const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../../src/lib/logic.js');
const C = require('../../src/lib/content.js');

test('6 refeições: horários a partir de acordar, treino e dormir', () => {
  // treino cedo (06:00): café depois do treino
  assert.deepEqual(L.defaultMealTimes('05:30', '06:00', '22:30'), { cafe: '07:15', lanche1: '09:45', almoco: '12:15', lanche2: '15:15', jantar: '18:30', ceia: '21:30' });
  // treino à noite: café logo após acordar
  const t = L.defaultMealTimes('06:30', '18:30', '22:30');
  assert.equal(t.cafe, '07:00');
  const mins = Object.values(t).map(L.minutesOf);
  mins.forEach((m, i) => { if (i) assert.ok(m > mins[i - 1], 'refeições em ordem'); });
  assert.ok(L.minutesOf(t.ceia) <= L.minutesOf('22:30') - 60, 'ceia pelo menos 1 h antes de dormir');
  // almoço fica entre 11:30 e 13:30 mesmo acordando muito cedo
  const early = L.defaultMealTimes('04:00', '19:00', '21:30');
  assert.ok(L.minutesOf(early.almoco) >= 690 && L.minutesOf(early.almoco) <= 810);
});

test('semana: alterna academia e corrida nos dias de treino', () => {
  assert.deepEqual(L.weekPlanFromDays([1, 3, 5]), { 0: 'rest', 1: 'gym', 2: 'rest', 3: 'run', 4: 'rest', 5: 'gym', 6: 'rest' });
  const six = L.weekPlanFromDays([1, 2, 3, 4, 5, 6]);
  assert.equal(Object.values(six).filter((v) => v === 'run').length, 3);
  assert.equal(six[0], 'rest');
  assert.equal(six[6], 'run', 'longo no fim da semana');
  assert.deepEqual(L.weekPlanFromDays([]), { 0: 'rest', 1: 'rest', 2: 'rest', 3: 'rest', 4: 'rest', 5: 'rest', 6: 'rest' });
});

test('plano de corrida: semanas até a prova e semana atual', () => {
  assert.equal(L.planWeeks('2026-09-29', '2027-05-16'), 33); // começa na segunda 28/09, prova num domingo
  assert.equal(L.planWeekNow('2026-09-29', '2026-09-29'), 1);
  assert.equal(L.planWeekNow('2026-09-29', '2026-10-05'), 2);
  assert.equal(L.planWeekNow('2026-09-29', '2026-10-05', 1), 1, 'repetir semana');
  assert.equal(L.planWeekNow('2026-09-29', '2026-09-29', 3), 1, 'nunca abaixo de 1');
  // plano com a duração-base usa as semanas do plano direto; semana da prova é sempre a 33
  assert.equal(L.canonicalWeek(10, 33), 10);
  assert.equal(L.canonicalWeek(33, 33), 33);
  assert.equal(L.canonicalWeek(60, 60), 33);
  // plano longo (prova no ano que vem): avança mais devagar e nunca pula a prova
  const long = Array.from({ length: 59 }, (_, i) => L.canonicalWeek(i + 1, 60));
  long.forEach((w, i) => { assert.ok(w >= 1 && w <= 32); if (i) assert.ok(w >= long[i - 1], 'nunca volta'); });
  // plano curto: comprime, sem pular direto para a prova
  assert.ok(L.canonicalWeek(1, 12) >= 1 && L.canonicalWeek(11, 12) <= 32);
});

test('conteúdo da corrida: 33 semanas, 3 sessões, progressão segura', () => {
  assert.equal(C.RUN_PLAN.length, 34);
  for (let w = 1; w <= 33; w++) {
    const wk = C.RUN_PLAN[w];
    assert.equal(wk.length, 3, 'semana ' + w);
    for (const s of wk) {
      assert.ok(s.title && s.kind && s.blocks.length, 'sessão completa na semana ' + w);
      s.blocks.forEach((b) => assert.ok(['r', 'w', 'b'].includes(b.t) && b.s > 0));
    }
  }
  // base de caminhada: nada de corrida nas 6 primeiras semanas
  for (let w = 1; w <= 6; w++) C.RUN_PLAN[w].forEach((s) => assert.equal(L.runSeconds(s.blocks), 0, 'sem corrida na semana ' + w));
  // o tempo total correndo cresce aos poucos (tolera semanas de descanso)
  const runMin = (w) => C.RUN_PLAN[w].reduce((a, s) => a + (s.kind === 'race' ? 0 : L.runSeconds(s.blocks)), 0) / 60;
  for (let w = 8; w <= 30; w++) assert.ok(runMin(w) <= Math.max(runMin(w - 1), runMin(w - 2)) * 1.35 + 8, `salto grande na semana ${w}`);
  // sessões longas com duração realista (nada de horas de blocos)
  for (let w = 1; w <= 33; w++) C.RUN_PLAN[w].forEach((s) => assert.ok(L.blocksSeconds(s.blocks) <= 100 * 60, `sessão longa demais na semana ${w}: ${s.title}`));
  const race = C.RUN_PLAN[33][2];
  assert.equal(race.kind, 'race'); assert.equal(race.targetKm, 10);
  assert.equal(C.RUN_PHASES[0].from, 1); assert.equal(C.RUN_PHASES[C.RUN_PHASES.length - 1].to, 33);
});

test('sessão ao vivo: bloco atual, tempo restante e versão caminhada', () => {
  const bl = [{ t: 'w', s: 300 }, { t: 'r', s: 60 }, { t: 'w', s: 120 }];
  assert.deepEqual(L.blockAt(bl, 0), { i: 0, left: 300, start: 0 });
  assert.deepEqual(L.blockAt(bl, 330), { i: 1, left: 30, start: 300 });
  assert.equal(L.blockAt(bl, 480).i, 3, 'terminou');
  assert.equal(L.blocksSeconds(bl), 480);
  assert.equal(L.runSeconds(bl), 60);
  const walk = L.walkVersion(bl);
  assert.equal(L.runSeconds(walk), 0);
  assert.equal(walk[1].t, 'b', 'corrida vira caminhada rápida');
  assert.equal(L.blocksSeconds(walk), 480, 'mesma duração');
});

test('GPS: soma distância e ignora leituras ruins ou saltos', () => {
  let st = null;
  const p = (lat, lon, ts, acc = 8) => ({ lat, lon, ts, acc });
  st = L.gpsAccumulate(st, p(-9.66, -35.70, 0));
  st = L.gpsAccumulate(st, p(-9.66, -35.6991, 60000)); // ~98 m em 1 min
  assert.ok(st.m > 90 && st.m < 110, 'distância ' + st.m);
  const before = st.m;
  st = L.gpsAccumulate(st, p(-9.60, -35.6991, 61000)); // salto de km em 1 s
  assert.equal(st.m, before, 'salto ignorado');
  st = L.gpsAccumulate(st, p(-9.66, -35.6981, 120000, 80)); // precisão ruim
  assert.equal(st.m, before, 'leitura imprecisa ignorada');
  assert.equal(L.pace(1800, 5), '6:00');
  assert.equal(L.pace(3599, 10), '6:00');
  assert.equal(L.pace(100, 0), null);
});

test('agenda do dia: ordem, refeições, suplementos e blocos fixos', () => {
  const ag = L.buildAgenda({
    weekday: 2, wake: '05:30', bed: '22:30', train: '06:00', dayPlan: 'run', trainLabel: 'Caminhada', trainSub: '', photo: true,
    meals: [{ id: 'cafe', label: 'Café', time: '07:15' }, { id: 'jantar', label: 'Jantar', time: '18:30' }],
    supps: [{ id: 's1', name: 'Creatina', time: '07:15' }],
    custom: [{ id: 'c1', label: 'Trabalho', time: '08:00', end: '17:00', days: [1, 2, 3, 4, 5] }, { id: 'c2', label: 'Igreja', time: '19:00', days: [0] }],
  });
  const ids = ag.map((x) => x.id);
  assert.equal(ids[0], 'wake');
  assert.ok(ids.includes('train') && ids.includes('pre') && ids.includes('photo'));
  assert.ok(ids.includes('custom:c1') && !ids.includes('custom:c2'), 'bloco só nos dias marcados');
  assert.equal(ag.find((x) => x.id === 'train').kind, 'run');
  const t = ag.map((x) => L.minutesOf(x.time));
  t.forEach((m, i) => { if (i) assert.ok(m >= t[i - 1], 'em ordem de horário'); });
  assert.ok(ids.indexOf('meal:cafe') < ids.indexOf('supp:s1'), 'suplemento junto da refeição vem depois dela');
  assert.equal(ids[ids.length - 1], 'sleep');
  const rest = L.buildAgenda({ weekday: 0, wake: '06:00', bed: '22:00', train: '06:00', dayPlan: 'rest', meals: [], supps: [], custom: [] });
  assert.ok(!rest.some((x) => x.id === 'train'), 'sem treino no descanso');
});

test('fotos: sequência de dias e estoque de suplementos', () => {
  assert.equal(L.photoStreak(['2026-09-27', '2026-09-28', '2026-09-29'], '2026-09-29'), 3);
  assert.equal(L.photoStreak(['2026-09-27', '2026-09-28'], '2026-09-29'), 2, 'hoje ainda pode tirar');
  assert.equal(L.photoStreak(['2026-09-25'], '2026-09-29'), 0);
  assert.equal(L.suppDaysLeft({ stock: 30, perDose: 1 }), 30);
  assert.equal(L.suppDaysLeft({ stock: 30, perDose: 1, days: [1, 3, 5] }), 70);
  assert.equal(L.suppDaysLeft({ stock: null }), null);
  assert.equal(L.suppDaysLeft({ stock: '' }), null);
});

test('calendário .ics: recorrência, alarme e texto escapado', () => {
  const ics = L.buildICS([
    { id: 'cafe', time: '07:15', title: 'Saúde Jr. · Café; com fruta, fibra', desc: 'linha 1\nlinha 2' },
    { id: 'gym', time: '06:00', days: [1, 3, 5], title: 'Academia', dur: 60 },
  ], '2026-09-29', '20260929T120000Z');
  assert.ok(ics.startsWith('BEGIN:VCALENDAR\r\n') && ics.trim().endsWith('END:VCALENDAR'));
  assert.ok(ics.includes('DTSTART:20260929T071500') && ics.includes('RRULE:FREQ=DAILY'));
  assert.ok(ics.includes('Café\\; com fruta\\, fibra'), 'ponto e vírgula e vírgula escapados');
  assert.ok(ics.includes('linha 1\\nlinha 2'));
  // evento semanal começa no primeiro dia da regra (terça 29/09 → quarta 30/09)
  assert.ok(ics.includes('DTSTART:20260930T060000') && ics.includes('RRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR'));
  assert.ok(ics.includes('DTEND:20260930T070000'));
  assert.equal((ics.match(/BEGIN:VALARM/g) || []).length, 2);
  ics.split('\r\n').forEach((line) => assert.ok(line.length <= 75, 'linhas dobradas: ' + line));
});

test('cardápio: 7 opções por refeição, frutas e fibras suficientes', () => {
  assert.equal(C.MEALS6.length, 6);
  for (const m of C.MEALS6) assert.equal(C.MENU[m.id].length, 7, m.id);
  for (let wd = 0; wd < 7; wd++) {
    const day = C.MEALS6.map((m) => C.MENU[m.id][wd]);
    assert.ok(day.filter((x) => x.fr).length >= 2, 'pelo menos 2 frutas no dia ' + wd);
    assert.ok(day.filter((x) => x.f).length >= 4, 'fibra em 4+ refeições no dia ' + wd);
    assert.ok(day.filter((x) => x.p).length >= 3, 'proteína em 3+ refeições no dia ' + wd);
  }
  // seguindo o cardápio, fibras, frutas e alimentação se marcam sozinhas
  const menu = {}; C.MEALS6.forEach((m) => { menu[m.id] = C.MENU[m.id][2]; });
  const meals = {}; C.MEALS6.forEach((m) => { meals[m.id] = 'ok'; });
  const auto = L.autoChecks({ meals }, { menu });
  assert.ok(auto.fibras && auto.frutas && auto.alimentacao && auto.proteina);
  const few = L.autoChecks({ meals: { cafe: 'ok', almoco: 'fora' } }, { menu });
  assert.ok(!few.alimentacao && !few.fibras);
});

test('textos de segurança sem promessas', () => {
  const all = JSON.stringify(C).toLowerCase();
  ['testosterona aumenta', 'garantido', 'cura ', 'anabolizante indicado', 'jejum de 24', 'jejum prolongado recomendado'].forEach((w) => assert.ok(!all.includes(w), w));
  assert.ok(C.SUPP_NOTE.includes('não recomenda'));
});
