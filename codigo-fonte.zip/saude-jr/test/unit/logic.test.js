const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../../src/lib/logic.js');
const C = require('../../src/lib/content.js');

const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} ≉ ${b}`);

test('datas locais: chave, soma de dias, diferença, semana', () => {
  assert.equal(L.key(new Date(2026, 8, 29, 23, 50)), '2026-09-29'); // 23:50 não vira o dia seguinte
  assert.equal(L.addDays('2026-09-29', 3), '2026-10-02');
  assert.equal(L.addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(L.addDays('2027-03-01', -1), '2027-02-28');
  assert.equal(L.diffDays('2026-09-28', '2026-10-05'), 7);
  assert.equal(L.weekday('2026-09-29'), 2); // terça
  assert.equal(L.weekStart('2026-09-29'), '2026-09-28');
  assert.equal(L.weekStart('2026-10-04'), '2026-09-28'); // domingo pertence à semana de segunda
  assert.equal(L.monthKey('2026-09-29'), '2026-09');
});

test('horas e sono atravessando meia-noite', () => {
  assert.equal(L.minutesOf('18:30'), 1110);
  assert.equal(L.minutesOf('nada'), null);
  assert.equal(L.hm(1110), '18:30');
  assert.equal(L.hm(-30), '23:30');
  assert.equal(L.sleepHours('23:00', '06:30'), 7.5);
  assert.equal(L.sleepHours('00:30', '07:00'), 6.5);
  assert.equal(L.sleepHours('22:15', '06:00'), 7.8);
});

test('números com vírgula', () => {
  assert.equal(L.num('111,4'), 111.4);
  assert.equal(L.num(' 90 '), 90);
  assert.equal(L.num(''), null);
  assert.equal(L.num('abc'), null);
});

test('pesagens: uma por dia, vale a última registrada', () => {
  const d = L.dailyWeights([
    { date: '2026-09-30', kg: 111.9, at: 2 },
    { date: '2026-09-29', kg: 112, at: 1 },
    { date: '2026-09-30', kg: 111.5, at: 3 },
    { date: '2026-10-01', kg: 0, at: 4 },
  ]);
  assert.deepEqual(d, [{ date: '2026-09-29', kg: 112 }, { date: '2026-09-30', kg: 111.5 }]);
});

test('tendência suaviza e acompanha a queda', () => {
  const pts = [];
  for (let i = 0; i < 60; i += 3) pts.push({ date: L.addDays('2026-09-29', i), kg: 112 - i * 0.1 + (i % 2 ? 0.6 : -0.6) });
  const t = L.trendSeries(pts);
  assert.equal(t[0].trend, pts[0].kg);
  const last = t[t.length - 1];
  assert.ok(last.trend < 108 && last.trend > 105.5, 'tendência perto da reta real');
});

test('ritmo semanal por regressão', () => {
  const pts = [];
  for (let i = 0; i <= 28; i += 2) pts.push({ date: L.addDays('2026-09-29', i), kg: 112 - i * 0.1 });
  near(L.weeklyRate(pts), -0.7, 1e-9);
  assert.equal(L.weeklyRate([{ date: '2026-09-29', kg: 112 }, { date: '2026-10-01', kg: 111 }]), null); // menos de 7 dias
});

test('metas intermediárias de 5 em 5 kg', () => {
  assert.deepEqual(L.milestones(112, 90), [105, 100, 95, 90]);
  assert.deepEqual(L.milestones(125, 90), [120, 115, 110, 105, 100, 95, 90]);
  assert.deepEqual(L.milestones(122, 92), [115, 110, 105, 100, 95, 92]);
  assert.deepEqual(L.milestones(112, null), [105, 100, 95, 90]);
});

test('projeção da meta', () => {
  near(L.weeksTo(112, 90, 0.01), 21.76, 0.01);
  near(L.weeksTo(112, 90, 0.005), 43.63, 0.01);
  assert.equal(L.weeksTo(89, 90, 0.01), 0);
  near(L.weightAfter(112, 0.007, 4), 108.9, 0.05);
  assert.equal(L.dateAfterWeeks('2026-09-29', 2), '2026-10-13');
});

test('checklist: automático, manual vence, pontuação e sequência', () => {
  const day = { water: 3000, steps: 7000, sleep: { hours: 7.5 }, gut: { fiber: 3, fruits: 2, veg: 2 }, meals: { cafe: 'ok', almoco: 'troca', lanche2: 'ok', jantar: 'ok', lanche1: 'fora' }, checks: { passos: false } };
  const auto = L.autoChecks(day, { trained: false, cardio: true, waterGoal: 3000, stepsGoal: 6000 });
  assert.equal(auto.treino, true);
  assert.equal(auto.agua, true);
  assert.equal(auto.proteina, true);
  assert.equal(auto.alimentacao, true);
  const st = L.checkState(day, auto);
  assert.equal(st.passos, false, 'desmarcado à mão');
  assert.equal(L.dayScore(st), 7 / 8);
  const good = new Set(['2026-09-26', '2026-09-27', '2026-09-28']);
  const isC = (k) => good.has(k);
  assert.equal(L.streak(isC, '2026-09-29', '2026-09-20'), 3, 'hoje ainda em andamento não quebra a sequência');
  good.add('2026-09-29');
  assert.equal(L.streak(isC, '2026-09-29', '2026-09-20'), 4);
  assert.equal(L.streak(isC, '2026-09-30', '2026-09-20'), 4);
  assert.equal(L.streak(isC, '2026-10-01', '2026-09-20'), 0);
  assert.equal(L.longestStreak(isC, '2026-09-20', '2026-10-01'), 4);
});

test('água esperada pelo horário', () => {
  // acorda 06:30, dorme 22:30 → janela até 21:30
  assert.equal(L.waterExpected(3000, 6 * 60, 390, 1350), 0);
  assert.equal(L.waterExpected(3000, 14 * 60, 390, 1350), 1500); // metade da janela 06:30–21:30
  assert.equal(L.waterExpected(3000, 22 * 60, 390, 1350), 3000);
  // dorme depois da meia-noite
  assert.ok(L.waterExpected(3000, 23 * 60, 480, 30) < 3000);
});

test('progressão dupla de carga', () => {
  const base = { kind: 'reps', inc: 5, load: 40, target: [10, 12], sets: [{ done: true, reps: 12 }, { done: true, reps: 12 }, { done: true, reps: 12 }] };
  assert.deepEqual([L.progression({ ...base, difficulty: 2 }).action, L.progression({ ...base, difficulty: 2 }).load], ['up', 45]);
  assert.equal(L.progression({ ...base, difficulty: 3 }).action, 'keep');
  assert.deepEqual([L.progression({ ...base, difficulty: 4 }).action, L.progression({ ...base, difficulty: 4 }).load], ['down', 35]);
  const short = { ...base, difficulty: 2, sets: [{ done: true, reps: 12 }, { done: true, reps: 10 }, { done: true, reps: 9 }] };
  assert.equal(L.progression(short).action, 'keep', 'não chegou ao topo das repetições');
  const incomplete = { ...base, difficulty: 3, sets: [{ done: true, reps: 12 }, { done: false, reps: 12 }] };
  assert.equal(L.progression(incomplete).action, 'keep');
  const time = { kind: 'time', inc: 0, load: 0, target: [20, 30], sets: [{ done: true, reps: 30 }, { done: true, reps: 30 }], difficulty: 1 };
  assert.equal(L.progression(time).secBonus, 5);
  const bw = { kind: 'reps', inc: 0, load: 0, target: [10, 12], sets: [{ done: true, reps: 12 }], difficulty: 1 };
  assert.equal(L.progression(bw).action, 'reps');
});

test('cardio: MET e calorias estimadas', () => {
  assert.equal(L.cardioMET('esteira', 5.0, 4), 3.5);
  assert.equal(L.cardioMET('caminhada', 6.2, 4), 5.0);
  assert.equal(L.cardioMET('bicicleta', null, 5), 4.8);
  assert.equal(L.kcal(3.5, 112, 30), 196);
  assert.equal(L.kcal(3.5, 112, 0), null);
});

test('marmita: soma, rótulo e avaliação', () => {
  const m = { protFood: 'frango', protG: 150, carbFood: 'arroz', carbG: 100, vegFood: 'brocolis', vegG: 150 };
  const t = L.marmitaTotals(m, C.FOODS);
  assert.deepEqual(t, { kcal: 410, prot: 53, source: 'estimativa' });
  assert.equal(L.marmitaCheck(m, t).level, 'ok');
  assert.deepEqual(L.marmitaTotals({ ...m, kcal: '450', prot: '38' }, C.FOODS), { kcal: 450, prot: 38, source: 'rotulo' });
  const unknown = L.marmitaTotals({ protFood: 'outro', protG: 150, vegFood: 'brocolis', vegG: 100 }, C.FOODS);
  assert.equal(unknown.kcal, null, 'não inventa valor quando não conhece o alimento');
  const noGrams = L.marmitaTotals({ protFood: 'frango', vegFood: 'brocolis' }, C.FOODS);
  assert.equal(noGrams.kcal, null);
  const lowVeg = L.marmitaCheck({ protFood: 'frango', protG: 150, carbFood: 'arroz', carbG: 250, vegFood: 'brocolis', vegG: 40 }, { kcal: null, prot: null });
  assert.equal(lowVeg.level, 'ajustar');
  assert.equal(lowVeg.tips.length, 2);
});

test('alertas sem diagnóstico', () => {
  assert.equal(L.gutFlag([{ bm: true }, { blood: true }]), 'urgente');
  assert.equal(L.gutFlag([{ bm: false }, { bm: false }, { bm: false }, { bm: true }]), 'atencao');
  assert.equal(L.gutFlag([{ bm: true }, undefined, { bm: false }]), null);
  const tired = Array.from({ length: 8 }, () => ({ hours: 7, energy: 3 }));
  assert.equal(L.fatigueFlag(tired), true);
  assert.equal(L.fatigueFlag(tired.slice(0, 5)), false);
  assert.equal(L.fatigueFlag(Array.from({ length: 8 }, () => ({ hours: 5.5, energy: 7 }))), true);
});

test('conteúdo: programa, semanas e textos consistentes', () => {
  for (const t of ['A', 'B']) for (const slot of C.PROGRAM[t].slots) for (const id of slot.options) assert.ok(C.EX[id], `exercício ${id} existe`);
  for (const id of C.QUICK_HOME.exercises) assert.ok(C.EX[id]);
  for (const s of C.QUICK.slots) assert.ok(C.PROGRAM.A.slots.find((x) => x.id === s));
  for (let w = 1; w <= 20; w++) {
    const c = C.weekConfig(w);
    for (const role of ['main', 'acc', 'core']) { assert.ok(c[role][0] >= 2 && c[role][0] <= 4); assert.ok(c.rest[role] > 0); }
    assert.ok(C.cardioPlan(w).minutes >= 20);
  }
  assert.equal(C.phaseOf(4), 1); assert.equal(C.phaseOf(5), 2); assert.equal(C.phaseOf(13), 3);
  assert.equal(new Set(C.MEALS.map((m) => m.id)).size, C.MEALS.length);
  assert.ok(C.PHRASES.length >= 30);
  for (const f of Object.values(C.FOODS)) assert.ok(f.kcal > 0 && f.prot >= 0);
  // nada de prescrição proibida nos textos
  const all = JSON.stringify(C).toLowerCase();
  for (const bad of ['tome testosterona', 'use anabolizante', 'jejum de 24', 'jejum de 48']) assert.ok(!all.includes(bad), bad);
});
