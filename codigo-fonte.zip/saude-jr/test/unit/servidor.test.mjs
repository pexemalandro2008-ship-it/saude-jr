// Testes da função de servidor "app" (cadastro e configuração pública), sem rede.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler, validateSignup, LIMITS } from '../../supabase/functions/app/logic.js';

function fakeDeps(over = {}) {
  const attempts = [];
  const users = new Map();
  return Object.assign({
    publishableKey: 'sb_publishable_teste',
    salt: 'sal-secreto',
    attempts, users,
    async countAttempts(h, since) { return attempts.filter((a) => a.h === h && a.at >= since).length; },
    async countAll(since) { return attempts.filter((a) => a.at >= since).length; },
    async recordAttempt(h) { attempts.push({ h, at: new Date().toISOString() }); },
    async createUser({ email, password, name }) {
      if (users.has(email)) return { error: { code: 'email_exists', status: 422 } };
      users.set(email, { password, name });
      return {};
    },
  }, over);
}
const post = (body, ip = '1.2.3.4') => new Request('https://x.supabase.co/functions/v1/app/signup', {
  method: 'POST', headers: { 'content-type': 'application/json', 'x-forwarded-for': ip }, body: typeof body === 'string' ? body : JSON.stringify(body),
});

test('validação do cadastro', () => {
  assert.equal(validateSignup({ email: 'ana@exemplo.com', password: 'senha123' }).email, 'ana@exemplo.com');
  assert.equal(validateSignup({ email: '  ANA@Exemplo.COM ', password: 'senha123' }).email, 'ana@exemplo.com');
  assert.match(validateSignup({ email: 'ana', password: 'senha123' }).error, /e-mail/);
  assert.match(validateSignup({ email: 'ana@exemplo', password: 'senha123' }).error, /e-mail/);
  assert.match(validateSignup({ email: 'ana@exemplo.com', password: 'curta1' }).error, /8 caracteres/);
  assert.match(validateSignup({ email: 'ana@exemplo.com', password: 'somenteletras' }).error, /letras e números/);
  assert.match(validateSignup({ email: 'ana@exemplo.com', password: '12345678' }).error, /letras e números/);
  assert.match(validateSignup({ email: 'marcos@exemplo.com', password: 'marcos2026' }).error, /não pode conter/);
  assert.match(validateSignup({ email: 'ana@exemplo.com', password: 'a1'.repeat(40) }).error, /72/);
  assert.equal(validateSignup({ email: 'ana@exemplo.com', password: 'senha123', name: '  Ana   Maria ' }).name, 'Ana Maria');
});

test('config devolve só a chave pública', async () => {
  const h = createHandler(fakeDeps());
  const r = await h(new Request('https://x.supabase.co/functions/v1/app/config'));
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.deepEqual(Object.keys(j).sort(), ['key', 'signup']);
  assert.equal(j.key, 'sb_publishable_teste');
  assert.equal(r.headers.get('access-control-allow-origin'), '*');
  const sem = await createHandler(fakeDeps({ publishableKey: null }))(new Request('https://x.supabase.co/functions/v1/app/config'));
  assert.equal(sem.status, 503);
});

test('cadastro: cria, recusa repetido, recusa inválido', async () => {
  const d = fakeDeps();
  const h = createHandler(d);
  const ok = await h(post({ email: 'ana@exemplo.com', password: 'senha123', name: 'Ana' }));
  assert.equal(ok.status, 201);
  assert.equal(d.users.get('ana@exemplo.com').name, 'Ana');
  const rep = await h(post({ email: 'ana@exemplo.com', password: 'outra123' }, '5.6.7.8'));
  assert.equal(rep.status, 409);
  assert.match((await rep.json()).error, /já tem conta/);
  const bad = await h(post({ email: 'x', password: 'senha123' }));
  assert.equal(bad.status, 400);
  const lixo = await h(post('não é json'));
  assert.equal(lixo.status, 400);
  // IP guardado só como hash, nunca em texto
  assert.ok(d.attempts.every((a) => /^[0-9a-f]{64}$/.test(a.h) && !a.h.includes('1.2.3.4')));
});

test('cadastro: limite por origem e por dia', async () => {
  const d = fakeDeps();
  const h = createHandler(d);
  for (let i = 0; i < LIMITS.perIpHour; i++) assert.equal((await h(post({ email: `u${i}@exemplo.com`, password: 'senha123' }))).status, 201);
  const bloq = await h(post({ email: 'mais@exemplo.com', password: 'senha123' }));
  assert.equal(bloq.status, 429);
  assert.equal((await h(post({ email: 'outro@exemplo.com', password: 'senha123' }, '9.9.9.9'))).status, 201, 'outra origem continua podendo');
  const cheio = fakeDeps({ countAll: async () => LIMITS.perDay });
  assert.equal((await createHandler(cheio)(post({ email: 'z@exemplo.com', password: 'senha123' }))).status, 429);
});

test('cadastro: falhas do servidor viram mensagens claras', async () => {
  const fora = createHandler(fakeDeps({ countAttempts: async () => { throw new Error('db fora'); } }));
  assert.equal((await fora(post({ email: 'a@exemplo.com', password: 'senha123' }))).status, 503);
  const erro = createHandler(fakeDeps({ createUser: async () => ({ error: { code: 'unexpected_failure', status: 500 } }) }));
  const r = await erro(post({ email: 'a@exemplo.com', password: 'senha123' }));
  assert.equal(r.status, 500);
  assert.match((await r.json()).error, /Tente de novo/);
  const fraca = createHandler(fakeDeps({ createUser: async () => ({ error: { code: 'weak_password', status: 422 } }) }));
  assert.equal((await fraca(post({ email: 'a@exemplo.com', password: 'senha123' }))).status, 400);
  const nf = await createHandler(fakeDeps())(new Request('https://x.supabase.co/functions/v1/app/outra'));
  assert.equal(nf.status, 404);
  const pre = await createHandler(fakeDeps())(new Request('https://x.supabase.co/functions/v1/app/signup', { method: 'OPTIONS' }));
  assert.equal(pre.status, 204);
});
