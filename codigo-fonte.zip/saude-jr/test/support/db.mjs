// Banco de testes: cria um Postgres limpo com o mesmo esquema do Supabase de produção.
//   Conexão pelas variáveis padrão do Postgres (PGHOST, PGPORT, PGUSER, PGPASSWORD).
//   Local: 127.0.0.1:54329 (usuário postgres). CI: serviço postgres do GitHub Actions.
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';

const require = createRequire(import.meta.url);
const pg = require('pg');
export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

export function connInfo(database) {
  return {
    host: process.env.PGHOST || '127.0.0.1',
    port: Number(process.env.PGPORT || 54329),
    user: process.env.PGUSER || 'postgres',
    password: process.env.PGPASSWORD || undefined,
    database: database || process.env.PGDATABASE || 'postgres',
  };
}

/** cria (ou recria) o banco e aplica: ambiente tipo Supabase + migrações do projeto */
export async function freshDatabase(name) {
  const admin = new pg.Client(connInfo('postgres'));
  await admin.connect();
  await admin.query(`drop database if exists "${name}" with (force)`);
  await admin.query(`create database "${name}"`);
  await admin.end();
  const c = new pg.Client(connInfo(name));
  await c.connect();
  await c.query(fs.readFileSync(path.join(ROOT, 'test/sql/00-supabase-bootstrap.sql'), 'utf8'));
  const migDir = path.join(ROOT, 'supabase/migrations');
  for (const f of fs.readdirSync(migDir).filter((x) => x.endsWith('.sql')).sort()) {
    await c.query(fs.readFileSync(path.join(migDir, f), 'utf8'));
  }
  await c.end();
  return connInfo(name);
}

export async function dropDatabase(name) {
  const admin = new pg.Client(connInfo('postgres'));
  await admin.connect();
  await admin.query(`drop database if exists "${name}" with (force)`);
  await admin.end();
}
