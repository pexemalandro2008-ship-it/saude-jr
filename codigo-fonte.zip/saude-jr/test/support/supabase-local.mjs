// Supabase local para os testes de ponta a ponta — sem internet e sem Docker.
//
// Implementa só o que o app usa, com o MESMO banco e as MESMAS regras (RLS) da produção:
//   /auth/v1      entrar, renovar sessão, sair, usuário, trocar senha, recuperar senha (e-mails vão para uma caixa de teste)
//   /rest/v1      tabela app_documents (listar, gravar/atualizar, apagar) — executado como o papel "authenticated"
//                 com o id do usuário no token, exatamente como o PostgREST faz. Quem decide o acesso é o Postgres.
//   /storage/v1   fotos no bucket progress-photos (enviar, baixar, apagar), também passando pelas regras do banco
//   /functions/v1/app   o MESMO código da função de produção (supabase/functions/app/logic.js)
//   /__test/outbox      e-mails "enviados" (links de recuperação)
import http from 'http';
import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { createRequire } from 'module';
import { createHandler } from '../../supabase/functions/app/logic.js';

const require = createRequire(import.meta.url);
const pg = require('pg');

const b64url = (buf) => Buffer.from(buf).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
const fromB64url = (s) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');

export async function startSupabaseLocal({ db, port = 54321, jwtSecret = 'segredo-local-de-teste-com-32-caracteres!!', accessTtl = 3600 } = {}) {
  const pool = new pg.Pool(Object.assign({ max: 8 }, db));
  const KEY = 'sb_publishable_teste_local';
  const storageDir = fs.mkdtempSync(path.join(os.tmpdir(), 'saudejr-storage-'));
  const refresh = new Map(); // token → { uid, revoked }
  const recovery = new Map(); // tokenHash → { uid, exp }
  const outbox = [];
  const base = `http://127.0.0.1:${port}`;
  const stats = { requests: 0, anonRest: 0 };

  function sign(payload) {
    const head = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const body = b64url(JSON.stringify(payload));
    const sig = b64url(crypto.createHmac('sha256', jwtSecret).update(head + '.' + body).digest());
    return `${head}.${body}.${sig}`;
  }
  function verify(tok) {
    const parts = String(tok || '').split('.');
    if (parts.length !== 3) return null;
    const sig = b64url(crypto.createHmac('sha256', jwtSecret).update(parts[0] + '.' + parts[1]).digest());
    if (sig !== parts[2]) return null;
    try { const p = JSON.parse(fromB64url(parts[1]).toString()); return p.exp && p.exp * 1000 < Date.now() ? null : p; } catch (e) { return null; }
  }
  const hashPw = (pw) => { const salt = crypto.randomBytes(16).toString('hex'); return `scrypt$${salt}$${crypto.scryptSync(pw, salt, 32).toString('hex')}`; };
  const checkPw = (pw, stored) => {
    const [, salt, h] = String(stored || '').split('$');
    if (!salt || !h) return false;
    return crypto.timingSafeEqual(Buffer.from(h, 'hex'), crypto.scryptSync(String(pw), salt, 32));
  };
  const userJson = (u) => ({
    id: u.id, aud: 'authenticated', role: 'authenticated', email: u.email,
    email_confirmed_at: u.email_confirmed_at, confirmed_at: u.email_confirmed_at, last_sign_in_at: u.last_sign_in_at,
    app_metadata: u.raw_app_meta_data || { provider: 'email', providers: ['email'] }, user_metadata: u.raw_user_meta_data || {},
    identities: [], created_at: u.created_at, updated_at: u.updated_at, is_anonymous: false,
  });
  async function userById(id) { const r = await pool.query('select * from auth.users where id = $1', [id]); return r.rows[0] || null; }
  async function session(u, extra) {
    const now = Math.floor(Date.now() / 1000);
    const sid = crypto.randomUUID();
    const access = sign({ aud: 'authenticated', exp: now + accessTtl, iat: now, iss: base + '/auth/v1', sub: u.id, email: u.email, role: 'authenticated', session_id: sid, aal: 'aal1', is_anonymous: false, user_metadata: u.raw_user_meta_data || {}, app_metadata: u.raw_app_meta_data || {} });
    const rt = crypto.randomBytes(24).toString('hex');
    refresh.set(rt, { uid: u.id, revoked: false, sid });
    await pool.query('update auth.users set last_sign_in_at = now() where id = $1', [u.id]);
    return Object.assign({ access_token: access, token_type: 'bearer', expires_in: accessTtl, expires_at: now + accessTtl, refresh_token: rt, user: userJson(u) }, extra || {});
  }

  /** executa como o PostgREST: papel + claims do token na transação */
  async function asRole(claims, fn) {
    const c = await pool.connect();
    try {
      await c.query('begin');
      await c.query(`select set_config('role', $1, true), set_config('request.jwt.claims', $2, true)`, [claims && claims.sub ? 'authenticated' : 'anon', JSON.stringify(claims || { role: 'anon' })]);
      const r = await fn(c);
      await c.query('commit');
      return r;
    } catch (e) { try { await c.query('rollback'); } catch (e2) { /* ok */ } throw e; }
    finally { c.release(); }
  }

  const fnHandler = createHandler({
    publishableKey: KEY,
    salt: jwtSecret,
    async countAttempts(h, since) { return Number((await pool.query('select count(*) from public.signup_attempts where ip_hash = $1 and created_at >= $2', [h, since])).rows[0].count); },
    async countAll(since) { return Number((await pool.query('select count(*) from public.signup_attempts where created_at >= $1', [since])).rows[0].count); },
    async recordAttempt(h) { await pool.query('insert into public.signup_attempts (ip_hash) values ($1)', [h]); },
    async createUser({ email, password, name }) {
      try {
        await pool.query(`insert into auth.users (email, encrypted_password, email_confirmed_at, raw_user_meta_data) values ($1, $2, now(), $3)`, [email, hashPw(password), JSON.stringify(name ? { name } : {})]);
        return {};
      } catch (e) { return { error: e.code === '23505' ? { code: 'email_exists', status: 422 } : { code: 'unexpected_failure', status: 500, message: e.message } }; }
    },
  });

  const readBody = (req) => new Promise((res, rej) => { const ch = []; req.on('data', (c) => ch.push(c)); req.on('end', () => res(Buffer.concat(ch))); req.on('error', rej); });
  function cors(req, res) {
    res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || 'authorization,apikey,content-type,x-client-info,prefer,x-upsert');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, X-Total-Count');
    res.setHeader('Access-Control-Max-Age', '600');
  }
  const send = (res, status, body, headers) => {
    const isBuf = Buffer.isBuffer(body);
    res.writeHead(status, Object.assign({ 'content-type': isBuf ? 'application/octet-stream' : 'application/json; charset=utf-8' }, headers || {}));
    res.end(body == null ? '' : isBuf ? body : typeof body === 'string' ? body : JSON.stringify(body));
  };
  const authErr = (res, status, code, msg) => send(res, status, { code: status, error_code: code, msg, message: msg });
  const pgErr = (res, e, authed) => {
    const code = e.code || 'XX000';
    const status = code === '42501' ? (authed ? 403 : 401) : code === '23505' ? 409 : code === '23514' || code === '22P02' || code === '23502' ? 400 : 500;
    send(res, status, { code, details: e.detail || null, hint: e.hint || null, message: e.message });
  };
  const bearer = (req) => { const h = req.headers.authorization || ''; return /^Bearer\s+(.+)$/i.test(h) ? h.replace(/^Bearer\s+/i, '') : null; };
  const claimsOf = (req) => { const t = bearer(req); const p = t ? verify(t) : null; return p && p.role === 'authenticated' ? p : null; };

  async function handleAuth(req, res, url, route) {
    const body = ['POST', 'PUT'].includes(req.method) ? JSON.parse((await readBody(req)).toString() || '{}') : {};
    if (route === '/token' && url.searchParams.get('grant_type') === 'password') {
      const r = await pool.query('select * from auth.users where email = lower($1)', [String(body.email || '')]);
      const u = r.rows[0];
      if (!u || !checkPw(body.password, u.encrypted_password)) return authErr(res, 400, 'invalid_credentials', 'Invalid login credentials');
      if (!u.email_confirmed_at) return authErr(res, 400, 'email_not_confirmed', 'Email not confirmed');
      return send(res, 200, await session(u));
    }
    if (route === '/token' && url.searchParams.get('grant_type') === 'refresh_token') {
      const t = refresh.get(body.refresh_token);
      if (!t || t.revoked) return authErr(res, 400, 'refresh_token_not_found', 'Invalid Refresh Token: Refresh Token Not Found');
      t.revoked = true;
      const u = await userById(t.uid);
      if (!u) return authErr(res, 400, 'user_not_found', 'User not found');
      return send(res, 200, await session(u));
    }
    if (route === '/user' && req.method === 'GET') {
      const c = claimsOf(req);
      if (!c) return authErr(res, 401, 'bad_jwt', 'invalid JWT');
      const u = await userById(c.sub);
      return u ? send(res, 200, userJson(u)) : authErr(res, 404, 'user_not_found', 'User not found');
    }
    if (route === '/user' && req.method === 'PUT') {
      const c = claimsOf(req);
      if (!c) return authErr(res, 401, 'bad_jwt', 'invalid JWT');
      const u = await userById(c.sub);
      if (body.password != null) {
        if (String(body.password).length < 6) return authErr(res, 422, 'weak_password', 'Password should be at least 6 characters.');
        if (checkPw(body.password, u.encrypted_password)) return authErr(res, 422, 'same_password', 'New password should be different from the old password.');
        await pool.query('update auth.users set encrypted_password = $2, updated_at = now() where id = $1', [c.sub, hashPw(body.password)]);
      }
      return send(res, 200, userJson(await userById(c.sub)));
    }
    if (route === '/logout') {
      const c = claimsOf(req);
      if (c) for (const [k, v] of refresh) if (v.uid === c.sub && (url.searchParams.get('scope') === 'global' || v.sid === c.session_id)) refresh.delete(k);
      return send(res, 204, null);
    }
    if (route === '/recover') {
      const r = await pool.query('select * from auth.users where email = lower($1)', [String(body.email || '')]);
      const u = r.rows[0];
      const redirect = url.searchParams.get('redirect_to') || 'http://localhost:3000';
      if (u) {
        const hash = crypto.createHash('sha224').update(u.email + crypto.randomBytes(8).toString('hex')).digest('hex');
        recovery.set(hash, { uid: u.id, exp: Date.now() + 3600e3 });
        outbox.push({ to: u.email, type: 'recovery', link: `${base}/auth/v1/verify?token=${hash}&type=recovery&redirect_to=${encodeURIComponent(redirect)}`, at: Date.now() });
      }
      return send(res, 200, {});
    }
    if (route === '/verify' && req.method === 'GET') {
      const t = recovery.get(url.searchParams.get('token'));
      const redirect = url.searchParams.get('redirect_to') || 'http://localhost:3000';
      if (!t || t.exp < Date.now()) { res.writeHead(303, { location: `${redirect}#error=access_denied&error_code=otp_expired&error_description=Email+link+is+invalid+or+has+expired` }); return res.end(); }
      recovery.delete(url.searchParams.get('token'));
      const s = await session(await userById(t.uid));
      const frag = new URLSearchParams({ access_token: s.access_token, expires_at: String(s.expires_at), expires_in: String(s.expires_in), refresh_token: s.refresh_token, token_type: 'bearer', type: 'recovery' });
      res.writeHead(303, { location: `${redirect}#${frag}` });
      return res.end();
    }
    if (route === '/verify' && req.method === 'POST') {
      const t = recovery.get(body.token_hash);
      if (!t || t.exp < Date.now() || body.type !== 'recovery') return authErr(res, 403, 'otp_expired', 'Email link is invalid or has expired');
      recovery.delete(body.token_hash);
      return send(res, 200, await session(await userById(t.uid)));
    }
    if (route === '/settings') return send(res, 200, { external: { email: true }, disable_signup: false, mailer_autoconfirm: false });
    return authErr(res, 404, 'not_found', 'not found');
  }

  const DOC_COLS = new Set(['user_id', 'doc_id', 'data', 'updated_at']);
  async function handleRest(req, res, url, table) {
    if (table !== 'app_documents') return send(res, 404, { code: 'PGRST205', message: `Could not find the table 'public.${table}' in the schema cache` });
    const claims = claimsOf(req);
    if (!claims) stats.anonRest++;
    const filters = [], params = [];
    for (const [k, v] of url.searchParams) {
      if (['select', 'on_conflict', 'order', 'limit', 'columns'].includes(k)) continue;
      if (!DOC_COLS.has(k) || !v.startsWith('eq.')) return send(res, 400, { code: 'PGRST100', message: 'filtro não suportado no teste: ' + k });
      params.push(v.slice(3)); filters.push(`${k} = $${params.length}`);
    }
    const where = filters.length ? ' where ' + filters.join(' and ') : '';
    try {
      if (req.method === 'GET') {
        const cols = (url.searchParams.get('select') || '*').split(',').map((s) => s.trim());
        if (!cols.every((c) => c === '*' || DOC_COLS.has(c))) return send(res, 400, { code: 'PGRST100', message: 'select inválido' });
        const rows = await asRole(claims, (c) => c.query(`select ${cols.join(',')} from public.app_documents${where}`, params));
        return send(res, 200, rows.rows);
      }
      if (req.method === 'POST') {
        const body = JSON.parse((await readBody(req)).toString() || '[]');
        const list = Array.isArray(body) ? body : [body];
        const prefer = String(req.headers.prefer || '');
        const conflict = (url.searchParams.get('on_conflict') || '').split(',').filter(Boolean);
        await asRole(claims, async (c) => {
          for (const row of list) {
            const keys = Object.keys(row).filter((k) => DOC_COLS.has(k));
            const vals = keys.map((k) => (k === 'data' ? JSON.stringify(row[k]) : row[k]));
            let sql = `insert into public.app_documents (${keys.join(',')}) values (${keys.map((k, i) => `$${i + 1}`).join(',')})`;
            if (/resolution=merge-duplicates/.test(prefer) && conflict.length) sql += ` on conflict (${conflict.join(',')}) do update set ${keys.filter((k) => !conflict.includes(k)).map((k) => `${k} = excluded.${k}`).join(', ')}`;
            await c.query(sql, vals);
          }
        });
        return send(res, 201, null);
      }
      if (req.method === 'DELETE') {
        await asRole(claims, (c) => c.query(`delete from public.app_documents${where}`, params));
        return send(res, 204, null);
      }
    } catch (e) { return pgErr(res, e, !!claims); }
    return send(res, 405, { message: 'método não suportado' });
  }

  async function handleStorage(req, res, url, rest) {
    const claims = claimsOf(req);
    const m = /^\/object\/(?:authenticated\/)?([^/]+)(?:\/(.+))?$/.exec(rest);
    if (!m) return send(res, 404, { statusCode: '404', error: 'not_found', message: 'not found' });
    const bucket = decodeURIComponent(m[1]), name = m[2] ? decodeURIComponent(m[2]) : null;
    if (!claims) return send(res, 400, { statusCode: '403', error: 'Unauthorized', message: 'invalid signature' });
    const file = (n) => path.join(storageDir, bucket, n);
    try {
      if (req.method === 'POST' && name) {
        const raw = await readBody(req);
        let bytes = raw, mime = String(req.headers['content-type'] || 'application/octet-stream');
        if (/multipart\/form-data/.test(mime)) {
          const fd = await new Response(raw, { headers: { 'content-type': req.headers['content-type'] } }).formData();
          const part = [...fd.values()].find((v) => typeof v === 'object' && v && typeof v.arrayBuffer === 'function');
          if (!part) return send(res, 400, { statusCode: '400', error: 'InvalidRequest', message: 'sem arquivo' });
          bytes = Buffer.from(await part.arrayBuffer()); mime = part.type || 'application/octet-stream';
        }
        const b = (await pool.query('select * from storage.buckets where id = $1', [bucket])).rows[0];
        if (!b) return send(res, 400, { statusCode: '404', error: 'Bucket not found', message: 'Bucket not found' });
        if (b.allowed_mime_types && !b.allowed_mime_types.includes(mime)) return send(res, 400, { statusCode: '415', error: 'invalid_mime_type', message: `mime type ${mime} is not supported` });
        if (b.file_size_limit && bytes.length > Number(b.file_size_limit)) return send(res, 400, { statusCode: '413', error: 'Payload too large', message: 'The object exceeded the maximum allowed size' });
        const upsert = String(req.headers['x-upsert']) === 'true';
        const id = crypto.randomUUID();
        await asRole(claims, (c) => c.query(
          `insert into storage.objects (id, bucket_id, name, owner, owner_id, metadata) values ($1, $2, $3, $4::uuid, $4::text, $5)` + (upsert ? ' on conflict (bucket_id, name) do update set metadata = excluded.metadata, updated_at = now()' : ''),
          [id, bucket, name, claims.sub, JSON.stringify({ mimetype: mime, size: bytes.length })]));
        fs.mkdirSync(path.dirname(file(name)), { recursive: true });
        fs.writeFileSync(file(name), bytes);
        return send(res, 200, { Key: `${bucket}/${name}`, Id: id });
      }
      if (req.method === 'GET' && name) {
        const r = await asRole(claims, (c) => c.query('select metadata from storage.objects where bucket_id = $1 and name = $2', [bucket, name]));
        if (!r.rows.length || !fs.existsSync(file(name))) return send(res, 400, { statusCode: '404', error: 'not_found', message: 'Object not found' });
        return send(res, 200, fs.readFileSync(file(name)), { 'content-type': (r.rows[0].metadata || {}).mimetype || 'application/octet-stream' });
      }
      if (req.method === 'DELETE' && !name) {
        const body = JSON.parse((await readBody(req)).toString() || '{}');
        const r = await asRole(claims, (c) => c.query('delete from storage.objects where bucket_id = $1 and name = any($2) returning name, bucket_id', [bucket, body.prefixes || []]));
        for (const row of r.rows) { try { fs.unlinkSync(file(row.name)); } catch (e) { /* ok */ } }
        return send(res, 200, r.rows);
      }
    } catch (e) {
      if (e.code === '42501') return send(res, 400, { statusCode: '403', error: 'Unauthorized', message: 'new row violates row-level security policy' });
      if (e.code === '23505') return send(res, 400, { statusCode: '409', error: 'Duplicate', message: 'The resource already exists' });
      return send(res, 500, { statusCode: '500', error: 'internal', message: e.message });
    }
    return send(res, 405, { message: 'método não suportado' });
  }

  const server = http.createServer(async (req, res) => {
    stats.requests++;
    cors(req, res);
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    const url = new URL(req.url, base);
    const p = url.pathname;
    try {
      if (p.startsWith('/functions/v1/app')) {
        const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : undefined;
        const headers = new Headers();
        for (const [k, v] of Object.entries(req.headers)) if (typeof v === 'string') headers.set(k, v);
        headers.set('x-forwarded-for', req.headers['x-test-ip'] || req.socket.remoteAddress || '127.0.0.1');
        const r = await fnHandler(new Request(base + p + url.search, { method: req.method, headers, body }));
        const out = Buffer.from(await r.arrayBuffer());
        const h = {}; r.headers.forEach((v, k) => { h[k] = v; });
        return send(res, r.status, r.status === 204 ? null : out, h);
      }
      if (p.startsWith('/auth/v1')) {
        if (req.method !== 'GET' && !req.headers.apikey) return authErr(res, 401, 'no_api_key', 'No API key found in request');
        return await handleAuth(req, res, url, p.slice('/auth/v1'.length));
      }
      if (p.startsWith('/rest/v1/')) return await handleRest(req, res, url, p.slice('/rest/v1/'.length));
      if (p.startsWith('/storage/v1')) return await handleStorage(req, res, url, p.slice('/storage/v1'.length));
      if (p === '/__test/outbox') return send(res, 200, outbox);
      return send(res, 404, { message: 'not found' });
    } catch (e) {
      console.error('supabase-local:', e);
      return send(res, 500, { message: e.message });
    }
  });
  await new Promise((r) => server.listen(port, '127.0.0.1', r));
  return {
    url: base, key: KEY, pool, outbox, stats, storageDir,
    async close() { await new Promise((r) => server.close(r)); await pool.end(); fs.rmSync(storageDir, { recursive: true, force: true }); },
    lastLink(email) { for (let i = outbox.length - 1; i >= 0; i--) if (outbox[i].to === email) return outbox[i].link; return null; },
  };
}
