// Saúde Jr. — testes de ponta a ponta do app publicado (com conta):
// cadastro, login, logout, sessão persistente, recuperação de senha, dados separados por usuário (RLS de verdade,
// no Postgres), fotos privadas, sem internet, telas de 360 a 430 px e instalação (PWA).
//
// Sobe um Postgres limpo com as mesmas migrações da produção e um Supabase local (test/support/supabase-local.mjs).
import { createRequire } from 'module';
import { execFileSync } from 'child_process';
import fs from 'fs';
import http from 'http';
import path from 'path';
import os from 'os';
import { freshDatabase, dropDatabase, ROOT } from '../support/db.mjs';
import { startSupabaseLocal } from '../support/supabase-local.mjs';

const require = createRequire(import.meta.url);
const { chromium, devices } = require('playwright');

const SHOTS = process.env.SHOTS || path.join(os.tmpdir(), 'saude-jr-shots-cloud');
fs.mkdirSync(SHOTS, { recursive: true });
const DBNAME = 'saudejr_e2e';
const db = await freshDatabase(DBNAME);
const sb = await startSupabaseLocal({ db, port: 54321 });

execFileSync(process.execPath, [path.join(ROOT, 'scripts/build.mjs'), 'pwa'], { env: Object.assign({}, process.env, { SUPABASE_URL: sb.url, PWA_OUT: 'pwa-e2e' }), stdio: 'inherit' });

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.json': 'application/json', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8' };
const server = http.createServer((req, res) => {
  let rel = decodeURIComponent(req.url.split('?')[0].split('#')[0]);
  if (rel.endsWith('/')) rel += 'index.html';
  const f = path.join(ROOT, 'dist', rel);
  if (!f.startsWith(path.join(ROOT, 'dist')) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(8767, '127.0.0.1', r));
const APP = 'http://127.0.0.1:8767/pwa-e2e/';

const problems = [];
const check = (cond, msg) => { if (!cond) { problems.push(msg); console.log('  ✗ ' + msg); } else console.log('  ✓ ' + msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ channel: 'chromium' }).catch(() => chromium.launch());
const shot = (page, name, full = true) => page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: full }).catch(() => {});
const text = (page, sel) => page.locator(sel).first().innerText();
async function tap(page, sel, ms = 120) { await page.locator(sel).first().click(); await sleep(ms); }
async function act(page, data, ms = 150) { await page.evaluate((d) => { const b = document.createElement('button'); Object.assign(b.dataset, d); document.body.appendChild(b); b.click(); b.remove(); }, data); await sleep(ms); }
async function overflow(page, label) {
  const r = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  check(r.sw <= r.cw + 1, `sem rolagem lateral: ${label} (${r.sw}/${r.cw})`);
}
async function until(fn, tries = 60, ms = 100) { for (let i = 0; i < tries; i++) { try { if (await fn()) return true; } catch (e) { /* tenta de novo */ } await sleep(ms); } return false; }
const todayKey = new Intl.DateTimeFormat('sv-SE', { timeZone: 'America/Sao_Paulo' }).format(new Date());
const monthDoc = 'm-' + todayKey.slice(0, 7);
const q = async (sql, params) => (await sb.pool.query(sql, params)).rows;
const uidOf = async (email) => ((await q('select id from auth.users where email = $1', [email]))[0] || {}).id;
const allErrors = [];
async function newApp(opts = {}) {
  const ctx = await browser.newContext(Object.assign({ ...devices['Pixel 7'], timezoneId: 'America/Sao_Paulo', locale: 'pt-BR' }, opts));
  const page = await ctx.newPage();
  page.on('pageerror', (e) => allErrors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|ERR_INTERNET_DISCONNECTED|Failed to fetch|net::ERR_/.test(m.text())) allErrors.push('console: ' + m.text()); });
  return { ctx, page };
}
async function login(page, email, pass) {
  await page.locator('.auth').waitFor();
  if (!(await page.locator('#au-pass').count()) || (await page.locator('[data-act="authLogin"]').count()) === 0) await tap(page, '[data-act="authMode"][data-m="login"]');
  await page.fill('#au-email', email); await page.fill('#au-pass', pass);
  await tap(page, '[data-act="authLogin"]', 300);
}
async function onboard(page, { age = '41', height = '178', weight = '112', goal = '95' } = {}) {
  await page.locator('.ob-hero').waitFor();
  await tap(page, 'button:has-text("Começar")');
  const name = await page.inputValue('#ob-name');
  await page.fill('#ob-age', age); await page.fill('#ob-height', height); await page.fill('#ob-weight', weight); await page.fill('#ob-goal', goal);
  await tap(page, 'button:has-text("Continuar")');
  await page.selectOption('#ob-activity', 'sedentario'); await page.selectOption('#ob-pref', 'misto');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Pronto")', 400);
  await page.locator('.card-now').waitFor();
  return name;
}

/* ===================== 1. Cadastro, primeiro uso e registros ===================== */
console.log('\n1) Cadastro e primeiro uso (usuária A)');
const A = { email: 'ana@teste.local', pass: 'saude2026', name: 'Ana' };
const B = { email: 'bruno@teste.local', pass: 'forte2026x', name: 'Bruno' };
let aUid, aPhotoPath;
{
  const { ctx, page } = await newApp();
  await page.goto(APP + '?go=agenda');
  await page.locator('.auth').waitFor();
  check(await page.locator('#tabbar').isHidden(), 'sem login: nenhuma tela interna, menu escondido');
  check(/Entrar/.test(await text(page, '.auth-hero .h1')), 'abre na tela de Entrar');
  await shot(page, 'c01-entrar', false);
  await overflow(page, 'Entrar');
  await page.fill('#au-email', A.email); await page.fill('#au-pass', 'qualquer123');
  await tap(page, '[data-act="authLogin"]', 400);
  check(/incorretos/.test(await text(page, '.auth .note.warn')), 'login com conta inexistente: “E-mail ou senha incorretos”');
  await tap(page, '[data-act="authMode"][data-m="signup"]');
  await page.fill('#au-name', A.name); await page.fill('#au-email', A.email); await page.fill('#au-pass', 'abc'); await page.fill('#au-pass2', 'abc');
  await tap(page, '[data-act="authSignup"]');
  check(/8 caracteres/.test(await text(page, '.auth .note.warn')), 'senha curta recusada');
  await page.fill('#au-pass', 'somenteletras'); await page.fill('#au-pass2', 'somenteletras');
  await tap(page, '[data-act="authSignup"]');
  check(/letras e números/.test(await text(page, '.auth .note.warn')), 'senha sem número recusada');
  await page.fill('#au-pass', A.pass); await page.fill('#au-pass2', A.pass + 'x');
  await tap(page, '[data-act="authSignup"]');
  check(/não são iguais/.test(await text(page, '.auth .note.warn')), 'senhas diferentes recusadas');
  await page.fill('#au-pass2', A.pass);
  await tap(page, '[data-act="pwToggle"][data-for="au-pass"]');
  check((await page.getAttribute('#au-pass', 'type')) === 'text', 'mostrar senha');
  await shot(page, 'c02-criar-conta', false);
  await overflow(page, 'Criar conta');
  await tap(page, '[data-act="authSignup"]', 600);
  const obName = await onboard(page);
  check(obName === 'Ana', `cadastro inicial já vem com o nome da conta (${obName})`);
  aUid = await uidOf(A.email);
  check(!!aUid, 'conta criada no banco (auth.users)');
  check((await q('select email_confirmed_at from auth.users where id = $1', [aUid]))[0].email_confirmed_at != null, 'conta criada já confirmada (entra direto)');
  check((await page.locator('.tab').allInnerTexts()).join('|').replace(/\s+/g, '') === 'Hoje|Treino|Alimentação|Evolução|Perfil', 'menu: Hoje, Treino, Alimentação, Evolução, Perfil');
  check(/Ana/.test(await text(page, '.hello h1')), 'Home: saudação com o nome');
  check(/Perder peso|meta 95/.test(await text(page, '.hello')), 'Home: objetivo e meta');
  const hour = Number(new Intl.DateTimeFormat('en-US', { timeZone: 'America/Sao_Paulo', hour: 'numeric', hour12: false }).format(new Date()));
  if (hour < 17) {
    check(await page.locator('[data-s="comecarDia"]').count() === 1, 'botão COMEÇAR O DIA na Home');
    await tap(page, '[data-s="comecarDia"]', 250);
    await page.fill('#sd-bed', '22:40'); await page.fill('#sd-wake', '06:20');
    await tap(page, '#sd-q [data-v="3"]'); await tap(page, '#sd-e [data-v="7"]');
    await shot(page, 'c03-comecar-o-dia', false);
    await tap(page, '[data-act="saveStartDay"]', 300);
    check(await page.locator('.start-done').count() === 1, 'dia começado: sono, energia e 1º copo de água registrados');
  } else {
    // depois das 17 h o botão some; registra direto
    await tap(page, '.water-btns [data-ml="250"]');
    console.log('  · (depois das 17 h: COMEÇAR O DIA testado na etapa de telas)');
  }
  await tap(page, '.water-btns [data-ml="500"]', 200);
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '750', 'água: 750 ml');
  await act(page, { act: 'sheet', s: 'peso' });
  await page.fill('#w-kg', '111,4');
  await tap(page, '[data-act="saveWeight"]', 200);
  await act(page, { act: 'sheet', s: 'medidas' });
  await page.fill('#m-waist', '109'); await page.fill('#m-arm', '37,5'); await page.fill('#m-chest', '116');
  await tap(page, '[data-act="saveMeasures"]', 200);
  await act(page, { act: 'sheet', s: 'sono' });
  await page.fill('#sl-notes', 'acordei 1 vez');
  await tap(page, '[data-act="saveSleep"]', 200);
  await act(page, { act: 'seg', group: 'comida', v: 'intestino' });
  await tap(page, '[data-act="gutSet"][data-f="heartburn"][data-v="2"]', 200);
  await page.fill('#gut-notes', 'azia depois do almoço');
  await page.locator('#gut-notes').blur(); await sleep(200);
  check(await page.locator('[data-act="gutSet"][data-f="heartburn"][data-v="2"][aria-pressed="true"]').count() === 1, 'intestino: azia registrada');
  await shot(page, 'c04-intestino', true);
  await act(page, { act: 'seg', group: 'comida', v: 'marmita' });
  await tap(page, '[data-act="addSugMarmita"][data-i="0"]', 200);
  check(/Frango, arroz e brócolis/.test(await page.locator('#app').innerText()), 'marmita fitness sugerida adicionada');
  await act(page, { act: 'seg', group: 'evolucao', v: 'fotos' });
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.locator('[data-act="photoAdd"][data-pose="frente"]').first().click()]);
  await fc.setFiles(path.join(ROOT, 'test/fixtures/foto-1.jpg'));
  check(await until(() => page.evaluate(() => !!document.querySelector('.photos img[src]'))), 'foto do dia salva e exibida');
  check(await until(async () => (await q(`select name from storage.objects where bucket_id = 'progress-photos' and name like $1`, [aUid + '/%'])).length === 1), 'foto enviada para a pasta privada da conta (Storage)');
  aPhotoPath = ((await q(`select name from storage.objects where bucket_id = 'progress-photos'`))[0] || {}).name;
  await act(page, { act: 'seg', group: 'evolucao', v: 'progresso' });
  check(/resumo da semana/i.test(await page.locator('#app').innerText()) && (await page.locator('#resumo .minibars').count()) === 4, 'Evolução: resumo da semana com 4 gráficos');
  await act(page, { act: 'seg', group: 'sumRange', v: 'mes' });
  check(/resumo do mês/i.test(await page.locator('#app').innerText()) && (await page.locator('#resumo .minibars .b').count()) === 120, 'Evolução: resumo do mês (30 dias em cada gráfico)');
  check(/Braço/.test(await page.locator('#app').innerText()) && /37,5/.test(await page.locator('#app').innerText()), 'Evolução: medidas com braço e peito');
  await shot(page, 'c05-evolucao', true);
  // sincronizou e projetou nas tabelas por assunto
  check(await until(async () => ((await q(`select data from public.app_documents where user_id = $1 and doc_id = $2`, [aUid, monthDoc]))[0] || { data: {} }).data.days?.[todayKey]?.water === 750, 80), 'registros salvos na conta (app_documents)');
  const w = await q('select total_ml from public.water_logs where user_id = $1 and date = $2', [aUid, todayKey]);
  check(w.length === 1 && w[0].total_ml === 750, 'tabela water_logs: 750 ml');
  const m = await q('select weight_kg, arm_cm, chest_cm from public.measurements where user_id = $1 and date = $2', [aUid, todayKey]);
  check(m.length === 1 && Number(m[0].weight_kg) === 111.4 && Number(m[0].arm_cm) === 37.5 && Number(m[0].chest_cm) === 116, 'tabela measurements: peso, braço e peito');
  const g = await q('select heartburn, notes from public.intestinal_logs where user_id = $1', [aUid]);
  check(g.length === 1 && g[0].heartburn === 2 && g[0].notes === 'azia depois do almoço', 'tabela intestinal_logs: azia e observação');
  const sl = await q('select notes from public.sleep_logs where user_id = $1', [aUid]);
  check(sl.length === 1 && sl[0].notes === 'acordei 1 vez', 'tabela sleep_logs: observação do sono');
  const pr = await q('select name, email, activity_level, training_preference from public.profiles where id = $1', [aUid]);
  check(pr[0] && pr[0].email === A.email && pr[0].activity_level === 'sedentario' && pr[0].training_preference === 'misto', 'tabela profiles: e-mail, nível de atividade e preferência de treino');
  check(Number((await q('select count(*) from public.reminders where user_id = $1', [aUid]))[0].count) === 9, 'tabela reminders: 9 lembretes (inclui pesagem e checklist)');
  check(Number((await q('select count(*) from public.progress_photos where user_id = $1', [aUid]))[0].count) === 1, 'tabela progress_photos: 1 foto');

  // fechar e abrir: continua logado
  await page.goto(APP);
  await page.locator('.card-now').waitFor();
  await page.reload();
  await page.locator('.card-now').waitFor();
  check(await page.locator('.auth').count() === 0, 'recarregar: continua logado (sessão persistente)');
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '750', 'recarregar: dados continuam');
  const p2 = await ctx.newPage();
  await p2.goto(APP);
  await p2.locator('.card-now').waitFor();
  check(/Ana/.test(await text(p2, '.hello h1')), 'fechar e abrir de novo: entra direto');
  await p2.close();

  // perfil: e-mail, preferências e sair
  await act(page, { act: 'go', to: 'perfil' });
  check((await page.inputValue('#pf-email')) === A.email, 'Perfil mostra o e-mail da conta');
  await page.selectOption('#pf-activity', 'leve'); await sleep(250);
  check((await page.inputValue('#pf-activity')) === 'leve', 'Perfil: nível de atividade editável');
  await shot(page, 'c06-perfil', true);
  await overflow(page, 'Perfil');
  await tap(page, '[data-act="askLogout"]', 200);
  await Promise.all([page.waitForNavigation().catch(() => {}), tap(page, '.sheet [data-act="doLogout"]', 100)]);
  await page.locator('.auth').waitFor({ timeout: 15000 });
  const ls = await page.evaluate(() => Object.keys(localStorage));
  check(!ls.includes('saudejr-auth'), 'sair: sessão removida do aparelho');
  check(!ls.some((k) => k.startsWith('mv1:data:') && !k.endsWith(':local')), 'sair: cópia local dos dados apagada');
  check(await page.locator('#tabbar').isHidden(), 'sair: volta para a tela de entrar');
  await ctx.close();
}

/* ===================== 2. Outro usuário: dados separados ===================== */
console.log('\n2) Usuário B: cada um só vê os próprios dados');
let bUid;
{
  const { ctx, page } = await newApp();
  await page.goto(APP);
  await page.locator('.auth').waitFor();
  await tap(page, '[data-act="authMode"][data-m="signup"]');
  await page.fill('#au-name', B.name); await page.fill('#au-email', A.email); await page.fill('#au-pass', B.pass); await page.fill('#au-pass2', B.pass);
  await tap(page, '[data-act="authSignup"]', 600);
  check(/já tem conta/.test(await text(page, '.auth .note.warn')), 'cadastro com e-mail já usado: mensagem clara');
  await page.fill('#au-email', B.email); await page.fill('#au-pass', 'bruno2026x'); await page.fill('#au-pass2', 'bruno2026x');
  await tap(page, '[data-act="authSignup"]', 600);
  check(/não pode conter o seu e-mail/.test(await text(page, '.auth .note.warn')), 'senha com o próprio e-mail recusada pelo servidor');
  await page.fill('#au-pass', B.pass); await page.fill('#au-pass2', B.pass);
  await tap(page, '[data-act="authSignup"]', 600);
  await onboard(page, { weight: '98', goal: '85' });
  bUid = await uidOf(B.email);
  check(/Bruno/.test(await text(page, '.hello h1')), 'B vê o próprio nome');
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '0', 'B começa com água zerada (não vê a de A)');
  await act(page, { act: 'seg', group: 'evolucao', v: 'fotos' });
  check((await page.locator('.photos img').count()) === 0, 'B não vê as fotos de A');
  // tentativas diretas pela API, com o token de B (depois que os dados de B já foram para a conta)
  await until(async () => Number((await q('select count(*) from public.app_documents where user_id = $1', [bUid]))[0].count) >= 3, 80);
  const r = await page.evaluate(async ({ a, path: ph, doc }) => {
    const c = window.MVCloud.client;
    const own = await c.from('app_documents').select('user_id,doc_id');
    const other = await c.from('app_documents').select('doc_id').eq('user_id', a);
    const ins = await c.from('app_documents').upsert({ user_id: a, doc_id: 'm-2026-01', data: { hack: true } }, { onConflict: 'user_id,doc_id' });
    await c.from('app_documents').delete().eq('user_id', a);
    const dl = await c.storage.from('progress-photos').download(ph);
    const up = await c.storage.from('progress-photos').upload(a + '/invasao.jpg', new Blob(['x'], { type: 'image/jpeg' }));
    return { ownUsers: [...new Set((own.data || []).map((x) => x.user_id))], other: (other.data || []).length, insErr: !!ins.error, dlErr: !!dl.error, upErr: !!up.error };
  }, { a: aUid, path: aPhotoPath, doc: monthDoc });
  check(r.ownUsers.length === 1 && r.ownUsers[0] === bUid, 'B lista só os próprios documentos');
  check(r.other === 0, 'B não consegue ler documentos de A (RLS)');
  check(r.insErr, 'B não consegue gravar em nome de A (RLS)');
  check(r.dlErr, 'B não consegue baixar a foto de A (Storage privado)');
  check(r.upErr, 'B não consegue enviar foto para a pasta de A');
  check(Number((await q('select count(*) from public.app_documents where user_id = $1', [aUid]))[0].count) >= 3, 'documentos de A continuam intactos no banco');
  await act(page, { act: 'go', to: 'mais' });
  await tap(page, '[data-act="askLogout"]', 200);
  await Promise.all([page.waitForNavigation().catch(() => {}), tap(page, '.sheet [data-act="doLogout"]', 100)]);
  await page.locator('.auth').waitFor({ timeout: 15000 });
  await ctx.close();
}

/* ===================== 3. Outro aparelho: dados vêm da conta ===================== */
console.log('\n3) A entra em outro aparelho');
{
  const { ctx, page } = await newApp();
  await page.goto(APP);
  await login(page, A.email, A.pass);
  await page.locator('.card-now').waitFor();
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '750', 'dados de A voltam da conta em outro aparelho');
  await act(page, { act: 'seg', group: 'evolucao', v: 'fotos' });
  check(await until(() => page.evaluate(() => { const i = document.querySelector('.photos img'); return !!(i && i.src && i.naturalWidth > 0); })), 'foto baixada da conta e exibida');
  await ctx.close();
}

/* ===================== 4. Recuperação de senha ===================== */
console.log('\n4) Esqueci a senha');
{
  const { ctx, page } = await newApp();
  await page.goto(APP);
  await page.locator('.auth').waitFor();
  await tap(page, '[data-act="authMode"][data-m="forgot"]');
  await page.fill('#au-email', A.email);
  await tap(page, '[data-act="authForgot"]', 400);
  check(/link chega/.test(await text(page, '.auth .note.go')), 'pedido de recuperação enviado');
  await shot(page, 'c07-recuperar', true);
  await overflow(page, 'Recuperar senha');
  const link = sb.lastLink(A.email);
  check(!!link, 'e-mail de recuperação gerado');
  await page.fill('#au-link', link);
  await tap(page, '[data-act="authRecover"]', 600);
  await page.locator('#au-pass2').waitFor();
  check(/Nova senha/.test(await text(page, '.auth-hero .h1')), 'link colado abre a tela de nova senha');
  await page.fill('#au-pass', 'novaSenha9'); await page.fill('#au-pass2', 'novaSenha9');
  await tap(page, '[data-act="authNewPass"]', 500);
  await page.locator('.card-now').waitFor();
  check(/Ana/.test(await text(page, '.hello h1')), 'senha nova salva e já dentro da conta');
  await act(page, { act: 'go', to: 'mais' });
  await tap(page, '[data-act="askLogout"]', 200);
  await Promise.all([page.waitForNavigation().catch(() => {}), tap(page, '.sheet [data-act="doLogout"]', 100)]);
  await login(page, A.email, A.pass);
  check(/incorretos/.test(await text(page, '.auth .note.warn')), 'senha antiga não funciona mais');
  await page.fill('#au-pass', 'novaSenha9');
  await tap(page, '[data-act="authLogin"]', 500);
  await page.locator('.card-now').waitFor({ timeout: 10000 }).catch(() => {});
  check((await page.locator('.card-now').count()) === 1, 'entra com a senha nova');
  await ctx.close();
  // link aberto direto (quando o Supabase estiver com o endereço do app configurado)
  const c2 = await newApp();
  await c2.page.goto(APP);
  await c2.page.locator('.auth').waitFor();
  await c2.page.evaluate(({ url, email }) => fetch(url + '/auth/v1/recover?redirect_to=' + encodeURIComponent(location.href.split('#')[0]), { method: 'POST', headers: { apikey: 'x', 'content-type': 'application/json' }, body: JSON.stringify({ email }) }), { url: sb.url, email: A.email });
  await c2.page.goto(sb.lastLink(A.email));
  await c2.page.locator('#au-pass2').waitFor({ timeout: 10000 });
  check(/Nova senha/.test(await text(c2.page, '.auth-hero .h1')), 'link do e-mail aberto no celular leva direto à nova senha');
  await c2.page.fill('#au-pass', 'terceira7'); await c2.page.fill('#au-pass2', 'terceira7');
  await tap(c2.page, '[data-act="authNewPass"]', 500);
  await c2.page.locator('.card-now').waitFor();
  check(!(await c2.page.evaluate(() => location.hash)), 'endereço limpo depois de usar o link');
  A.pass = 'terceira7';
  // trocar senha logado
  await act(c2.page, { act: 'go', to: 'perfil' });
  await tap(c2.page, '[data-act="changePass"]', 200);
  await c2.page.fill('#np-1', 'quarta2026'); await c2.page.fill('#np-2', 'quarta2026');
  await tap(c2.page, '#np-save', 500);
  check(await c2.page.locator('.sheet').count() === 0 || await c2.page.locator('#sheet').isHidden(), 'trocar senha no perfil');
  A.pass = 'quarta2026';
  await c2.ctx.close();
}

/* ===================== 5. Sem internet ===================== */
console.log('\n5) Sem internet');
{
  const { ctx, page } = await newApp();
  await page.goto(APP);
  await login(page, A.email, A.pass);
  await page.locator('.card-now').waitFor();
  await page.evaluate(() => navigator.serviceWorker.ready);
  await sleep(300);
  await ctx.setOffline(true);
  await page.reload();
  await page.locator('.card-now').waitFor({ timeout: 10000 }).catch(() => {});
  check((await page.locator('.card-now').count()) === 1, 'abre sem internet (app e dados guardados no aparelho)');
  await tap(page, '.water-btns [data-ml="250"]', 200);
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '1.000', 'registra sem internet (1.000 ml)');
  await ctx.setOffline(false);
  await page.evaluate(() => window.dispatchEvent(new Event('online')));
  check(await until(async () => ((await q(`select data from public.app_documents where user_id = $1 and doc_id = $2`, [aUid, monthDoc]))[0] || { data: {} }).data.days?.[todayKey]?.water === 1000, 150), 'internet de volta: registro enviado para a conta');
  await ctx.close();
}

/* ===================== 6. Telas de Android: 360, 390, 412 e 430 px ===================== */
console.log('\n6) Telas de 360 a 430 px');
for (const width of [360, 390, 412, 430]) {
  const { ctx, page } = await newApp({ viewport: { width, height: 820 }, screen: { width, height: 820 } });
  await page.goto(APP);
  await page.locator('.auth').waitFor();
  const bad = [];
  const m0 = async (label) => { const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth })); if (m.sw > m.cw + 1) bad.push(`${label} ${m.sw}/${m.cw}`); };
  for (const mode of ['login', 'signup', 'forgot']) { await act(page, { act: 'authMode', m: mode }); await m0('conta:' + mode); }
  await act(page, { act: 'authMode', m: 'login' });
  await login(page, A.email, A.pass);
  await page.locator('.card-now').waitFor();
  const routes = [{ act: 'go', to: 'home' }, { act: 'seg', group: 'treino', v: 'academia' }, { act: 'seg', group: 'treino', v: 'corrida' }, { act: 'go', to: 'agenda' },
    { act: 'seg', group: 'comida', v: 'refeicoes' }, { act: 'seg', group: 'comida', v: 'marmita' }, { act: 'seg', group: 'comida', v: 'intestino' }, { act: 'seg', group: 'comida', v: 'suplementos' },
    { act: 'seg', group: 'evolucao', v: 'progresso' }, { act: 'seg', group: 'evolucao', v: 'fotos' }, { act: 'seg', group: 'evolucao', v: 'meta' },
    { act: 'go', to: 'mais' }, { act: 'go', to: 'perfil' }, { act: 'go', to: 'lembretes' }, { act: 'go', to: 'sono' }, { act: 'go', to: 'hormonal' }, { act: 'go', to: 'seguranca' }, { act: 'go', to: 'instalar' }, { act: 'go', to: 'privacidade' }];
  for (const r of routes) { await act(page, r, 120); await m0(r.to || r.v); }
  for (const s of ['comecarDia', 'medidas', 'sono', 'senha', 'peso', 'cardio', 'energia']) {
    await act(page, { act: 'sheet', s }, 150);
    const m = await page.evaluate(() => { const sh = document.querySelector('.sheet'); return sh ? { sw: sh.scrollWidth, cw: sh.clientWidth } : { sw: 0, cw: 0 }; });
    if (m.sw > m.cw + 1) bad.push(`folha ${s} ${m.sw}/${m.cw}`);
    if (width === 360 && s === 'comecarDia') await shot(page, 'c08-comecar-dia-360', false);
    await act(page, { act: 'closeSheet' });
  }
  // botões grandes para o dedo: nada clicável menor que 40 px de altura na Home
  await act(page, { act: 'go', to: 'home' });
  const small = await page.evaluate(() => [...document.querySelectorAll('#app button, #tabbar button')].filter((b) => { const r = b.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.height < 40 && !b.classList.contains('link-btn') && !b.classList.contains('chip'); }).map((b) => (b.innerText || b.getAttribute('aria-label') || '').trim().slice(0, 20)));
  check(!small.length, `${width} px: botões com altura confortável${small.length ? ' — pequenos: ' + small.join(', ') : ''}`);
  if (width === 360) { await shot(page, 'c09-home-360', true); await act(page, { act: 'go', to: 'perfil' }); await shot(page, 'c10-perfil-360', false); }
  if (width === 412) { await shot(page, 'c11-home-412', false); }
  check(!bad.length, `${width} px sem rolagem lateral e nada cortado${bad.length ? ': ' + bad.join(', ') : ''}`);
  await ctx.close();
}

/* ===================== 7. Instalação (PWA) ===================== */
console.log('\n7) App instalável');
{
  const { ctx, page } = await newApp();
  await page.goto(APP);
  await page.locator('.auth').waitFor();
  const man = await page.evaluate(async () => { const l = document.querySelector('link[rel=manifest]'); return (await fetch(l.href)).json(); });
  check(man.name === 'Saúde Jr.' && man.display === 'standalone' && man.start_url === './' && man.icons.some((i) => i.purpose === 'maskable'), 'manifesto: nome, tela cheia, início e ícone maskable');
  check(await page.evaluate(async () => !!(await navigator.serviceWorker.ready).active), 'service worker ativo');
  check(await page.evaluate(() => !!document.querySelector('meta[http-equiv="Content-Security-Policy"]')), 'política de segurança de conteúdo (CSP) ativa');
  const html = fs.readFileSync(path.join(ROOT, 'dist/pwa-e2e/index.html'), 'utf8');
  check(!/sb_publishable_|sb_secret_|service_role|eyJhbGciOi/.test(html), 'nenhuma chave dentro do código publicado');
  check((html.match(/[\w.%+-]+@[\w.-]+\.[a-z]{2,}/gi) || []).every((e) => e === 'voce@email.com'), 'nenhum e-mail pessoal no código publicado (só o exemplo voce@email.com)');
  await ctx.close();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'saude-jr-perfil-'));
  const pctx = await chromium.launchPersistentContext(dir, { channel: 'chromium', ...devices['Pixel 7'] }).catch(() => chromium.launchPersistentContext(dir, { ...devices['Pixel 7'] }));
  const pp = pctx.pages()[0] || await pctx.newPage();
  await pp.goto(APP);
  await pp.evaluate(() => navigator.serviceWorker.ready);
  await pp.reload(); await pp.locator('.auth').waitFor();
  const cdp = await pctx.newCDPSession(pp);
  const inst = await cdp.send('Page.getInstallabilityErrors');
  check(inst.installabilityErrors.length === 0, 'Chrome considera o app instalável' + (inst.installabilityErrors.length ? ': ' + JSON.stringify(inst.installabilityErrors) : ''));
  await pctx.close();
}

/* ===================== 8. Servidor: limites e acesso anônimo ===================== */
console.log('\n8) Servidor');
{
  const post = (email, ip) => fetch(sb.url + '/functions/v1/app/signup', { method: 'POST', headers: { 'content-type': 'application/json', 'x-test-ip': ip }, body: JSON.stringify({ email, password: 'limite2026', name: 'X' }) });
  const codes = [];
  for (let i = 0; i < 6; i++) codes.push((await post(`lim${i}@teste.local`, '10.9.9.9')).status);
  check(codes.slice(0, 5).every((c) => c === 201) && codes[5] === 429, `limite de cadastros por origem (${codes.join(',')})`);
  const anon = await fetch(sb.url + '/rest/v1/app_documents?select=*', { headers: { apikey: sb.key } });
  check(anon.status === 401, 'sem login: API recusa ler dados (401)');
  const cfg = await (await fetch(sb.url + '/functions/v1/app/config')).json();
  check(cfg.key === sb.key && Object.keys(cfg).length === 2, 'config pública entrega só a chave publicável');
}

check(allErrors.length === 0, 'sem erros no console: ' + allErrors.slice(0, 5).join(' | '));
await browser.close();
server.close();
await sb.close();
await dropDatabase(DBNAME);
console.log(`\n${problems.length ? 'FALHAS: ' + problems.length : 'Tudo certo.'}`);
process.exit(problems.length ? 1 : 0);
