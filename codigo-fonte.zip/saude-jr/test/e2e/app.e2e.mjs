// Teste de ponta a ponta no Chromium com tela de celular.
import { createRequire } from 'module';
import fs from 'fs';
import http from 'http';
import path from 'path';
import os from 'os';
import assert from 'assert/strict';
const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); } catch (e) { playwright = require('/home/claude/.npm-global/lib/node_modules/playwright'); }
const { chromium, devices } = playwright;

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '..');
const SHOTS = process.env.SHOTS || path.join(os.tmpdir(), 'saude-jr-shots');
fs.mkdirSync(SHOTS, { recursive: true });
const b64 = (p) => fs.readFileSync(path.join(ROOT, p)).toString('base64');
// fontes do próprio projeto (as mesmas do app instalável), para as telas saírem iguais em qualquer máquina
const fontCss = `
@font-face{font-family:"Archivo";font-style:normal;font-display:block;font-weight:100 900;font-stretch:62% 125%;src:url(data:font/woff2;base64,${b64('public/fonts/archivo.woff2')}) format("woff2");}
@font-face{font-family:"Figtree";font-style:normal;font-display:block;font-weight:300 900;src:url(data:font/woff2;base64,${b64('public/fonts/figtree.woff2')}) format("woff2");}`;

// servidor estático local
const server = http.createServer((req, res) => {
  const f = path.join(ROOT, 'dist', 'claude', decodeURIComponent(req.url.split('?')[0]));
  if (!f.startsWith(path.join(ROOT, 'dist')) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(8765, r));
const URL_ = 'http://127.0.0.1:8765/harness.html';

const problems = [];
const check = (cond, msg) => { if (!cond) { problems.push(msg); console.log('  ✗ ' + msg); } else console.log('  ✓ ' + msg); };

function fakeClaude({ key, owner }) {
  const load = () => { try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch (e) { return {}; } };
  const persist = (d) => localStorage.setItem(key, JSON.stringify(d));
  const listeners = [];
  const snap = (p, data, pending) => ({ id: p.split('/').pop(), exists: data !== undefined, data: () => (data === undefined ? undefined : JSON.parse(JSON.stringify(data))), metadata: { fromCache: false, hasPendingWrites: !!pending } });
  const notify = (p, removed) => { const d = load(); for (const l of listeners) if (p.startsWith(l.path + '/')) l.next({ docs: [], size: 0, empty: true, metadata: {}, docChanges: () => [{ type: removed ? 'removed' : 'modified', doc: snap(p, removed ? undefined : d[p]) }] }); };
  window.__fakeWrites = 0;
  const db = {
    doc(p) {
      return {
        id: p.split('/').pop(), path: p,
        async get() { return snap(p, load()[p]); },
        async set(data) { if (window.__fakeFail) throw { code: 'unavailable', message: 'simulado' }; const d = load(); d[p] = JSON.parse(JSON.stringify(data)); persist(d); window.__fakeWrites++; notify(p); },
        async update(data) { const d = load(); d[p] = Object.assign({}, d[p], data); persist(d); notify(p); },
        async delete() { const d = load(); delete d[p]; persist(d); notify(p, true); },
      };
    },
    collection(cp) {
      return {
        path: cp,
        async get() {
          if (window.__fakeFail) throw { code: 'unavailable', message: 'simulado' };
          const d = load(), depth = cp.split('/').length + 1;
          const docs = Object.keys(d).filter((p) => p.startsWith(cp + '/') && p.split('/').length === depth).sort().map((p) => snap(p, d[p]));
          return { docs, size: docs.length, empty: !docs.length, metadata: {}, docChanges: () => docs.map((doc) => ({ type: 'added', doc })) };
        },
        onSnapshot(next) { listeners.push({ path: cp, next }); return () => {}; },
      };
    },
  };
  window.__fakeRemoteEdit = (p, fn) => { const d = load(); fn(d[p]); d[p].updatedAt = Date.now() + 5000; persist(d); notify(p); };
  const me = { id: 'u_test', name: 'Carlos Teste', avatarUrl: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2244%22 height=%2244%22%3E%3Crect width=%2244%22 height=%2244%22 fill=%22%232fe070%22/%3E%3C/svg%3E', color: '#2fe070', email: null, isOwner: owner, canEdit: true };
  const user = { id: async () => 'u_test', isOwner: async () => owner, canEdit: async () => true, can: async () => true, me: async () => me, profiles: async () => ({}), name: async () => me.name };
  const downloads = { save: async ({ filename, data }) => { window.__downloads = (window.__downloads || []).concat({ filename, size: String(data).length }); return { status: 'saved' }; } };
  window.claude = { use: async (n) => (n === 'db' ? db : n === 'user' ? user : n === 'downloads' ? downloads : null) };
}

const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' }).catch(() => chromium.launch());
async function open({ time, cloud, owner = true, seed, fakeKey = '__fakedb' } = {}) {
  const ctx = await browser.newContext({ ...devices['iPhone 13'], timezoneId: 'America/Sao_Paulo', locale: 'pt-BR' });
  await ctx.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: fontCss }));
  await ctx.route('https://fonts.gstatic.com/**', (r) => r.abort());
  if (seed) await ctx.addInitScript((s) => { if (!localStorage.getItem('mv1:seeded')) { localStorage.setItem('mv1:data:local', s); localStorage.setItem('mv1:seeded', '1'); } }, JSON.stringify(seed));
  if (cloud) await ctx.addInitScript(fakeClaude, { key: fakeKey, owner });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.gstatic|ERR_FAILED/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.clock.install({ time: new Date(time || '2026-09-28T18:05:00-03:00') });
  await page.goto(URL_);
  await page.clock.runFor(500);
  return { ctx, page, errors };
}
const shot = (page, name, full = true) => page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: full });
async function overflow(page, label) {
  const r = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  check(r.sw <= r.cw + 1, `sem rolagem lateral em ${label} (${r.sw}/${r.cw})`);
}
const text = (page, sel) => page.locator(sel).first().innerText();
async function tap(page, sel) { await page.locator(sel).first().click(); await page.clock.runFor(50); }

/* ===================== 1. Fluxo completo, modo local ===================== */
console.log('\n1) Primeiro uso e rotina completa (modo local)');
{
  const { ctx, page, errors } = await open();
  await page.getByRole('button', { name: 'Começar' }).waitFor();
  await shot(page, '01-boas-vindas', false);
  await tap(page, 'button:has-text("Começar")');
  await page.fill('#ob-name', 'Carlos');
  check((await page.inputValue('#ob-weight')) === '', 'cadastro começa sem dados pessoais no código');
  await page.fill('#ob-age', '41'); await page.fill('#ob-height', '178'); await page.fill('#ob-weight', '112');
  await shot(page, '02-perfil', false);
  await page.fill('#ob-goal', '130');
  await tap(page, 'button:has-text("Continuar")');
  check(await page.locator('#ob-name').count() === 1, 'valida meta maior que o peso (continua no passo 1)');
  await page.fill('#ob-goal', '90');
  await page.fill('#ob-waist', '109');
  await tap(page, 'button:has-text("Continuar")');
  await page.locator('#ob-train').waitFor();
  await shot(page, '03-rotina', false);
  await tap(page, 'button:has-text("Continuar")');
  await page.getByRole('button', { name: 'Pronto' }).waitFor();
  await shot(page, '04-seguranca', true);
  await tap(page, 'button:has-text("Pronto")');
  await page.locator('.card-now').waitFor();
  const now = await text(page, '.card-now .now-title');
  check(/Hora do Treino A/.test(now), `AGORA mostra o treino na segunda às 18:05 (“${now}”)`);
  check(/Bom dia|Boa tarde|Boa noite/.test(await text(page, '.hello h1')) && (await text(page, '.hello h1')).includes('Carlos'), 'saudação com nome');
  await shot(page, '05-home', true);
  await overflow(page, 'Hoje');

  await tap(page, '.water-btns [data-ml="500"]');
  check((await text(page, '.water-btns')).length > 0 && (await page.locator('text=500').count()) > 0, '+500 ml registra com 1 toque');
  await tap(page, '.water-btns [data-act="waterUndo"]');
  await tap(page, '.water-btns [data-ml="750"]');
  const waterNow = await page.locator('section.card:has(.water-btns) .num').first().innerText();
  check(waterNow.trim() === '750', `desfazer e somar água (${waterNow})`);

  await tap(page, 'button.tile[data-s="peso"]');
  await page.fill('#w-kg', '111,4');
  await tap(page, '[data-act="saveWeight"]');
  check((await text(page, 'button.tile[data-s="peso"] .num')).startsWith('111,4'), 'peso salvo e tendência atualizada');

  await tap(page, '.card-now [data-act="startSession"]');
  await page.locator('.sess-top').waitFor();
  check((await page.locator('.ex').count()) === 7, 'treino A: aquecimento + 6 exercícios');
  await tap(page, '.ex.open [data-act="exLoad"][data-d="1"]');
  await tap(page, '.ex.open [data-act="exLoad"][data-d="1"]');
  check((await page.inputValue('#load0')) === '20', 'carga do leg press sobe de 10 em 10');
  await tap(page, '.ex.open .set-done >> nth=0');
  check(await page.locator('#restbar').isVisible(), 'descanso começa depois da série');
  await shot(page, '06-sessao', false);
  await page.clock.runFor(91000);
  check(!(await page.locator('#restbar').isVisible()), 'descanso termina sozinho em 90 s');
  await tap(page, '.ex.open .set-done >> nth=1');
  await tap(page, '.ex.open [data-act="exDiff"][data-v="2"]');
  await tap(page, '.ex.open [data-act="exDone"]');
  await tap(page, '[data-act="restSkip"]');
  const open2 = await text(page, '.ex.open .ex-title');
  check(open2 === 'Puxada frontal', `abre o próximo exercício (${open2})`);
  await tap(page, '.ex.open [data-s="trocar"]');
  await tap(page, '[data-act="swapEx"][data-ex="remada_maq"]');
  check((await text(page, '.ex.open .ex-title')) === 'Remada sentada na máquina', 'troca de exercício');
  await shot(page, '07-sessao-troca', true);
  await tap(page, '.sess-top [data-act="sessFinishAsk"]');
  await tap(page, '.sheet [data-act="sessFinish"]');
  await page.locator('text=Treino concluído').waitFor();
  const fim = await page.locator('#app').innerText();
  check(/Leg press 45°\s+30 kg ↑/.test(fim), 'progressão: leg press vai para 30 kg no próximo treino');
  await shot(page, '08-fim', true);
  await tap(page, '[data-act="finishDone"]');
  check(/concluído/.test(await page.locator('#app').innerText()), 'Home mostra treino concluído');
  const pct = await text(page, '#hoje .h2');
  check(/Dia concluído: 13%/.test(pct), `checklist marca treino sozinho (${pct})`);

  await tap(page, '.tab[data-to="treino"]');
  await shot(page, '09-treino', true);
  await overflow(page, 'Treino');
  check((await text(page, '.card .h2 >> nth=0')).length > 0 && (await page.locator('text=Treino B').count()) > 0, 'próximo treino é o B');
  await tap(page, '[data-act="sheet"][data-s="cardio"]');
  await tap(page, '[data-act="pick"][data-v="esteira"]');
  await page.fill('#cd-min', '30');
  await page.fill('#cd-km', '2,5');
  await page.locator('#cd-km').dispatchEvent('input');
  const ph = await page.getAttribute('#cd-kcal', 'placeholder');
  check(/kcal/.test(ph), `estimativa de calorias (${ph})`);
  await tap(page, '[data-act="saveCardio"]');
  check((await page.locator('text=Esteira').count()) > 0, 'cardio aparece no histórico');

  await tap(page, '.tab[data-to="comida"]');
  await tap(page, '[data-act="meal"][data-m="cafe"][data-v="ok"]');
  await shot(page, '10-comida', true);
  await overflow(page, 'Comida');
  await tap(page, '[data-act="seg"][data-v="marmita"]');
  await tap(page, '[data-act="sheet"][data-s="marmita"]');
  await page.fill('#mm-name', 'Frango com legumes');
  await page.selectOption('#mm-p-f', 'frango'); await page.fill('#mm-p-g', '150');
  await page.selectOption('#mm-c-f', 'arroz'); await page.fill('#mm-c-g', '100');
  await page.selectOption('#mm-v-f', 'brocolis'); await page.fill('#mm-v-g', '150');
  await page.locator('#mm-v-g').dispatchEvent('input');
  check(/410 kcal/.test(await text(page, '#mm-prev')), 'prévia da marmita: ≈ 410 kcal');
  await shot(page, '11-marmita-form', false);
  await tap(page, '[data-act="saveMarmita"]');
  await tap(page, 'button.chip[data-act="dinner"]');
  const mcard = await page.locator('#app').innerText();
  check(/Equilibrada/.test(mcard) && /53/.test(mcard), 'marmita equilibrada, 53 g de proteína');
  await shot(page, '12-marmita', true);
  await tap(page, '[data-act="seg"][data-v="intestino"]');
  for (let i = 0; i < 3; i++) await tap(page, '[data-act="gut"][data-f="fiber"][data-d="1"]');
  for (let i = 0; i < 2; i++) { await tap(page, '[data-act="gut"][data-f="fruits"][data-d="1"]'); await tap(page, '[data-act="gut"][data-f="veg"][data-d="1"]'); }
  await tap(page, '[data-act="gutSet"][data-f="bm"][data-v="1"]');
  await tap(page, '[data-act="gutSet"][data-f="form"][data-v="normal"]');
  await shot(page, '13-intestino', true);
  await tap(page, '[data-act="gutFlag"][data-f="blood"]');
  check((await page.locator('.card-alert').count()) === 1, 'sangue nas fezes → recomenda avaliação médica');
  await tap(page, '[data-act="gutFlag"][data-f="blood"]');

  await tap(page, '.tab[data-to="home"]');
  const pct2 = await text(page, '#hoje .h2');
  check(/Dia concluído: 38%/.test(pct2), `fibras e frutas/vegetais marcam sozinhos (${pct2})`);

  await tap(page, '.tab[data-to="evolucao"]');
  await shot(page, '14-evolucao', true);
  await overflow(page, 'Evolução');
  await tap(page, '[data-act="seg"][data-v="meta"]');
  const hasGoalPhotos = fs.existsSync(path.join(ROOT, 'private/before.jpg'));
  if (hasGoalPhotos) { await page.locator('.pair img').first().waitFor(); check((await page.locator('.pair img').count()) === 2, 'fotos da meta aparecem'); }
  else check((await page.locator('[data-act="photoAdd"][data-pose="inicio"]').count()) >= 1, 'sem fotos-meta: convite para foto de início');
  await shot(page, '15-meta', true);
  await overflow(page, 'Minha meta');
  if (hasGoalPhotos) {
    await tap(page, '[data-act="sheet"][data-s="compare"]');
    await page.locator('#cmp').waitFor();
    await page.fill('#cmp-r', '30');
    await page.locator('#cmp-r').dispatchEvent('input');
    await page.clock.runFor(400);
    await shot(page, '16-comparar', false);
    await tap(page, '.sheet-head [data-act="closeSheet"]');
  }

  await tap(page, '.tab[data-to="mais"]');
  await tap(page, '[data-act="go"][data-to="sono"]');
  await tap(page, '[data-act="sheet"][data-s="sono"]');
  await page.fill('#sl-bed', '23:00'); await page.fill('#sl-wake', '06:30');
  await page.locator('#sl-wake').dispatchEvent('input');
  check((await text(page, '#sl-h')) === '7,5 h', 'duração do sono calculada');
  await tap(page, '#sl-q [data-v="3"]'); await tap(page, '#sl-e [data-v="7"]');
  await tap(page, '[data-act="saveSleep"]');
  await shot(page, '17-sono', true);
  await tap(page, '.top .back');
  await tap(page, '[data-act="go"][data-to="hormonal"]');
  await tap(page, '[data-act="alcohol"][data-v="0"]'); await tap(page, '[data-act="stress"][data-v="2"]');
  await shot(page, '18-hormonal', true);
  await overflow(page, 'Saúde hormonal');
  await tap(page, '.top .back');
  await tap(page, '[data-act="go"][data-to="lembretes"]');
  await tap(page, '[data-act="testReminder"]');
  check(await page.locator('#alertbar').isVisible(), 'lembrete aparece com frase');
  await page.clock.runFor(400);
  await shot(page, '19-lembretes', false);
  await tap(page, '[data-act="alertClose"]');
  await tap(page, '.top .back');
  await tap(page, '[data-act="go"][data-to="perfil"]');
  await page.fill('#pf-water', '3500');
  await page.locator('#pf-water').dispatchEvent('change');
  await page.clock.runFor(100);
  await shot(page, '20-perfil', true);
  await overflow(page, 'Perfil');
  await tap(page, '.top .back');
  await tap(page, '[data-act="go"][data-to="seguranca"]');
  await overflow(page, 'Segurança');
  await tap(page, '.tab[data-to="home"]');
  check(/3\.500/.test(await page.locator('section.card:has(.water-btns)').innerText()), 'meta de água ajustada aparece na Home');

  // reabrir: dados continuam
  await page.reload();
  await page.clock.runFor(500);
  await page.locator('.card-now').waitFor();
  const w2 = await page.locator('section.card:has(.water-btns) .num').first().innerText();
  check(w2.trim() === '750', 'dados continuam depois de reabrir');
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}

/* ===================== 2. Histórico de 6 semanas ===================== */
console.log('\n2) Seis semanas de histórico: tendência, sequência e projeção');
{
  const L = require(path.join(ROOT, 'src/lib/logic.js'));
  const start = '2026-08-17', today = '2026-09-28';
  const docs = { profile: { name: 'Carlos', age: 41, height: 178, startWeight: 112, goalWeight: 90, trainDays: [1, 3, 5], trainTime: '18:30', wakeTime: '06:30', bedTime: '22:30', waterGoal: 3000, stepsGoal: 6000, onboarded: true, startDate: start, safety: { answers: {}, flag: false }, updatedAt: 1 }, core: { choice: {}, ex: { legpress: { load: 60, first: 30, best: 60 }, supino_maq: { load: 30, first: 20, best: 30 } }, marmitas: [], marks: {}, photos: [], updatedAt: 1 } };
  let n = 0;
  for (let k = start; k < today; k = L.addDays(k, 1), n++) {
    const id = 'm-' + k.slice(0, 7);
    docs[id] = docs[id] || { days: {}, weights: [], measures: [], sessions: [], cardio: [], updatedAt: 1 };
    const m = docs[id];
    m.days[k] = { water: 3000, steps: 6500, sleep: { bed: '23:00', wake: '06:30', hours: 7.5, quality: 3, energy: 6 }, gut: { fiber: 3, fruits: 2, veg: 2 } };
    if (n % 3 === 0 || n === 0) m.weights.push({ date: k, kg: Math.round((112 - n * 0.13 + ((n * 7) % 5) * 0.12 - 0.24) * 10) / 10, at: n });
    if (n % 14 === 0) m.measures.push({ date: k, waist: 109 - n * 0.15, at: n });
    const wd = L.weekday(k);
    if ([1, 3, 5].includes(wd)) m.sessions.push({ id: 's' + n, date: k, type: n % 2 ? 'B' : 'A', week: 1, phase: 1, startedAt: n * 1e6, finishedAt: n * 1e6 + 2.7e6, completed: true, warmupDone: true, items: [{ exId: 'legpress', kind: 'reps', sets: [{ done: true, reps: 12 }], load: 50, target: [10, 12], inc: 10, done: true }] });
    else m.cardio.push({ id: 'c' + n, date: k, kind: 'caminhada', minutes: 30, rpe: 4, kcal: 200, at: n });
  }
  const { ctx, page, errors } = await open({ seed: { docs, dirty: [] } });
  await page.locator('.card-now').waitFor();
  const streak = await text(page, 'button.tile[data-to="evolucao"] .num');
  check(/^42/.test(streak.trim()), `sequência de 42 dias (${streak.trim()})`);
  await shot(page, '21-home-historico', true);
  await tap(page, '.tab[data-to="evolucao"]');
  check((await page.locator('svg.chart path.trend').count()) === 1, 'gráfico de tendência desenhado');
  const rate = await page.locator('#app').innerText();
  check(/−0,9 kg\/sem|−1,0 kg\/sem|−0,8 kg\/sem/.test(rate), 'ritmo semanal calculado');
  await shot(page, '22-evolucao-historico', true);
  await tap(page, '[data-act="seg"][data-v="meta"]');
  const meta = await page.locator('#app').innerText();
  check(/Seu ritmo real/.test(meta), 'meta mostra previsão pelo ritmo real');
  check(/Dobrar a carga inicial no leg press/.test(meta), 'marco de força listado');
  check((await page.locator('.check[data-id="legdouble"][aria-pressed="true"]').count()) === 1, 'marco automático: dobrou a carga no leg press');
  await shot(page, '23-meta-historico', true);
  await tap(page, '[data-act="seg"][data-v="progresso"]');
  await tap(page, '[data-act="seg"][data-group="range"][data-v="all"]');
  await overflow(page, 'Evolução (tudo)');
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}

/* ===================== 3. Conta e sincronização ===================== */
console.log('\n3) Dados na conta: salvar, reabrir em outro aparelho, falha de rede');
{
  const { ctx, page, errors } = await open({ cloud: true, fakeKey: '__fakedbA' });
  await page.getByRole('button', { name: 'Começar' }).waitFor();
  await tap(page, 'button:has-text("Começar")');
  check((await page.inputValue('#ob-name')) === 'Carlos', 'nome vem da conta');
  await page.fill('#ob-age', '41'); await page.fill('#ob-height', '178'); await page.fill('#ob-weight', '112'); await page.fill('#ob-goal', '90');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Pronto")');
  await tap(page, '.water-btns [data-ml="250"]');
  await page.clock.runFor(1500);
  const cloudDocs = await page.evaluate(() => Object.keys(JSON.parse(localStorage.getItem('__fakedbA') || '{}')));
  check(['data/users/u_test/profile', 'data/users/u_test/core', 'data/users/u_test/m-2026-09'].every((p) => cloudDocs.includes(p)), 'documentos na área privada do usuário: ' + cloudDocs.join(', '));
  check((await text(page, '#syncLabel')) === 'Salvo', 'status “Salvo”');
  // falha de rede e recuperação
  await page.evaluate(() => { window.__fakeFail = true; });
  await tap(page, '.water-btns [data-ml="250"]');
  await page.clock.runFor(1500);
  const st1 = await text(page, '#syncLabel');
  check(/Offline|Sem sincronizar/.test(st1), `mostra falha de sincronização (${st1})`);
  await page.evaluate(() => { window.__fakeFail = false; });
  await page.clock.runFor(4000);
  check((await text(page, '#syncLabel')) === 'Salvo', 'sincroniza sozinho quando a conexão volta');
  const water = await page.evaluate(() => JSON.parse(localStorage.getItem('__fakedbA'))['data/users/u_test/m-2026-09'].days['2026-09-28'].water);
  check(water === 500, `água sincronizada na conta (${water} ml)`);
  // mudança vinda de outro aparelho
  await page.evaluate(() => window.__fakeRemoteEdit('data/users/u_test/m-2026-09', (d) => { d.days['2026-09-28'].water = 1500; }));
  await page.clock.runFor(200);
  const w3 = await page.locator('section.card:has(.water-btns) .num').first().innerText();
  check(w3.trim() === '1.500', `atualiza com dado de outro aparelho (${w3.trim()})`);
  // "outro aparelho": apaga a cópia local e reabre
  await page.evaluate(() => { Object.keys(localStorage).filter((k) => k.startsWith('mv1:')).forEach((k) => localStorage.removeItem(k)); });
  await page.reload();
  await page.clock.runFor(800);
  await page.locator('.card-now').waitFor();
  check((await text(page, '.hello h1')).includes('Carlos'), 'reabre com dados da conta, sem cópia local');
  await tap(page, '.tab[data-to="mais"]');
  await tap(page, '[data-act="go"][data-to="perfil"]');
  check((await text(page, '#meName')) === 'Carlos Teste', 'perfil mostra a conta');
  await tap(page, '[data-act="exportJson"]');
  await page.clock.runFor(100);
  const dl = await page.evaluate(() => window.__downloads || []);
  check(dl.length === 1 && /saude-jr-backup-2026-09-28\.json/.test(dl[0].filename), 'backup gera arquivo');
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}
{
  const { ctx, page, errors } = await open({ cloud: true, owner: false, fakeKey: '__fakedbB' });
  await page.getByRole('button', { name: 'Começar' }).waitFor();
  await tap(page, 'button:has-text("Começar")');
  await page.fill('#ob-age', '41'); await page.fill('#ob-height', '178'); await page.fill('#ob-weight', '112'); await page.fill('#ob-goal', '90');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Pronto")');
  await tap(page, '.tab[data-to="evolucao"]');
  await tap(page, '[data-act="seg"][data-v="meta"]');
  check((await page.locator('.pair img').count()) === 0, 'foto-meta não aparece para quem não é o dono');
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}

/* ===================== 4. Horários do dia ===================== */
console.log('\n4) Card AGORA ao longo do dia');
for (const [time, re] of [['2026-09-29T07:10:00-03:00', /Como você dormiu/], ['2026-09-29T15:00:00-03:00', /Beba 500 ml/], ['2026-09-29T22:10:00-03:00', /desacelerar/]]) {
  const { ctx, page } = await open({ time, seed: { docs: { profile: { name: 'Carlos', startWeight: 112, goalWeight: 90, height: 178, onboarded: true, startDate: '2026-09-28', updatedAt: 1 }, 'm-2026-09': { days: {}, weights: [{ date: '2026-09-28', kg: 112, at: 1 }], measures: [], sessions: [], cardio: [], updatedAt: 1 } }, dirty: [] } });
  await page.locator('.card-now').waitFor();
  const t = await text(page, '.card-now .now-title');
  check(re.test(t), `${time.slice(11, 16)} → “${t}”`);
  await ctx.close();
}

/* ===================== 5. Dados feitos sem conta ===================== */
console.log('\n5) Dados feitos sem conta: sobem se a conta estiver vazia, nunca sobrescrevem');
{
  const localProfile = { docs: { profile: { name: 'Local', startWeight: 112, goalWeight: 90, height: 178, onboarded: true, startDate: '2026-09-28', updatedAt: 9e12 } }, dirty: ['profile'] };
  // conta vazia → dados locais sobem
  const a = await open({ cloud: true, fakeKey: '__fakedbC', seed: localProfile });
  await a.page.locator('.card-now').waitFor();
  await a.page.clock.runFor(1500);
  const up = await a.page.evaluate(() => JSON.parse(localStorage.getItem('__fakedbC') || '{}')['data/users/u_test/profile']);
  check(up && up.name === 'Local', 'conta vazia recebe os dados feitos antes');
  await a.ctx.close();
  // conta com dados → dados locais soltos são descartados
  const b = await browser.newContext({ ...devices['iPhone 13'], timezoneId: 'America/Sao_Paulo', locale: 'pt-BR' });
  await b.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: '' }));
  await b.addInitScript((seed) => {
    if (!localStorage.getItem('__init')) {
      localStorage.setItem('__init', '1');
      localStorage.setItem('mv1:data:local', seed);
      localStorage.setItem('__fakedbD', JSON.stringify({ 'data/users/u_test/profile': { name: 'Nuvem', startWeight: 112, goalWeight: 90, height: 178, onboarded: true, startDate: '2026-09-01', updatedAt: 5 } }));
    }
  }, JSON.stringify(localProfile));
  await b.addInitScript(fakeClaude, { key: '__fakedbD', owner: true });
  const pg = await b.newPage();
  await pg.clock.install({ time: new Date('2026-09-28T18:05:00-03:00') });
  await pg.goto(URL_);
  await pg.clock.runFor(1500);
  await pg.locator('.card-now').waitFor();
  const h1 = await pg.locator('.hello h1').innerText();
  const cloudName = await pg.evaluate(() => JSON.parse(localStorage.getItem('__fakedbD'))['data/users/u_test/profile'].name);
  check(h1.includes('Nuvem') && cloudName === 'Nuvem', `dados da conta preservados (${h1} · nuvem: ${cloudName})`);
  await b.close();
}

await browser.close();
server.close();
console.log(`\n${problems.length ? 'FALHAS: ' + problems.length : 'Tudo certo.'}`);
process.exit(problems.length ? 1 : 0);
