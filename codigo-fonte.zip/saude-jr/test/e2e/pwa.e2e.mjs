// Saúde Jr. — testes de ponta a ponta das funções novas (agenda, corrida, refeições, suplementos, fotos, plano do mês)
// e do app instalável (PWA: manifesto, service worker, offline, calendário, backup e restauração).
import { createRequire } from 'module';
import fs from 'fs';
import http from 'http';
import path from 'path';
import os from 'os';
const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); } catch (e) { playwright = require('/home/claude/.npm-global/lib/node_modules/playwright'); }
const { chromium, devices } = playwright;

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '..');
const SHOTS = process.env.SHOTS || path.join(os.tmpdir(), 'saude-jr-shots-2');
fs.mkdirSync(SHOTS, { recursive: true });
const b64 = (p) => fs.readFileSync(path.join(ROOT, p)).toString('base64');
const fontCss = `
@font-face{font-family:"Archivo";font-style:normal;font-display:block;font-weight:100 900;font-stretch:62% 125%;src:url(data:font/woff2;base64,${b64('public/fonts/archivo.woff2')}) format("woff2");}
@font-face{font-family:"Figtree";font-style:normal;font-display:block;font-weight:300 900;src:url(data:font/woff2;base64,${b64('public/fonts/figtree.woff2')}) format("woff2");}`;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.json': 'application/json', '.md': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8' };
const server = http.createServer((req, res) => {
  let rel = decodeURIComponent(req.url.split('?')[0]);
  if (rel.endsWith('/')) rel += 'index.html';
  const f = path.join(ROOT, 'dist', rel);
  if (!f.startsWith(ROOT + '/dist') || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
});
await new Promise((r) => server.listen(8766, r));
const BASE = 'http://127.0.0.1:8766';

const problems = [];
const check = (cond, msg) => { if (!cond) { problems.push(msg); console.log('  ✗ ' + msg); } else console.log('  ✓ ' + msg); };
// Chromium completo (modo headless novo): suporta permissão de notificações
const browser = await chromium.launch({ channel: 'chromium' }).catch(() => chromium.launch());
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const shot = (page, name, full = true) => page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: full });
const text = (page, sel) => page.locator(sel).first().innerText();
async function tap(page, sel, ms = 60) { await page.locator(sel).first().click(); if (page.__clock) await page.clock.runFor(ms); else await sleep(ms); }
async function overflow(page, label) {
  const r = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  check(r.sw <= r.cw + 1, `sem rolagem lateral: ${label} (${r.sw}/${r.cw})`);
}
/** aciona uma ação do app como se fosse um toque (navegação direta nos testes) */
async function act(page, data) {
  await page.evaluate((d) => { const b = document.createElement('button'); Object.assign(b.dataset, d); document.body.appendChild(b); b.click(); b.remove(); }, data);
  if (page.__clock) await page.clock.runFor(80); else await sleep(80);
}
/** espera algo assíncrono de verdade (imagem, IndexedDB) com o relógio falso */
async function until(page, fn, arg, tries = 60) {
  for (let i = 0; i < tries; i++) { if (await page.evaluate(fn, arg)) return true; await page.clock.runFor(50); await sleep(60); }
  return false;
}

const PROFILE = { name: 'Teste', age: 41, height: 178, startWeight: 112, goalWeight: 90, trainDays: [1, 2, 3, 4, 5, 6], trainTime: '06:00', wakeTime: '05:30', bedTime: '22:30', waterGoal: 3000, stepsGoal: 6000, onboarded: true, startDate: '2026-09-29', safety: { answers: { dizzy: true }, flag: true, cleared: false, date: '2026-09-29' }, updatedAt: 1 };
const seedDocs = () => ({ profile: JSON.parse(JSON.stringify(PROFILE)), core: { choice: {}, ex: {}, marmitas: [], marks: {}, photos: [], updatedAt: 1 }, 'm-2026-09': { days: {}, weights: [{ date: '2026-09-29', kg: 112, at: 1 }], measures: [], sessions: [], cardio: [], updatedAt: 1 } });

async function openArtifact({ time, docs, width } = {}) {
  const ctx = await browser.newContext({ ...devices['iPhone 13'], ...(width ? { viewport: { width, height: 800 } } : {}), timezoneId: 'America/Sao_Paulo', locale: 'pt-BR' });
  await ctx.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: fontCss }));
  await ctx.route('https://fonts.gstatic.com/**', (r) => r.abort());
  if (docs) await ctx.addInitScript((s) => { if (!localStorage.getItem('mv1:seeded')) { localStorage.setItem('mv1:data:local', s); localStorage.setItem('mv1:seeded', '1'); } }, JSON.stringify({ docs, dirty: [] }));
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.gstatic|ERR_FAILED/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.clock.install({ time: new Date(time || '2026-09-29T06:05:00-03:00') });
  page.__clock = true;
  await page.goto(BASE + '/claude/harness.html');
  await page.clock.runFor(500);
  return { ctx, page, errors };
}

/* ===================== 6. Rotina do Saúde Jr. ===================== */
console.log('\n6) Saúde Jr.: agenda, corrida, refeições, suplementos, fotos e plano do mês');
{
  const { ctx, page, errors } = await openArtifact({ docs: seedDocs() });
  await page.locator('.card-now').waitFor();
  check((await text(page, '.brand')).toUpperCase().includes('SAÚDE JR.'), 'nome do app: Saúde Jr.');
  check((await page.locator('.agenda .ag-row').count()) === 5, 'Home mostra a agenda do dia (5 próximos itens)');
  const tcard = await page.locator('section.card:has-text("Treino de hoje")').innerText();
  check(/Caminhada contínua · 30 min/.test(tcard), `terça é dia de corrida, semana 1 = caminhada (${tcard.split('\n')[2] || ''})`);
  check(await page.locator('.card-warn:has-text("médico")').count() >= 1, 'aviso de segurança pela tontura');
  await shot(page, '30-home', true);
  await overflow(page, 'Hoje');

  // agenda completa e semana
  await tap(page, '[data-act="go"][data-to="agenda"]');
  const ag = await page.locator('#app').innerText();
  check(/Café da manhã/.test(ag) && /07:15/.test(ag) && /Ceia/.test(ag) && /21:30/.test(ag), 'agenda com as 6 refeições nos horários certos (café 07:15, ceia 21:30)');
  check((await page.locator('.week-row').count()) === 7, 'semana com os 7 dias');
  await tap(page, '[data-act="weekSet"][data-w="0"][data-v="run"]');
  check((await page.locator('[data-act="weekSet"][data-w="0"][data-v="run"][aria-pressed="true"]').count()) === 1, 'muda o domingo para corrida');
  await tap(page, '[data-act="weekSet"][data-w="0"][data-v="rest"]');
  await tap(page, '[data-act="sheet"][data-s="bloco"]');
  await page.fill('#bl-label', 'Trabalho');
  await page.fill('#bl-time', '08:00'); await page.fill('#bl-end', '17:00');
  await tap(page, '[data-act="saveBloco"]');
  check(/Trabalho/.test(await page.locator('.agenda').first().innerText()), 'bloco fixo entra na agenda');
  await shot(page, '31-agenda', true);
  await overflow(page, 'Agenda');
  await tap(page, '.ag-check[data-kind="meal"]');
  check((await page.locator('.ag-check[data-kind="meal"][aria-pressed="true"]').count()) === 1, 'marcar refeição pela agenda');
  await tap(page, '.ag-check[data-kind="meal"]');

  // corrida guiada
  await tap(page, '.tab[data-to="treino"]');
  await tap(page, '[data-act="seg"][data-group="treino"][data-v="corrida"]');
  const cor = await page.locator('#app').innerText();
  check(/10 KM Tribuna FM/.test(cor) && /Semana 1 de 33/.test(cor), 'plano até a prova: semana 1 de 33');
  check(/Trotes liberados só depois do médico/.test(cor), 'trote bloqueado até liberação médica');
  check((await page.locator('.run-slot').count()) === 3, '3 sessões na semana (ter, qui, sáb)');
  await shot(page, '32-corrida', true);
  await overflow(page, 'Corrida');
  await tap(page, '.run-slot.today [data-act="runStart"]');
  check((await text(page, '#runPhase')) === 'CAMINHE', 'sessão ao vivo começa caminhando');
  await page.clock.runFor(60000);
  check(/^29:0[01]$/.test(await text(page, '#runLeft')), `contagem regressiva do bloco (${await text(page, '#runLeft')})`);
  await tap(page, '[data-act="runPause"]');
  await page.clock.runFor(10000);
  check((await text(page, '#runPhase')) === 'PAUSADO' && (await text(page, '#runLeft')) === '29:00', 'pausa congela o tempo');
  await shot(page, '33-sessao-corrida', false);
  await overflow(page, 'Sessão de corrida');
  await tap(page, '[data-act="runPause"]');
  await page.reload(); page.__clock = true; await page.clock.runFor(600);
  check((await page.locator('#runLive').count()) === 1, 'sessão continua depois de recarregar a página');
  await tap(page, '[data-act="runSkip"]', 300);
  check(await page.locator('.sheet:has-text("Como foi a sessão?")').count() === 1, 'fim do último bloco abre o registro');
  check((await page.inputValue('#rl-min')) === '30', 'tempo vem preenchido (30 min)');
  await tap(page, '#rl-pain [data-v="1"]');
  check(!(await page.locator('#rl-area-f').isHidden()), 'com dor, pergunta onde dói');
  await tap(page, '#rl-area [data-v="joelho"]');
  await tap(page, '[data-act="runSave"]');
  check(/Caminhada contínua · 30 min/.test(await page.locator('section.card:has-text("Últimas sessões")').innerText()), 'sessão no histórico');
  await tap(page, '[data-act="runFree"][data-t="r"]');
  check(await page.locator('.sheet:has-text("liberação")').count() === 1, 'corrida livre pede liberação médica');
  await tap(page, '.sheet [data-act="runFree"][data-t="w"]');
  check((await text(page, '#runPhase')) === 'CAMINHANDO', 'caminhada livre começa');
  await page.clock.runFor(6 * 60000);
  await tap(page, '.sess-top [data-act="runFinishAsk"]');
  await tap(page, '.sheet [data-act="runFinish"]');
  await page.fill('#rl-km', '0,8');
  await tap(page, '[data-act="runSave"]');
  check((await page.locator('section.card:has-text("Últimas sessões") .kv').count()) === 2, 'duas sessões registradas');
  await tap(page, '.tab[data-to="home"]');
  check(/Feito/.test(await page.locator('section.card:has-text("Treino de hoje")').innerText()), 'Home: treino do dia feito');

  // refeições, horários e suplementos
  await tap(page, '.tab[data-to="comida"]');
  check((await page.locator('[id^="meal-"]').count()) === 6, '6 refeições no dia');
  check((await page.locator('.pill.fr').count()) >= 2 && (await page.locator('.pill.fb').count()) >= 4, 'frutas e fibras marcadas no cardápio');
  await shot(page, '34-refeicoes', true);
  await overflow(page, 'Refeições');
  await tap(page, '[data-act="sheet"][data-s="horarios"]');
  await page.fill('#mt-cafe', '07:30');
  await tap(page, '[data-act="saveMealTimes"]');
  check(/07:30/.test(await text(page, '#meal-cafe')), 'horário do café ajustado');
  await tap(page, '[data-act="seg"][data-group="comida"][data-v="suplementos"]');
  await tap(page, '[data-act="sheet"][data-s="supp"]');
  await tap(page, '[data-act="suppTpl"][data-i="1"]');
  check((await page.inputValue('#sp-name')) === 'Creatina', 'atalho preenche o suplemento');
  await page.fill('#sp-stock', '30');
  await tap(page, '[data-act="saveSupp"]');
  await tap(page, '[data-act="suppTake"]');
  const sp = await page.locator('#app').innerText();
  check(/Estoque: 29 doses/.test(sp), 'tomar a dose baixa o estoque (29)');
  await shot(page, '35-suplementos', true);
  await overflow(page, 'Suplementos');

  // lembretes na hora da refeição (café 07:30: água, café e creatina na fila)
  await page.clock.setSystemTime(new Date('2026-09-29T07:30:30-03:00'));
  await page.clock.runFor(21000);
  check(await page.locator('#alertbar').isVisible(), 'aviso aparece na hora da refeição');
  const al1 = await text(page, '#alertbar');
  await tap(page, '[data-act="alertClose"]', 1500);
  const al2 = await text(page, '#alertbar');
  check(/Café da manhã · 07:30/.test(al1 + al2), `avisos em fila: “${al1.split('\n')[1]}” e “${al2.split('\n')[1]}”`);
  await shot(page, '36-aviso-refeicao', false);
  await tap(page, '[data-act="alertClose"]', 1500);
  if (await page.locator('#alertbar').isVisible()) await tap(page, '[data-act="alertClose"]', 200);

  // fotos diárias no aparelho
  await tap(page, '.tab[data-to="evolucao"]');
  await tap(page, '[data-act="seg"][data-group="evolucao"][data-v="fotos"]');
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.locator('[data-act="photoAdd"][data-pose="frente"]').first().click()]);
  await fc.setFiles(path.join(ROOT, 'test/fixtures/foto-1.jpg'));
  check(await until(page, () => !!document.querySelector('.photos img[src]')), 'foto do dia salva e exibida');
  check(/1 dia/.test(await text(page, '.card-now .badge')), 'sequência de fotos: 1 dia');
  await page.clock.setSystemTime(new Date('2026-09-30T06:00:00-03:00'));
  await page.clock.runFor(31000);
  await act(page, { act: 'seg', group: 'evolucao', v: 'fotos' });
  const [fc2] = await Promise.all([page.waitForEvent('filechooser'), page.locator('[data-act="photoAdd"][data-pose="frente"]').first().click()]);
  await fc2.setFiles(path.join(ROOT, 'test/fixtures/foto-2.jpg'));
  check(await until(page, () => document.querySelectorAll('.photos img[src]').length === 2), 'segunda foto no dia seguinte');
  await shot(page, '37-fotos', true);
  await overflow(page, 'Fotos');
  await tap(page, '[data-act="sheet"][data-s="timelapse"]', 200);
  check(await until(page, () => { const i = document.getElementById('tl-img'); return !!(i && i.src && i.naturalWidth > 0); }), 'linha do tempo toca as fotos');
  check(await page.locator('#alertbar').isHidden(), 'aviso espera a folha fechar');
  await shot(page, '38-linha-do-tempo', false);
  await tap(page, '.sheet-head [data-act="closeSheet"]');
  await tap(page, '[data-act="sheet"][data-s="compare"][data-mode="photos"]', 200);
  check(await until(page, () => document.querySelectorAll('#cmp img[src]').length === 2), 'comparar primeira × última');
  await tap(page, '.sheet-head [data-act="closeSheet"]');

  // plano do mês
  await tap(page, '.tab[data-to="treino"]');
  await tap(page, '[data-act="seg"][data-group="treino"][data-v="academia"]');
  await tap(page, '[data-act="go"][data-to="planoMes"]');
  await tap(page, '[data-act="sheet"][data-s="planItem"][data-t="A"][data-i="0"]');
  await page.fill('#pi-sets', '4');
  await tap(page, '[data-act="savePlanItem"]');
  check(/4 × /.test(await text(page, '[data-s="planItem"][data-t="A"][data-i="0"]')) && /personalizado/i.test(await page.locator('#app').innerText()), 'plano de setembro personalizado (4 séries)');
  await shot(page, '39-plano-mes', true);
  await overflow(page, 'Plano do mês');

  // lembretes: horários para o celular
  await act(page, { act: 'go', to: 'lembretes' });
  const lem = await text(page, '#alarmsText');
  check(/07:30 · Café da manhã/.test(lem) && /Creatina/.test(lem) && /Corrida \/ caminhada — ter, qui, sáb/.test(lem), 'lista de alarmes com refeições, suplemento e corrida');
  await overflow(page, 'Lembretes');
  await act(page, { act: 'go', to: 'instalar' });
  check(/Adicionar à Tela de Início/.test(await page.locator('#app').innerText()), 'instruções para pôr o ícone no celular');
  await shot(page, '40-instalar', true);
  await overflow(page, 'Instalar');
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}

/* ===================== 7. Telas estreitas (320 px) e tablet (768 px) ===================== */
console.log('\n7) Telas estreitas e tablet');
for (const width of [320, 360, 768]) {
  const docs = seedDocs();
  docs.core.supps = [{ id: 'sp1', name: 'Multivitamínico', dose: '1 comprimido', meal: 'almoco', days: [0, 1, 2, 3, 4, 5, 6], stock: 5, unit: 'comprimidos', perDose: 1 }];
  const { ctx, page, errors } = await openArtifact({ docs, width });
  await page.locator('.card-now').waitFor();
  const routes = [{ act: 'go', to: 'home' }, { act: 'go', to: 'agenda' }, { act: 'seg', group: 'treino', v: 'corrida' }, { act: 'seg', group: 'treino', v: 'academia' }, { act: 'go', to: 'planoMes' },
    { act: 'seg', group: 'comida', v: 'refeicoes' }, { act: 'seg', group: 'comida', v: 'suplementos' }, { act: 'seg', group: 'evolucao', v: 'fotos' }, { act: 'seg', group: 'evolucao', v: 'meta' }, { act: 'go', to: 'lembretes' }, { act: 'go', to: 'instalar' }, { act: 'go', to: 'perfil' }];
  const bad = [];
  for (const r of routes) {
    await act(page, r);
    const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    if (m.sw > m.cw + 1) bad.push(`${r.to || r.v} ${m.sw}/${m.cw}`);
  }
  for (const s of [{ act: 'sheet', s: 'supp' }, { act: 'sheet', s: 'horarios' }, { act: 'sheet', s: 'bloco' }, { act: 'sheet', s: 'prova' }, { act: 'sheet', s: 'runLog', manual: '1' }]) {
    await act(page, s);
    const m = await page.evaluate(() => { const sh = document.querySelector('.sheet'); return sh ? { sw: sh.scrollWidth, cw: sh.clientWidth } : { sw: 0, cw: 0 }; });
    if (m.sw > m.cw + 1) bad.push(`folha ${s.s} ${m.sw}/${m.cw}`);
    await act(page, { act: 'closeSheet' });
  }
  await act(page, { act: 'runStart', idx: '0' });
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  if (m.sw > m.cw + 1) bad.push(`sessão ${m.sw}/${m.cw}`);
  if (width === 320) { await shot(page, '41-sessao-320', false); await act(page, { act: 'go', to: 'home' }); await shot(page, '42-home-320', true); await act(page, { act: 'seg', group: 'comida', v: 'refeicoes' }); await shot(page, '43-comida-320', false); }
  if (width === 768) { await act(page, { act: 'go', to: 'agenda' }); await shot(page, '44-agenda-768', false); }
  check(!bad.length, `${width} px sem rolagem lateral${bad.length ? ': ' + bad.join(', ') : ''}`);
  check(errors.length === 0, `${width} px sem erros: ` + errors.join(' | '));
  await ctx.close();
}

/* ===================== 8. App instalável (PWA) ===================== */
console.log('\n8) App instalável: manifesto, service worker, offline, calendário e backup');
{
  const ctx = await browser.newContext({ ...devices['Pixel 7'], timezoneId: 'America/Sao_Paulo', locale: 'pt-BR', acceptDownloads: true });
  await ctx.route('https://fonts.googleapis.com/**', (r) => r.fulfill({ contentType: 'text/css', body: fontCss }));
  await ctx.route('https://fonts.gstatic.com/**', (r) => r.abort());
  let page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.gstatic|ERR_FAILED|ERR_INTERNET_DISCONNECTED/.test(m.text())) errors.push('console: ' + m.text()); });
  await page.goto(BASE + '/pwa/');
  await page.getByRole('button', { name: 'Começar' }).waitFor();
  const man = await page.evaluate(async () => { const l = document.querySelector('link[rel=manifest]'); const r = await fetch(l.href); return r.json(); });
  check(man.name === 'Saúde Jr.' && man.display === 'standalone' && man.icons.some((i) => i.sizes === '512x512' && i.purpose === 'maskable'), 'manifesto: nome, tela cheia e ícones (inclui maskable)');
  const sw = await page.evaluate(async () => { const reg = await navigator.serviceWorker.ready; return !!reg.active; });
  check(sw, 'service worker ativo');
  // critério de instalação do Chrome (o mesmo que libera "Instalar app" no Android), num perfil normal (não anônimo)
  {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'saude-jr-perfil-'));
    const pctx = await chromium.launchPersistentContext(dir, { channel: 'chromium', ...devices['Pixel 7'] }).catch(() => chromium.launchPersistentContext(dir, { ...devices['Pixel 7'] }));
    const pp = pctx.pages()[0] || await pctx.newPage();
    await pp.goto(BASE + '/pwa/');
    await pp.evaluate(() => navigator.serviceWorker.ready);
    await pp.reload(); await pp.getByRole('button', { name: 'Começar' }).waitFor();
    const cdp = await pctx.newCDPSession(pp);
    const inst = await cdp.send('Page.getInstallabilityErrors');
    check(inst.installabilityErrors.length === 0, 'Chrome considera o app instalável' + (inst.installabilityErrors.length ? ': ' + JSON.stringify(inst.installabilityErrors) : ''));
    await pctx.close();
  }
  const fontsLocal = await page.evaluate(() => [...document.querySelectorAll('link[rel=stylesheet]')].every((l) => !/googleapis/.test(l.href)));
  check(fontsLocal, 'fontes no próprio app (sem chamadas a terceiros)');
  check((await text(page, '.ob-hero .h1')).includes('Saúde em primeiro lugar'), 'versão pública começa sem dados pessoais');
  check((await page.evaluate(() => !!window.MVImages && Object.keys(window.MVImages).length === 0)), 'sem fotos pessoais embutidas');
  await tap(page, 'button:has-text("Começar")');
  check((await page.inputValue('#ob-weight')) === '', 'peso começa em branco');
  await page.fill('#ob-name', 'Teste'); await page.fill('#ob-age', '41'); await page.fill('#ob-height', '178'); await page.fill('#ob-weight', '112'); await page.fill('#ob-goal', '95');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Continuar")');
  await tap(page, 'button:has-text("Pronto")', 200);
  await page.locator('.card-now').waitFor();
  check(await page.locator('text=Instale o app').count() === 1, 'Home sugere instalar');
  check((await page.locator('.tab').allInnerTexts()).join('|').replace(/\s+/g, '') === 'Hoje|Treino|Alimentação|Evolução|Perfil', 'menu: Hoje, Treino, Alimentação, Evolução, Perfil');
  check(await page.locator('section.card:has-text("Alimentação") [data-to="comida"]').count() === 1, 'Home com card de alimentação');
  await shot(page, '45-pwa-home', true);
  // registros do dia a dia
  await tap(page, '.water-btns [data-ml="250"]');
  await tap(page, 'button.tile[data-s="energia"]');
  check(await page.locator('.sheet:has-text("Como você está se sentindo hoje?")').count() === 1, 'energia: pergunta do dia');
  await tap(page, '.sheet [data-act="dayEnergy"][data-v="7"]');
  check(/^7/.test((await text(page, 'button.tile[data-s="energia"] .num')).trim()), 'energia registrada (7/10)');
  // fechar e abrir de novo
  await page.close();
  const page2 = await ctx.newPage();
  page2.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  await page2.goto(BASE + '/pwa/');
  await page2.locator('.card-now').waitFor();
  check((await page2.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '250', 'fechar e abrir: dados continuam');
  // armazenamento simples apagado: os dados voltam da cópia estruturada (IndexedDB)
  await page2.evaluate(() => { Object.keys(localStorage).filter((k) => k.startsWith('mv1:')).forEach((k) => localStorage.removeItem(k)); });
  await page2.reload();
  await page2.locator('.card-now').waitFor({ timeout: 8000 }).catch(() => {});
  check((await page2.locator('.hello h1').innerText().catch(() => '')).includes('Teste'), 'dados recuperados da cópia no IndexedDB');
  page = page2;
  // notificações do sistema (permissão concedida)
  await ctx.grantPermissions(['notifications'], { origin: BASE });
  await act(page, { act: 'go', to: 'lembretes' });
  await tap(page, '[data-act="testReminder"]', 300);
  const notes = await page.evaluate(async () => { const reg = await navigator.serviceWorker.ready; await new Promise((r) => setTimeout(r, 300)); return (await reg.getNotifications()).map((n) => n.title); });
  check(notes.some((t) => /Hora do treino/.test(t)), `notificação do sistema pelo app instalado (${notes.join(', ') || 'nenhuma'})`);
  check(await page.locator('#alertbar').isVisible(), 'aviso na tela com o app aberto');
  await tap(page, '[data-act="alertClose"]');
  const gcal = await page.locator('a[href^="https://calendar.google.com/calendar/render"]').evaluateAll((as) => as.map((a) => a.href));
  check(gcal.length >= 9 && gcal.every((h) => /action=TEMPLATE/.test(h) && /recur=RRULE/.test(h)), `lembretes para o Google Agenda com repetição (${gcal.length})`);
  await act(page, { act: 'go', to: 'privacidade' });
  check(/termos de uso/i.test(await page.locator('#app').innerText()), 'página de privacidade e termos');
  await act(page, { act: 'seg', group: 'evolucao', v: 'fotos' });
  check(await page.locator('[data-act="photoAdd"][data-pose="costas"]').count() === 1, 'fotos: frente, lado e costas');
  // calendário de lembretes (.ics)
  await act(page, { act: 'go', to: 'lembretes' });
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-act="exportIcs"]').click()]);
  const icsPath = await dl.path();
  const ics = fs.readFileSync(icsPath, 'utf8');
  check(dl.suggestedFilename() === 'saude-jr-lembretes.ics' && /BEGIN:VCALENDAR/.test(ics) && (ics.match(/BEGIN:VEVENT/g) || []).length >= 9 && /Café da manhã/.test(ics), `calendário com ${(ics.match(/BEGIN:VEVENT/g) || []).length} lembretes (6 refeições, treino, foto, dormir…)`);
  // backup e restauração
  const [bk] = await Promise.all([page.waitForEvent('download'), act(page, { act: 'exportJson' })]);
  const backup = JSON.parse(fs.readFileSync(await bk.path(), 'utf8'));
  check(backup.app === 'Saúde Jr.' && backup.docs.profile.name === 'Teste', 'backup em arquivo .json');
  backup.docs.profile.name = 'Restaurado';
  const bkFile = SHOTS + '/backup-teste.json';
  fs.writeFileSync(bkFile, JSON.stringify(backup));
  await act(page, { act: 'importAsk' });
  const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.locator('.sheet [data-act="importPick"]').click()]);
  await fc.setFiles(bkFile);
  await sleep(500);
  check((await text(page, '.hello h1')).includes('Restaurado'), 'restaurar backup');
  // sem internet e de volta
  await ctx.setOffline(true);
  await page.reload();
  await page.locator('.card-now').waitFor({ timeout: 8000 }).catch(() => {});
  check((await page.locator('.card-now').count()) === 1, 'abre sem internet');
  await tap(page, '.water-btns [data-ml="500"]');
  check(/500|750/.test(await page.locator('section.card:has(.water-btns) .num').first().innerText()), 'registra sem internet');
  await ctx.setOffline(false);
  await page.reload();
  await page.locator('.card-now').waitFor();
  check((await page.locator('section.card:has(.water-btns) .num').first().innerText()).trim() === '750', 'internet de volta: nada se perdeu (750 ml)');
  // perfil inicial pelo link
  const ctx2 = await browser.newContext({ ...devices['Pixel 7'], locale: 'pt-BR' });
  const pi = await ctx2.newPage();
  await pi.goto(BASE + '/pwa/#ini=30,175,95,85');
  await pi.getByRole('button', { name: 'Começar' }).click();
  check((await pi.inputValue('#ob-weight')) === '95' && (await pi.inputValue('#ob-height')) === '175' && (await pi.inputValue('#ob-age')) === '30' && (await pi.inputValue('#ob-goal')) === '85', 'link com perfil inicial preenche idade, altura, peso e meta');
  await ctx2.close();
  check(errors.length === 0, 'sem erros no console: ' + errors.join(' | '));
  await ctx.close();
}

await browser.close();
server.close();
console.log(`\n${problems.length ? 'FALHAS: ' + problems.length : 'Tudo certo.'}`);
process.exit(problems.length ? 1 : 0);
