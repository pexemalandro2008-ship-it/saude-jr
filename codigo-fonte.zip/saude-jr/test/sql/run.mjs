// Testes do banco (RLS, projeção e fotos) num Postgres limpo com as mesmas migrações da produção.
//   npm run test:db
// Usa as variáveis padrão do Postgres (PGHOST, PGPORT, PGUSER, PGPASSWORD). Nada é gravado: tudo roda em transação.
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { freshDatabase, dropDatabase, ROOT } from '../support/db.mjs';

const require = createRequire(import.meta.url);
const pg = require('pg');
const NAME = 'saudejr_sql';
const sqlFile = (f) => fs.readFileSync(path.join(ROOT, 'test/sql', f), 'utf8')
  .split('\n').filter((l) => !l.startsWith('\\')).join('\n'); // tira comandos do psql (\set ...)

let failed = false;
const conn = await freshDatabase(NAME);
const c = new pg.Client(conn);
await c.connect();
try {
  // 1) roteiro completo, em transação desfeita no final
  const res = [].concat(await c.query(sqlFile('10-security.sql')));
  const ok = res.some((r) => r.rows && r.rows.some((row) => /^OK: banco seguro/.test(row.resultado || '')));
  console.log(ok ? '  ✓ isolamento entre usuários, projeção e fotos (10-security.sql)' : '  ✗ 10-security.sql não terminou com OK');
  if (!ok) failed = true;
} catch (e) {
  failed = true;
  console.log('  ✗ 10-security.sql: ' + e.message);
}
try {
  // 2) a mesma conferência usada na produção: só pode terminar com TESTE_OK (que desfaz tudo)
  await c.query(sqlFile('20-remote-check.sql'));
  failed = true;
  console.log('  ✗ 20-remote-check.sql deveria terminar com TESTE_OK');
} catch (e) {
  if (/^TESTE_OK/.test(e.message)) console.log('  ✓ conferência de produção (20-remote-check.sql)');
  else { failed = true; console.log('  ✗ 20-remote-check.sql: ' + e.message); }
}
await c.end();
await dropDatabase(NAME);
if (failed) { console.log('\nFalhou.'); process.exit(1); }
console.log('\nBanco: tudo certo.');
