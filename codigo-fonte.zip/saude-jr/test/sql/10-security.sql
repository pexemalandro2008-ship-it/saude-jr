-- Testes do banco: isolamento entre usuários (RLS), projeção dos documentos e fotos.
-- Roda dentro de uma transação que é desfeita no final: nada fica gravado.
\set ON_ERROR_STOP 1
begin;

insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values
  ('00000000-0000-4000-8000-00000000000a', 'ana@teste.local', '{"name":"Ana"}', now()),
  ('00000000-0000-4000-8000-00000000000b', 'bruno@teste.local', '{"name":"Bruno"}', now());

do $$ begin
  assert (select count(*) from public.profiles) = 2, 'cadastro cria o perfil';
  assert (select name from public.profiles where email = 'ana@teste.local') = 'Ana', 'nome vindo do cadastro';
end $$;

-- ===== usuário A =====
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-00000000000a","role":"authenticated"}', true);

insert into public.app_documents (doc_id, data) values ('profile', '{
  "name":"Ana","age":41,"height":178,"startWeight":112,"goalWeight":95,"goal":"Perder peso",
  "activityLevel":"sedentario","trainPref":"academia","trainDays":[1,3,5],"trainTime":"18:30","wakeTime":"06:30","bedTime":"22:30",
  "waterGoal":3000,"stepsGoal":6000,"startDate":"2026-09-01",
  "reminders":{"wake":true,"water":true,"waterEvery":120,"train":true,"meals":false,"sleep":true,"photo":true,"supps":true,"weigh":true,"weighDay":1,"weighTime":"07:00","checklist":true,"checklistTime":"21:00"},
  "mealTimes":{"almoco":"12:30"}}');

insert into public.app_documents (doc_id, data) values ('core', '{
  "photos":[{"id":"ph1","date":"2026-09-28","pose":"frente","src":"sb","path":"00000000-0000-4000-8000-00000000000a/ph1.jpg","at":1790600000000},
            {"id":"ph2","date":"data-ruim"}],
  "ex":{}}');

insert into public.app_documents (doc_id, data) values ('m-2026-09', '{
  "days":{
    "2026-09-28":{"water":2500,"waterLog":[250,500,750,1000],"steps":7200,
      "sleep":{"bed":"22:40","wake":"06:20","hours":7.7,"quality":3,"energy":7,"day":8,"notes":"acordei 1x"},
      "gut":{"bm":true,"form":"normal","pain":0,"bloat":1,"heartburn":2,"fiber":4,"fruits":3,"veg":2,"flags":{"blood":false},"notes":"azia depois do almoço"},
      "meals":{"cafe":"ok","almoco":"troca","jantar":"fora"},
      "checks":{"proteina":true,"frutas":true},"alcohol":0,"stress":2},
    "2026-09-29":{"water":750},
    "2026-09-31":{"water":999},
    "2026-10-01":{"water":999},
    "lixo":{"water":1}
  },
  "weights":[{"date":"2026-09-28","kg":111.4,"at":1790600000000},{"date":"2026-09-29","kg":"abc"}],
  "measures":[{"date":"2026-09-28","waist":109,"hip":112,"arm":37.5,"chest":116}],
  "sessions":[{"id":"s1","date":"2026-09-28","type":"A","week":4,"phase":1,"startedAt":1790600000000,"finishedAt":1790603000000,"completed":true,
    "items":[{"exId":"legpress","kind":"reps","load":60,"rest":90,"difficulty":2,"note":"banco 4","done":true,"sets":[{"done":true,"reps":12},{"done":true,"reps":12},{"done":false,"reps":10}]},
             {"exId":"prancha","kind":"time","sets":[{"done":true,"reps":30}]}]},
    {"id":"s1","date":"2026-09-28","type":"A","items":[]}],
  "cardio":[{"id":"c1","date":"2026-09-28","at":1790604000000,"kind":"esteira","minutes":20,"km":1.8,"speed":5.4,"rpe":4,"kcal":150,"kcalSrc":"estimativa"}],
  "runs":[{"id":"r1","date":"2026-09-29","at":1790690000000,"title":"Caminhada 30 min","kind":"walk","minutes":30,"km":2.9,"place":"praia","rpe":3,"pain":0,"src":"app"}]
}');

-- documento com dados ruins é aceito (a projeção ignora o que não entende)
insert into public.app_documents (doc_id, data) values ('m-2026-08', '{"days":[1,2,3],"weights":{"x":1},"sessions":"não é lista"}');

do $$ begin
  assert (select count(*) from public.app_documents) = 4, 'A vê os próprios 4 documentos';
  assert (select name from public.profiles) = 'Ana', 'A vê só o próprio perfil';
  assert (select count(*) from public.profiles) = 1, 'A não vê o perfil de B';
  assert (select training_preference from public.profiles) = 'academia', 'preferência de treino projetada';
  assert (select train_days from public.profiles) = array[1,3,5], 'dias de treino projetados';
  assert (select count(*) from public.reminders) = 9, 'lembretes projetados';
  assert (select enabled from public.reminders where id = 'refeicoes') = false, 'lembrete desligado respeitado';
  assert (select time from public.reminders where id = 'pesagem') = '07:00', 'horário da pesagem';
  assert (select total_ml from public.water_logs where date = '2026-09-28') = 2500, 'água do dia';
  assert (select entries from public.water_logs where date = '2026-09-28') = 4, 'registros de água';
  assert (select count(*) from public.water_logs) = 2, 'datas inválidas e fora do mês ignoradas';
  assert (select hours from public.sleep_logs where date = '2026-09-28') = 7.7, 'sono';
  assert (select notes from public.sleep_logs where date = '2026-09-28') = 'acordei 1x', 'observação do sono';
  assert (select on_waking from public.energy_logs) = 7 and (select during_day from public.energy_logs) = 8, 'energia';
  assert (select heartburn from public.intestinal_logs) = 2, 'azia';
  assert (select notes from public.intestinal_logs) = 'azia depois do almoço', 'observação do intestino';
  assert (select count(*) from public.meals where date = '2026-09-28') = 3, 'refeições';
  assert (select status from public.meals where meal = 'jantar') = 'fora', 'status da refeição';
  assert (select steps from public.daily_checklists) = 7200, 'passos';
  assert (select items ->> 'proteina' from public.daily_checklists) = 'true', 'checklist';
  assert (select weight_kg from public.measurements where date = '2026-09-28') = 111.4, 'peso';
  assert (select arm_cm from public.measurements where date = '2026-09-28') = 37.5, 'braço';
  assert (select chest_cm from public.measurements where date = '2026-09-28') = 116, 'peito';
  assert (select count(*) from public.measurements) = 1, 'peso inválido ignorado';
  assert (select count(*) from public.workouts) = 3, 'treino + cardio + caminhada (id duplicado ignorado)';
  assert (select minutes from public.workouts where id = 's1') = 50, 'duração do treino';
  assert (select kind from public.workouts where id = 'r1') = 'caminhada', 'caminhada';
  assert (select count(*) from public.workout_logs) = 2, 'exercícios do treino';
  assert (select sets_done from public.workout_logs where exercise_id = 'legpress') = 2, 'séries feitas';
  assert (select load_kg from public.workout_logs where exercise_id = 'legpress') = 60, 'carga';
  assert (select count(*) from public.progress_photos) = 1, 'foto válida projetada';
end $$;

-- atualizar o mês substitui a projeção (sem duplicar)
update public.app_documents set data = jsonb_set(data, '{days,2026-09-28,water}', '3000') where doc_id = 'm-2026-09';
do $$ begin
  assert (select total_ml from public.water_logs where date = '2026-09-28') = 3000, 'água atualizada';
  assert (select count(*) from public.workouts) = 3, 'sem duplicar treinos';
end $$;

-- o app não escreve direto nas tabelas por assunto
do $$ begin
  begin
    insert into public.water_logs (user_id, date, total_ml) values ('00000000-0000-4000-8000-00000000000a', '2026-09-01', 1);
    raise exception 'FALHA: app escreveu direto em water_logs';
  exception when insufficient_privilege then null;
  end;
end $$;

-- foto na pasta do próprio usuário: permitido
insert into storage.objects (bucket_id, name, owner) values ('progress-photos', '00000000-0000-4000-8000-00000000000a/ph1.jpg', '00000000-0000-4000-8000-00000000000a');
-- foto na pasta de outro usuário: bloqueado
do $$ begin
  begin
    insert into storage.objects (bucket_id, name) values ('progress-photos', '00000000-0000-4000-8000-00000000000b/invasao.jpg');
    raise exception 'FALHA: A enviou foto na pasta de B';
  exception when insufficient_privilege then null;
  end;
end $$;

-- controle de cadastros é só do servidor
do $$ begin
  begin
    perform 1 from public.signup_attempts;
    raise exception 'FALHA: app leu signup_attempts';
  exception when insufficient_privilege then null;
  end;
end $$;

-- ===== usuário B =====
select set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-00000000000b","role":"authenticated"}', true);
do $$ declare n int; begin
  assert (select count(*) from public.app_documents) = 0, 'B não vê documentos de A';
  assert (select count(*) from public.water_logs) = 0, 'B não vê água de A';
  assert (select count(*) from public.workouts) = 0, 'B não vê treinos de A';
  assert (select count(*) from public.measurements) = 0, 'B não vê peso de A';
  assert (select count(*) from public.progress_photos) = 0, 'B não vê fotos de A (tabela)';
  assert (select count(*) from storage.objects) = 0, 'B não vê fotos de A (arquivos)';
  assert (select name from public.profiles) = 'Bruno', 'B vê só o próprio perfil';
  update public.app_documents set data = '{"hack":true}' where doc_id = 'profile';
  get diagnostics n = row_count;
  assert n = 0, 'B não altera documento de A';
  delete from public.app_documents where doc_id = 'core';
  get diagnostics n = row_count;
  assert n = 0, 'B não apaga documento de A';
  delete from storage.objects where name like '00000000-0000-4000-8000-00000000000a/%';
  get diagnostics n = row_count;
  assert n = 0, 'B não apaga foto de A';
  begin
    insert into public.app_documents (user_id, doc_id, data) values ('00000000-0000-4000-8000-00000000000a', 'm-2026-07', '{}');
    raise exception 'FALHA: B gravou documento em nome de A';
  exception when insufficient_privilege then null;
  end;
end $$;

-- B grava o próprio documento normalmente
insert into public.app_documents (doc_id, data) values ('profile', '{"name":"Bruno"}');
do $$ begin
  assert (select count(*) from public.app_documents) = 1, 'B grava o próprio documento';
end $$;

-- ===== visitante sem login =====
reset role;
set local role anon;
select set_config('request.jwt.claims', '{"role":"anon"}', true);
do $$ begin
  begin
    perform 1 from public.app_documents;
    raise exception 'FALHA: anônimo leu documentos';
  exception when insufficient_privilege then null;
  end;
  begin
    perform 1 from public.profiles;
    raise exception 'FALHA: anônimo leu perfis';
  exception when insufficient_privilege then null;
  end;
  assert (select count(*) from storage.objects) = 0, 'anônimo não vê fotos';
end $$;

-- ===== apagar o documento limpa a projeção =====
reset role;
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-00000000000a","role":"authenticated"}', true);
delete from public.app_documents where doc_id = 'm-2026-09';
do $$ begin
  assert (select count(*) from public.water_logs) = 0, 'água removida junto com o mês';
  assert (select count(*) from public.workouts) = 0, 'treinos removidos junto com o mês';
end $$;

reset role;
select 'OK: banco seguro — isolamento, projeção e fotos conferidos' as resultado;
rollback;
