-- Conferência de segurança para rodar no banco de PRODUÇÃO sem deixar rastro.
-- É um único bloco: no final ele lança 'TESTE_OK', o que desfaz tudo o que foi criado.
-- Qualquer outra mensagem de erro indica qual regra falhou.
do $$
declare
  a constant uuid := '00000000-0000-4000-8000-00000000000a';
  b constant uuid := '00000000-0000-4000-8000-00000000000b';
  n int;
begin
  insert into auth.users (id, email, raw_user_meta_data, email_confirmed_at) values
    (a, 'ana@teste.local', '{"name":"Ana"}', now()),
    (b, 'bruno@teste.local', '{"name":"Bruno"}', now());
  assert (select count(*) from public.profiles where id in (a, b)) = 2, 'cadastro cria o perfil';

  -- usuário A
  perform set_config('role', 'authenticated', true);
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  insert into public.app_documents (doc_id, data) values ('profile', '{"name":"Ana","trainPref":"academia","trainDays":[1,3,5],"reminders":{"meals":false,"weighTime":"07:00"}}');
  insert into public.app_documents (doc_id, data) values ('core', '{"photos":[{"id":"ph1","date":"2026-09-28","pose":"frente","path":"x/ph1.jpg"}]}');
  insert into public.app_documents (doc_id, data) values ('m-2026-09', '{
    "days":{"2026-09-28":{"water":2500,"waterLog":[250,500],"sleep":{"hours":7.5,"quality":3,"energy":7,"day":8},
                          "gut":{"bm":true,"heartburn":2,"notes":"azia"},"meals":{"cafe":"ok"},"checks":{"frutas":true},"steps":7000}},
    "weights":[{"date":"2026-09-28","kg":111.4}],
    "measures":[{"date":"2026-09-28","waist":109,"arm":37.5,"chest":116}],
    "sessions":[{"id":"s1","date":"2026-09-28","type":"A","completed":true,"startedAt":1790600000000,"finishedAt":1790603000000,
                 "items":[{"exId":"legpress","kind":"reps","load":60,"sets":[{"done":true,"reps":12}]}]}],
    "cardio":[{"id":"c1","date":"2026-09-28","kind":"esteira","minutes":20}]}');
  assert (select count(*) from public.app_documents) = 3, 'A vê os próprios documentos';
  assert (select count(*) from public.profiles) = 1, 'A vê só o próprio perfil';
  assert (select training_preference from public.profiles) = 'academia', 'perfil projetado';
  assert (select count(*) from public.reminders) = 9, 'lembretes projetados';
  assert (select total_ml from public.water_logs) = 2500, 'água projetada';
  assert (select hours from public.sleep_logs) = 7.5, 'sono projetado';
  assert (select during_day from public.energy_logs) = 8, 'energia projetada';
  assert (select heartburn from public.intestinal_logs) = 2, 'intestino projetado';
  assert (select count(*) from public.meals) = 1, 'refeições projetadas';
  assert (select steps from public.daily_checklists) = 7000, 'checklist projetado';
  assert (select arm_cm from public.measurements) = 37.5 and (select weight_kg from public.measurements) = 111.4, 'medidas projetadas';
  assert (select count(*) from public.workouts) = 2, 'treinos projetados';
  assert (select count(*) from public.workout_logs) = 1, 'exercícios projetados';
  assert (select count(*) from public.progress_photos) = 1, 'fotos projetadas';
  begin
    insert into public.water_logs (user_id, date, total_ml) values (a, '2026-09-01', 1);
    raise exception 'FALHA: app escreveu direto em water_logs';
  exception when insufficient_privilege then null;
  end;
  insert into storage.objects (bucket_id, name, owner) values ('progress-photos', a::text || '/ph1.jpg', a);
  begin
    insert into storage.objects (bucket_id, name) values ('progress-photos', b::text || '/invasao.jpg');
    raise exception 'FALHA: A enviou foto na pasta de B';
  exception when insufficient_privilege then null;
  end;
  begin
    perform 1 from public.signup_attempts;
    raise exception 'FALHA: app leu signup_attempts';
  exception when insufficient_privilege then null;
  end;

  -- usuário B
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  assert (select count(*) from public.app_documents) = 0, 'B não vê documentos de A';
  assert (select count(*) from public.water_logs) = 0, 'B não vê água de A';
  assert (select count(*) from public.workouts) = 0, 'B não vê treinos de A';
  assert (select count(*) from public.measurements) = 0, 'B não vê medidas de A';
  assert (select count(*) from public.progress_photos) = 0, 'B não vê fotos de A (tabela)';
  assert (select count(*) from storage.objects where bucket_id = 'progress-photos') = 0, 'B não vê fotos de A (arquivos)';
  update public.app_documents set data = '{"hack":true}' where user_id = a;
  get diagnostics n = row_count;
  assert n = 0, 'B não altera documento de A';
  delete from public.app_documents where user_id = a;
  get diagnostics n = row_count;
  assert n = 0, 'B não apaga documento de A';
  begin
    insert into public.app_documents (user_id, doc_id, data) values (a, 'm-2026-07', '{}');
    raise exception 'FALHA: B gravou em nome de A';
  exception when insufficient_privilege then null;
  end;

  -- visitante sem login
  perform set_config('role', 'anon', true);
  perform set_config('request.jwt.claims', '{"role":"anon"}', true);
  begin
    perform 1 from public.app_documents;
    raise exception 'FALHA: anônimo leu documentos';
  exception when insufficient_privilege then null;
  end;
  begin
    perform 1 from public.profiles;
    raise exception 'FALHA: anônimo leu perfis';
  exception when insufficient_privilege then null;
  end;
  assert (select count(*) from storage.objects where bucket_id = 'progress-photos') = 0, 'anônimo não vê fotos';

  perform set_config('role', 'none', true);
  raise exception 'TESTE_OK: isolamento, projeção e fotos conferidos (nada foi gravado)';
end $$;
