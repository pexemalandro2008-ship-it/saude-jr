-- =====================================================================
-- Saúde Jr. — banco de dados (Supabase / Postgres)
--
-- Como os dados fluem:
--   1. O app grava documentos em public.app_documents (perfil, núcleo e um
--      documento por mês). É o que permite usar o app sem internet e
--      sincronizar depois, sem perder registros.
--   2. Um gatilho no banco projeta cada documento nas tabelas por assunto
--      (profiles, workouts, workout_logs, meals, water_logs, sleep_logs,
--      energy_logs, intestinal_logs, measurements, progress_photos,
--      daily_checklists, reminders), prontas para consulta e relatórios.
--
-- Segurança:
--   * Toda linha pertence a um usuário (user_id / id = auth.users.id).
--   * RLS ligado em todas as tabelas: cada pessoa só enxerga o que é dela.
--   * As tabelas por assunto são somente leitura para o app: só o gatilho
--     escreve nelas. Ninguém anônimo lê nada.
--   * Fotos ficam no bucket privado "progress-photos", numa pasta com o id
--     do usuário; só o dono lê, envia e apaga.
-- =====================================================================

create schema if not exists private;
revoke all on schema private from public;
revoke all on schema private from anon, authenticated;
comment on schema private is 'Funções internas do Saúde Jr. (não expostas pela API).';

-- ---------------------------------------------------------------------
-- 1. Documentos sincronizados pelo app (fonte de verdade)
-- ---------------------------------------------------------------------
create table public.app_documents (
  user_id    uuid        not null default auth.uid() references auth.users (id) on delete cascade,
  doc_id     text        not null,
  data       jsonb       not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, doc_id),
  constraint app_documents_doc_id check (doc_id ~ '^(profile|core|m-[0-9]{4}-(0[1-9]|1[0-2]))$'),
  constraint app_documents_data_object check (jsonb_typeof(data) = 'object'),
  constraint app_documents_data_size check (pg_column_size(data) <= 2000000)
);
comment on table public.app_documents is 'Documentos que o app sincroniza (perfil, núcleo e um por mês). Fonte de verdade.';

alter table public.app_documents enable row level security;
revoke all on public.app_documents from anon;
revoke all on public.app_documents from authenticated;
grant select, insert, update, delete on public.app_documents to authenticated;

create policy "app_documents: dono lê" on public.app_documents
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "app_documents: dono cria" on public.app_documents
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "app_documents: dono altera" on public.app_documents
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "app_documents: dono apaga" on public.app_documents
  for delete to authenticated using ((select auth.uid()) = user_id);

create or replace function private.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger app_documents_updated_at before update on public.app_documents
  for each row execute function private.touch_updated_at();

-- ---------------------------------------------------------------------
-- 2. Tabelas por assunto (somente leitura para o app)
-- ---------------------------------------------------------------------
create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  email               text,
  name                text,
  age                 int,
  height_cm           numeric(5,1),
  start_weight_kg     numeric(5,1),
  goal_weight_kg      numeric(5,1),
  goal                text,
  activity_level      text,
  training_preference text,
  train_days          int[],
  train_time          text,
  wake_time           text,
  bed_time            text,
  water_goal_ml       int,
  steps_goal          int,
  start_date          date,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
comment on table public.profiles is 'Perfil de cada usuário (nome, e-mail, medidas iniciais, objetivo, rotina).';

create table public.reminders (
  user_id uuid    not null references auth.users (id) on delete cascade,
  id      text    not null,
  label   text    not null,
  time    text,
  enabled boolean not null default true,
  details jsonb   not null default '{}'::jsonb,
  primary key (user_id, id)
);
comment on table public.reminders is 'Lembretes configurados (acordar, água, treino, refeições, dormir, pesagem, checklist…).';

create table public.workouts (
  user_id     uuid not null references auth.users (id) on delete cascade,
  id          text not null,
  date        date not null,
  kind        text not null,
  title       text,
  started_at  timestamptz,
  finished_at timestamptz,
  completed   boolean not null default true,
  minutes     int,
  distance_km numeric(7,2),
  effort      int,
  kcal        int,
  details     jsonb not null default '{}'::jsonb,
  primary key (user_id, id)
);
comment on table public.workouts is 'Treinos feitos: musculação, treino rápido, treino em casa, cardio, corrida e caminhada.';
create index workouts_user_date on public.workouts (user_id, date);

create table public.workout_logs (
  user_id       uuid not null references auth.users (id) on delete cascade,
  workout_id    text not null,
  position      int  not null,
  exercise_id   text not null,
  exercise_kind text,
  sets_planned  int,
  sets_done     int,
  reps          jsonb,
  load_kg       numeric(6,1),
  rest_s        int,
  difficulty    int,
  note          text,
  done          boolean,
  primary key (user_id, workout_id, position),
  foreign key (user_id, workout_id) references public.workouts (user_id, id) on delete cascade
);
comment on table public.workout_logs is 'Exercícios de cada treino: séries, repetições, carga, descanso, esforço e observações.';

create table public.meals (
  user_id uuid not null references auth.users (id) on delete cascade,
  date    date not null,
  meal    text not null,
  status  text not null,
  primary key (user_id, date, meal)
);
comment on table public.meals is 'Refeições do dia (café, lanches, almoço, jantar, ceia): seguiu, trocou ou fugiu.';

create table public.water_logs (
  user_id  uuid not null references auth.users (id) on delete cascade,
  date     date not null,
  total_ml int  not null,
  entries  int,
  primary key (user_id, date)
);
comment on table public.water_logs is 'Água bebida por dia.';

create table public.sleep_logs (
  user_id   uuid not null references auth.users (id) on delete cascade,
  date      date not null,
  bed_time  text,
  wake_time text,
  hours     numeric(4,1),
  quality   int,
  notes     text,
  primary key (user_id, date)
);
comment on table public.sleep_logs is 'Sono: horário de dormir e acordar, duração, qualidade e observações.';

create table public.energy_logs (
  user_id    uuid not null references auth.users (id) on delete cascade,
  date       date not null,
  on_waking  int,
  during_day int,
  primary key (user_id, date)
);
comment on table public.energy_logs is 'Energia (1 a 10) ao acordar e durante o dia.';

create table public.intestinal_logs (
  user_id        uuid not null references auth.users (id) on delete cascade,
  date           date not null,
  bowel_movement boolean,
  stool_form     text,
  discomfort     int,
  bloating       int,
  heartburn      int,
  fiber_servings int,
  fruit_servings int,
  veg_servings   int,
  red_flags      jsonb not null default '{}'::jsonb,
  notes          text,
  primary key (user_id, date)
);
comment on table public.intestinal_logs is 'Saúde intestinal: evacuação, desconforto, estufamento, azia, fibras, frutas, verduras e observações.';

create table public.measurements (
  user_id   uuid not null references auth.users (id) on delete cascade,
  date      date not null,
  weight_kg numeric(5,1),
  waist_cm  numeric(5,1),
  hip_cm    numeric(5,1),
  arm_cm    numeric(5,1),
  chest_cm  numeric(5,1),
  primary key (user_id, date)
);
comment on table public.measurements is 'Peso e medidas corporais (cintura, quadril, braço, peito).';

create table public.progress_photos (
  user_id      uuid not null references auth.users (id) on delete cascade,
  id           text not null,
  date         date not null,
  pose         text,
  storage_path text,
  created_at   timestamptz,
  primary key (user_id, id)
);
comment on table public.progress_photos is 'Fotos de evolução (o arquivo fica no bucket privado progress-photos).';

create table public.daily_checklists (
  user_id uuid  not null references auth.users (id) on delete cascade,
  date    date  not null,
  items   jsonb not null default '{}'::jsonb,
  steps   int,
  alcohol int,
  stress  int,
  primary key (user_id, date)
);
comment on table public.daily_checklists is 'Checklist do dia (itens marcados), passos, álcool e estresse.';

-- RLS: cada usuário lê apenas as próprias linhas; escrita só pelo gatilho.
do $$
declare
  t text;
  owner_col text;
begin
  foreach t in array array['profiles','reminders','workouts','workout_logs','meals','water_logs','sleep_logs',
                           'energy_logs','intestinal_logs','measurements','progress_photos','daily_checklists'] loop
    owner_col := case when t = 'profiles' then 'id' else 'user_id' end;
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('revoke all on public.%I from authenticated', t);
    execute format('grant select on public.%I to authenticated', t);
    execute format('create policy %I on public.%I for select to authenticated using ((select auth.uid()) = %I)',
                   t || ': dono lê', t, owner_col);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 3. Conversões seguras de JSON (dado ruim vira NULL, nunca erro)
-- ---------------------------------------------------------------------
create or replace function private.jnum(v jsonb) returns numeric
language plpgsql immutable set search_path = '' as $$
declare s text;
begin
  if v is null then return null; end if;
  if jsonb_typeof(v) = 'number' then return (v #>> '{}')::numeric; end if;
  if jsonb_typeof(v) = 'string' then
    s := replace(btrim(v #>> '{}'), ',', '.');
    if s ~ '^-?[0-9]{1,12}([.][0-9]{1,6})?$' then return s::numeric; end if;
  end if;
  return null;
exception when others then return null;
end $$;

create or replace function private.jint(v jsonb, lo numeric default -2000000000, hi numeric default 2000000000) returns int
language plpgsql immutable set search_path = '' as $$
declare n numeric := private.jnum(v);
begin
  if n is null or n < lo or n > hi then return null; end if;
  return round(n)::int;
end $$;

create or replace function private.jdec(v jsonb, lo numeric, hi numeric) returns numeric
language plpgsql immutable set search_path = '' as $$
declare n numeric := private.jnum(v);
begin
  if n is null or n < lo or n > hi then return null; end if;
  return round(n, 2);
end $$;

create or replace function private.jtxt(v jsonb, maxlen int default 300) returns text
language sql immutable set search_path = '' as $$
  select case when v is not null and jsonb_typeof(v) in ('string','number','boolean') then left(v #>> '{}', maxlen) end
$$;

create or replace function private.jbool(v jsonb) returns boolean
language sql immutable set search_path = '' as $$
  select case when v is null then null
              when jsonb_typeof(v) = 'boolean' then (v #>> '{}')::boolean
              when jsonb_typeof(v) = 'number' then (v #>> '{}')::numeric <> 0
              else null end
$$;

create or replace function private.tdate(s text) returns date
language plpgsql immutable set search_path = '' as $$
begin
  if s is null or s !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then return null; end if;
  return s::date;
exception when others then return null;
end $$;

create or replace function private.jdate(v jsonb) returns date
language sql immutable set search_path = '' as $$
  select private.tdate(private.jtxt(v, 10))
$$;

create or replace function private.jtime(v jsonb) returns text
language sql immutable set search_path = '' as $$
  select case when private.jtxt(v, 5) ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then private.jtxt(v, 5) end
$$;

create or replace function private.jts(v jsonb) returns timestamptz
language plpgsql immutable set search_path = '' as $$
declare n numeric := private.jnum(v);
begin
  -- epoch em milissegundos, entre 2020 e 2100
  if n is null or n < 1577836800000 or n > 4102444800000 then return null; end if;
  return to_timestamp(n / 1000.0);
end $$;

create or replace function private.jobj(v jsonb) returns jsonb
language sql immutable set search_path = '' as $$
  select case when v is not null and jsonb_typeof(v) = 'object' then v else '{}'::jsonb end
$$;

create or replace function private.jarr(v jsonb) returns jsonb
language sql immutable set search_path = '' as $$
  select case when v is not null and jsonb_typeof(v) = 'array' then v else '[]'::jsonb end
$$;

-- ---------------------------------------------------------------------
-- 4. Projeção dos documentos nas tabelas por assunto
-- ---------------------------------------------------------------------
create or replace function private.project_profile(p_user uuid, p jsonb) returns void
language plpgsql security definer set search_path = '' as $$
declare
  r jsonb := private.jobj(p -> 'reminders');
  mt jsonb := private.jobj(p -> 'mealTimes');
  days int[];
begin
  select array_agg(x::int) into days
    from jsonb_array_elements_text(private.jarr(p -> 'trainDays')) as x
   where x ~ '^[0-6]$';

  insert into public.profiles as pr (id, name, age, height_cm, start_weight_kg, goal_weight_kg, goal, activity_level,
                                     training_preference, train_days, train_time, wake_time, bed_time, water_goal_ml,
                                     steps_goal, start_date, updated_at)
  values (p_user,
          private.jtxt(p -> 'name', 60),
          private.jint(p -> 'age', 10, 120),
          private.jdec(p -> 'height', 80, 260),
          private.jdec(p -> 'startWeight', 25, 400),
          private.jdec(p -> 'goalWeight', 25, 400),
          private.jtxt(p -> 'goal', 200),
          private.jtxt(p -> 'activityLevel', 40),
          private.jtxt(p -> 'trainPref', 40),
          days,
          private.jtime(p -> 'trainTime'),
          private.jtime(p -> 'wakeTime'),
          private.jtime(p -> 'bedTime'),
          private.jint(p -> 'waterGoal', 0, 20000),
          private.jint(p -> 'stepsGoal', 0, 200000),
          private.jdate(p -> 'startDate'),
          now())
  on conflict (id) do update set
    name = excluded.name, age = excluded.age, height_cm = excluded.height_cm,
    start_weight_kg = excluded.start_weight_kg, goal_weight_kg = excluded.goal_weight_kg, goal = excluded.goal,
    activity_level = excluded.activity_level, training_preference = excluded.training_preference,
    train_days = excluded.train_days, train_time = excluded.train_time, wake_time = excluded.wake_time,
    bed_time = excluded.bed_time, water_goal_ml = excluded.water_goal_ml, steps_goal = excluded.steps_goal,
    start_date = excluded.start_date, updated_at = now();

  delete from public.reminders where user_id = p_user;
  insert into public.reminders (user_id, id, label, time, enabled, details) values
    (p_user, 'acordar',     'Acordar',                 private.jtime(p -> 'wakeTime'),  coalesce(private.jbool(r -> 'wake'), true), '{}'::jsonb),
    (p_user, 'agua',        'Água',                    null,                           coalesce(private.jbool(r -> 'water'), true),
       jsonb_build_object('a_cada_min', private.jint(r -> 'waterEvery', 15, 600))),
    (p_user, 'treino',      'Treino',                  private.jtime(p -> 'trainTime'), coalesce(private.jbool(r -> 'train'), true),
       jsonb_build_object('dias', to_jsonb(days))),
    (p_user, 'refeicoes',   'Refeições',               null,                           coalesce(private.jbool(r -> 'meals'), true), jsonb_build_object('horarios', mt)),
    (p_user, 'dormir',      'Desacelerar para dormir', private.jtime(p -> 'bedTime'),   coalesce(private.jbool(r -> 'sleep'), true), '{}'::jsonb),
    (p_user, 'foto',        'Foto do dia',             null,                           coalesce(private.jbool(r -> 'photo'), true), '{}'::jsonb),
    (p_user, 'suplementos', 'Suplementos',             null,                           coalesce(private.jbool(r -> 'supps'), true), '{}'::jsonb),
    (p_user, 'pesagem',     'Pesagem da semana',       private.jtime(r -> 'weighTime'), coalesce(private.jbool(r -> 'weigh'), true),
       jsonb_build_object('dia_da_semana', private.jint(r -> 'weighDay', 0, 6))),
    (p_user, 'checklist',   'Checklist do dia',        private.jtime(r -> 'checklistTime'), coalesce(private.jbool(r -> 'checklist'), true), '{}'::jsonb);
end $$;

create or replace function private.project_core(p_user uuid, c jsonb) returns void
language plpgsql security definer set search_path = '' as $$
declare ph jsonb;
begin
  delete from public.progress_photos where user_id = p_user;
  for ph in select value from jsonb_array_elements(private.jarr(c -> 'photos')) loop
    continue when jsonb_typeof(ph) <> 'object' or private.jtxt(ph -> 'id', 80) is null or private.jdate(ph -> 'date') is null;
    insert into public.progress_photos (user_id, id, date, pose, storage_path, created_at)
    values (p_user, private.jtxt(ph -> 'id', 80), private.jdate(ph -> 'date'), private.jtxt(ph -> 'pose', 20),
            private.jtxt(ph -> 'path', 300), private.jts(ph -> 'at'))
    on conflict do nothing;
  end loop;
end $$;

create or replace function private.project_month(p_user uuid, p_doc text, m jsonb) returns void
language plpgsql security definer set search_path = '' as $$
declare
  m_start date := private.tdate(substr(p_doc, 3, 7) || '-01');
  m_end   date;
  rec record;
  dt date;
  d jsonb;
  s jsonb;
  g jsonb;
  it jsonb;
  pos int;
  wid text;
  kind text;
begin
  if m_start is null then return; end if;
  m_end := (m_start + interval '1 month')::date;

  delete from public.water_logs       where user_id = p_user and date >= m_start and date < m_end;
  delete from public.sleep_logs       where user_id = p_user and date >= m_start and date < m_end;
  delete from public.energy_logs      where user_id = p_user and date >= m_start and date < m_end;
  delete from public.intestinal_logs  where user_id = p_user and date >= m_start and date < m_end;
  delete from public.meals            where user_id = p_user and date >= m_start and date < m_end;
  delete from public.daily_checklists where user_id = p_user and date >= m_start and date < m_end;
  delete from public.measurements     where user_id = p_user and date >= m_start and date < m_end;
  delete from public.workouts         where user_id = p_user and date >= m_start and date < m_end;
  if m is null then return; end if;

  -- dias
  for rec in select key, value from jsonb_each(private.jobj(m -> 'days')) loop
    dt := private.tdate(rec.key);
    d := rec.value;
    continue when dt is null or dt < m_start or dt >= m_end or jsonb_typeof(d) <> 'object';

    if coalesce(private.jint(d -> 'water', 0, 50000), 0) > 0 then
      insert into public.water_logs (user_id, date, total_ml, entries)
      values (p_user, dt, private.jint(d -> 'water', 0, 50000), jsonb_array_length(private.jarr(d -> 'waterLog')));
    end if;

    s := private.jobj(d -> 'sleep');
    if private.jnum(s -> 'hours') is not null or private.jtime(s -> 'bed') is not null or private.jint(s -> 'quality', 1, 4) is not null then
      insert into public.sleep_logs (user_id, date, bed_time, wake_time, hours, quality, notes)
      values (p_user, dt, private.jtime(s -> 'bed'), private.jtime(s -> 'wake'), private.jdec(s -> 'hours', 0, 24),
              private.jint(s -> 'quality', 1, 4), private.jtxt(s -> 'notes', 500));
    end if;
    if private.jint(s -> 'energy', 1, 10) is not null or private.jint(s -> 'day', 1, 10) is not null then
      insert into public.energy_logs (user_id, date, on_waking, during_day)
      values (p_user, dt, private.jint(s -> 'energy', 1, 10), private.jint(s -> 'day', 1, 10));
    end if;

    g := private.jobj(d -> 'gut');
    if g <> '{}'::jsonb then
      insert into public.intestinal_logs (user_id, date, bowel_movement, stool_form, discomfort, bloating, heartburn,
                                          fiber_servings, fruit_servings, veg_servings, red_flags, notes)
      values (p_user, dt, private.jbool(g -> 'bm'), private.jtxt(g -> 'form', 20), private.jint(g -> 'pain', 0, 3),
              private.jint(g -> 'bloat', 0, 3), private.jint(g -> 'heartburn', 0, 3), private.jint(g -> 'fiber', 0, 50),
              private.jint(g -> 'fruits', 0, 50), private.jint(g -> 'veg', 0, 50), private.jobj(g -> 'flags'),
              private.jtxt(g -> 'notes', 500));
    end if;

    insert into public.meals (user_id, date, meal, status)
    select p_user, dt, left(key, 20), left(value #>> '{}', 20)
      from jsonb_each(private.jobj(d -> 'meals'))
     where jsonb_typeof(value) = 'string'
    on conflict do nothing;

    if private.jobj(d -> 'checks') <> '{}'::jsonb or private.jint(d -> 'steps', 0, 200000) is not null
       or private.jint(d -> 'alcohol', 0, 50) is not null or private.jint(d -> 'stress', 1, 5) is not null then
      insert into public.daily_checklists (user_id, date, items, steps, alcohol, stress)
      values (p_user, dt, private.jobj(d -> 'checks'), private.jint(d -> 'steps', 0, 200000),
              private.jint(d -> 'alcohol', 0, 50), private.jint(d -> 'stress', 1, 5));
    end if;
  end loop;

  -- peso e medidas
  for it in select value from jsonb_array_elements(private.jarr(m -> 'weights')) loop
    dt := private.jdate(it -> 'date');
    continue when dt is null or dt < m_start or dt >= m_end or private.jdec(it -> 'kg', 25, 400) is null;
    insert into public.measurements (user_id, date, weight_kg) values (p_user, dt, private.jdec(it -> 'kg', 25, 400))
    on conflict (user_id, date) do update set weight_kg = excluded.weight_kg;
  end loop;
  for it in select value from jsonb_array_elements(private.jarr(m -> 'measures')) loop
    dt := private.jdate(it -> 'date');
    continue when dt is null or dt < m_start or dt >= m_end;
    insert into public.measurements (user_id, date, waist_cm, hip_cm, arm_cm, chest_cm)
    values (p_user, dt, private.jdec(it -> 'waist', 20, 300), private.jdec(it -> 'hip', 20, 300),
            private.jdec(it -> 'arm', 10, 150), private.jdec(it -> 'chest', 30, 300))
    on conflict (user_id, date) do update set
      waist_cm = excluded.waist_cm, hip_cm = excluded.hip_cm, arm_cm = excluded.arm_cm, chest_cm = excluded.chest_cm;
  end loop;

  -- treinos de academia (e seus exercícios)
  for s in select value from jsonb_array_elements(private.jarr(m -> 'sessions')) loop
    wid := private.jtxt(s -> 'id', 80);
    dt := private.jdate(s -> 'date');
    continue when wid is null or dt is null or dt < m_start or dt >= m_end;
    kind := case private.jtxt(s -> 'type', 2) when 'R' then 'rapido' when 'H' then 'casa' else 'musculacao' end;
    insert into public.workouts (user_id, id, date, kind, title, started_at, finished_at, completed, minutes, details)
    values (p_user, wid, dt, kind,
            case private.jtxt(s -> 'type', 2) when 'A' then 'Treino A' when 'B' then 'Treino B'
                                              when 'R' then 'Treino rápido' when 'H' then 'Treino em casa' else 'Treino' end,
            private.jts(s -> 'startedAt'), private.jts(s -> 'finishedAt'), coalesce(private.jbool(s -> 'completed'), false),
            case when private.jts(s -> 'finishedAt') is not null and private.jts(s -> 'startedAt') is not null
                 then greatest(1, round(extract(epoch from private.jts(s -> 'finishedAt') - private.jts(s -> 'startedAt')) / 60))::int end,
            jsonb_strip_nulls(jsonb_build_object('semana', private.jint(s -> 'week', 1, 520), 'fase', private.jint(s -> 'phase', 1, 9),
                               'parcial', private.jbool(s -> 'partial'), 'aquecimento', private.jbool(s -> 'warmupDone'))))
    on conflict do nothing;
    if not found then continue; end if;

    pos := 0;
    for it in select value from jsonb_array_elements(private.jarr(s -> 'items')) loop
      pos := pos + 1;
      continue when jsonb_typeof(it) <> 'object' or private.jtxt(it -> 'exId', 60) is null;
      insert into public.workout_logs (user_id, workout_id, position, exercise_id, exercise_kind, sets_planned, sets_done,
                                       reps, load_kg, rest_s, difficulty, note, done)
      values (p_user, wid, pos, private.jtxt(it -> 'exId', 60), private.jtxt(it -> 'kind', 10),
              jsonb_array_length(private.jarr(it -> 'sets')),
              (select count(*) from jsonb_array_elements(private.jarr(it -> 'sets')) x where private.jbool(x -> 'done')),
              (select coalesce(jsonb_agg(x -> 'reps'), '[]'::jsonb) from jsonb_array_elements(private.jarr(it -> 'sets')) x),
              private.jdec(it -> 'load', 0, 1000), private.jint(it -> 'rest', 0, 3600), private.jint(it -> 'difficulty', 1, 4),
              private.jtxt(it -> 'note', 500), private.jbool(it -> 'done'))
      on conflict do nothing;
    end loop;
  end loop;

  -- cardio
  for s in select value from jsonb_array_elements(private.jarr(m -> 'cardio')) loop
    wid := private.jtxt(s -> 'id', 80);
    dt := private.jdate(s -> 'date');
    continue when wid is null or dt is null or dt < m_start or dt >= m_end;
    insert into public.workouts (user_id, id, date, kind, title, started_at, completed, minutes, distance_km, effort, kcal, details)
    values (p_user, wid, dt, 'cardio', coalesce(private.jtxt(s -> 'kind', 30), 'cardio'), private.jts(s -> 'at'), true,
            private.jint(s -> 'minutes', 0, 1440), private.jdec(s -> 'km', 0, 500), private.jint(s -> 'rpe', 1, 10),
            private.jint(s -> 'kcal', 0, 20000),
            jsonb_strip_nulls(jsonb_build_object('velocidade_kmh', private.jdec(s -> 'speed', 0, 100),
                                                 'fonte_kcal', private.jtxt(s -> 'kcalSrc', 20))))
    on conflict do nothing;
  end loop;

  -- corrida e caminhada
  for s in select value from jsonb_array_elements(private.jarr(m -> 'runs')) loop
    wid := private.jtxt(s -> 'id', 80);
    dt := private.jdate(s -> 'date');
    continue when wid is null or dt is null or dt < m_start or dt >= m_end;
    insert into public.workouts (user_id, id, date, kind, title, started_at, completed, minutes, distance_km, effort, details)
    values (p_user, wid, dt, case when private.jtxt(s -> 'kind', 10) = 'walk' then 'caminhada' else 'corrida' end,
            private.jtxt(s -> 'title', 120), private.jts(s -> 'at'), true, private.jint(s -> 'minutes', 0, 1440),
            private.jdec(s -> 'km', 0, 500), private.jint(s -> 'rpe', 1, 10),
            jsonb_strip_nulls(jsonb_build_object('local', private.jtxt(s -> 'place', 20), 'dor', private.jint(s -> 'pain', 0, 3),
                                                 'area_dor', private.jtxt(s -> 'painArea', 30), 'semana_plano', private.jint(s -> 'week', 1, 200),
                                                 'origem', private.jtxt(s -> 'src', 10))))
    on conflict do nothing;
  end loop;
end $$;

create or replace function private.project_document() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := coalesce(new.user_id, old.user_id);
  v_doc text := coalesce(new.doc_id, old.doc_id);
  v_data jsonb := case when tg_op = 'DELETE' then null else new.data end;
begin
  begin
    if v_doc = 'profile' then
      if v_data is null then
        delete from public.reminders where user_id = v_user;
        update public.profiles set name = null, age = null, height_cm = null, start_weight_kg = null, goal_weight_kg = null,
          goal = null, activity_level = null, training_preference = null, train_days = null, train_time = null,
          wake_time = null, bed_time = null, water_goal_ml = null, steps_goal = null, start_date = null, updated_at = now()
         where id = v_user;
      else
        perform private.project_profile(v_user, v_data);
      end if;
    elsif v_doc = 'core' then
      if v_data is null then delete from public.progress_photos where user_id = v_user;
      else perform private.project_core(v_user, v_data);
      end if;
    elsif v_doc like 'm-%' then
      perform private.project_month(v_user, v_doc, v_data);
    end if;
  exception when others then
    -- a projeção nunca impede o app de salvar: o documento continua sendo a fonte de verdade
    raise warning 'saude-jr: projeção do documento % falhou: %', v_doc, sqlerrm;
  end;
  return null;
end $$;

create trigger app_documents_project after insert or update or delete on public.app_documents
  for each row execute function private.project_document();

-- ---------------------------------------------------------------------
-- 5. Perfil criado automaticamente no cadastro
-- ---------------------------------------------------------------------
create or replace function private.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, nullif(left(coalesce(new.raw_user_meta_data ->> 'name', ''), 60), ''))
  on conflict (id) do update set email = excluded.email;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function private.handle_new_user();

create or replace function private.handle_user_email() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  update public.profiles set email = new.email, updated_at = now() where id = new.id;
  return new;
end $$;

create trigger on_auth_user_email_changed after update of email on auth.users
  for each row when (old.email is distinct from new.email) execute function private.handle_user_email();

-- funções internas: ninguém de fora chama
revoke all on all functions in schema private from public;
revoke all on all functions in schema private from anon, authenticated;

-- ---------------------------------------------------------------------
-- 6. Controle de cadastros (usado só pela função "app", com a chave secreta)
-- ---------------------------------------------------------------------
create table public.signup_attempts (
  id         bigint generated always as identity primary key,
  ip_hash    text not null,
  created_at timestamptz not null default now()
);
comment on table public.signup_attempts is 'Limite de cadastros por origem (anti-abuso). Só a função do servidor acessa.';
create index signup_attempts_ip_time on public.signup_attempts (ip_hash, created_at);
alter table public.signup_attempts enable row level security;
revoke all on public.signup_attempts from anon;
revoke all on public.signup_attempts from authenticated;

-- ---------------------------------------------------------------------
-- 7. Fotos: bucket privado, uma pasta por usuário
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('progress-photos', 'progress-photos', false, 6291456, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit,
                               allowed_mime_types = excluded.allowed_mime_types;

create policy "progress-photos: dono lê" on storage.objects for select to authenticated
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "progress-photos: dono envia" on storage.objects for insert to authenticated
  with check (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "progress-photos: dono altera" on storage.objects for update to authenticated
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "progress-photos: dono apaga" on storage.objects for delete to authenticated
  using (bucket_id = 'progress-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
