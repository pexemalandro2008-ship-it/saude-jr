// Saúde Jr. — função de servidor "app" (Supabase Edge Function).
// Chaves vêm das variáveis de ambiente que o próprio Supabase injeta; nada fica no código.
// Publicada com verify_jwt = false: /config e /signup precisam funcionar antes do login.
// A proteção fica no código: validação dos dados e limite de cadastros por origem e por dia.
import { createClient } from 'npm:@supabase/supabase-js@2';
import { createHandler } from './logic.js';

const pick = (name: string): string | null => {
  try {
    const o = JSON.parse(Deno.env.get(name) || '{}');
    return o.default || (Object.values(o)[0] as string) || null;
  } catch (_e) {
    return null;
  }
};

const url = Deno.env.get('SUPABASE_URL') ?? '';
const publishableKey = pick('SUPABASE_PUBLISHABLE_KEYS') || Deno.env.get('SUPABASE_ANON_KEY') || null;
const secretKey = pick('SUPABASE_SECRET_KEYS') || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const admin = createClient(url, secretKey, { auth: { persistSession: false, autoRefreshToken: false } });

const handler = createHandler({
  publishableKey,
  salt: secretKey,
  async countAttempts(ipHash: string, since: string) {
    const { count, error } = await admin.from('signup_attempts').select('id', { count: 'exact', head: true })
      .eq('ip_hash', ipHash).gte('created_at', since);
    if (error) throw error;
    return count ?? 0;
  },
  async countAll(since: string) {
    const { count, error } = await admin.from('signup_attempts').select('id', { count: 'exact', head: true })
      .gte('created_at', since);
    if (error) throw error;
    return count ?? 0;
  },
  async recordAttempt(ipHash: string) {
    const { error } = await admin.from('signup_attempts').insert({ ip_hash: ipHash });
    if (error) throw error;
    await admin.from('signup_attempts').delete().lt('created_at', new Date(Date.now() - 7 * 86400e3).toISOString());
  },
  async createUser({ email, password, name }: { email: string; password: string; name: string }) {
    const { error } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: name ? { name } : {},
    });
    return error ? { error: { code: (error as { code?: string }).code, status: error.status, message: error.message } } : {};
  },
});

Deno.serve(handler);
