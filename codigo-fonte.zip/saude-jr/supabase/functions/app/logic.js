// Saúde Jr. — lógica da função de servidor "app".
//
//   GET  /app/config  → chave pública (publishable) para o app falar com o Supabase.
//                       Assim nenhuma chave fica gravada no código ou no repositório.
//   POST /app/signup  → cria a conta com e-mail e senha (já confirmada) e o app entra em seguida.
//
// Sem dependências do Deno: o mesmo arquivo roda no Supabase (Deno) e nos testes (Node).

export const LIMITS = { perIpHour: 5, perDay: 100 };

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@.]+(\.[^\s@.]+)*\.[a-z]{2,24}$/i;

export function validateSignup(body) {
  const email = String((body && body.email) || '').trim().toLowerCase();
  const password = String((body && body.password) || '');
  const name = String((body && body.name) || '').trim().replace(/\s+/g, ' ').slice(0, 60);
  if (!email || email.length > 254 || !EMAIL_RE.test(email)) return { error: 'Confira o e-mail.' };
  if (password.length < 8) return { error: 'A senha precisa ter pelo menos 8 caracteres.' };
  if (password.length > 72) return { error: 'A senha pode ter no máximo 72 caracteres.' };
  if (!/[a-zA-ZÀ-ÿ]/.test(password) || !/[0-9]/.test(password)) return { error: 'Use letras e números na senha.' };
  const local = email.split('@')[0];
  if (local.length >= 4 && password.toLowerCase().includes(local)) return { error: 'A senha não pode conter o seu e-mail.' };
  return { email, password, name };
}

export const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

export async function sha256hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function clientIp(req) {
  const h = (n) => req.headers.get(n) || '';
  return (h('cf-connecting-ip') || h('x-real-ip') || h('x-forwarded-for').split(',')[0] || '').trim() || 'desconhecido';
}

/**
 * deps = {
 *   publishableKey: string | null,
 *   salt: string,                                   // segredo do servidor: IPs são guardados só como hash
 *   countAttempts(ipHash, sinceIso) → Promise<number>,
 *   countAll(sinceIso) → Promise<number>,
 *   recordAttempt(ipHash) → Promise<void>,
 *   createUser({ email, password, name }) → Promise<{ error?: { code?, status?, message? } }>,
 * }
 */
export function createHandler(deps) {
  return async function handle(req) {
    const path = new URL(req.url).pathname.replace(/\/+$/, '');
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    if (req.method === 'GET' && /\/config$/.test(path)) {
      if (!deps.publishableKey) return json(503, { error: 'Configuração indisponível.' });
      return json(200, { key: deps.publishableKey, signup: true });
    }

    if (req.method === 'POST' && /\/signup$/.test(path)) {
      let body;
      try { body = await req.json(); } catch (e) { return json(400, { error: 'Pedido inválido.' }); }
      const v = validateSignup(body);
      if (v.error) return json(400, { error: v.error });

      const ipHash = await sha256hex(deps.salt + ':' + clientIp(req));
      const now = Date.now();
      try {
        const [nIp, nAll] = await Promise.all([
          deps.countAttempts(ipHash, new Date(now - 3600e3).toISOString()),
          deps.countAll(new Date(now - 86400e3).toISOString()),
        ]);
        if (nIp >= LIMITS.perIpHour || nAll >= LIMITS.perDay) {
          return json(429, { error: 'Muitas tentativas de cadastro. Tente de novo daqui a 1 hora.' });
        }
        await deps.recordAttempt(ipHash);
      } catch (e) {
        return json(503, { error: 'Servidor indisponível. Tente de novo em instantes.' });
      }

      let r;
      try { r = await deps.createUser(v); } catch (e) { r = { error: { code: 'unexpected' } }; }
      if (r && r.error) {
        const code = r.error.code || '';
        if (code === 'email_exists' || code === 'user_already_exists' || /already (been )?registered/i.test(r.error.message || '')) {
          return json(409, { error: 'Este e-mail já tem conta. Toque em “Entrar” ou em “Esqueci a senha”.' });
        }
        if (code === 'weak_password') return json(400, { error: 'Senha fraca. Use pelo menos 8 caracteres, com letras e números.' });
        if (code === 'email_address_invalid' || code === 'validation_failed') return json(400, { error: 'Confira o e-mail.' });
        return json(500, { error: 'Não foi possível criar a conta agora. Tente de novo em instantes.' });
      }
      return json(201, { ok: true });
    }

    return json(404, { error: 'Não encontrado.' });
  };
}
