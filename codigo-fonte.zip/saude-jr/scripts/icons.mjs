// Gera os ícones PNG do app a partir de public/icons/icon.svg (usa o Chromium do Playwright).
//   npm run icons      (só é preciso rodar quando o desenho do ícone mudar)
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); } catch (e) { playwright = require('/home/claude/.npm-global/lib/node_modules/playwright'); }

const dir = path.join(ROOT, 'public', 'icons');
const svg = fs.readFileSync(path.join(dir, 'icon.svg'), 'utf8');
const browser = await playwright.chromium.launch();
const page = await browser.newPage({ deviceScaleFactor: 1 });
for (const [name, size] of [['icon-512.png', 512], ['icon-192.png', 192], ['icon-maskable-512.png', 512], ['apple-touch-icon.png', 180], ['favicon-32.png', 32]]) {
  await page.setViewportSize({ width: size, height: size });
  const markup = svg.replace(/width="\d+" height="\d+"/, `width="${size}" height="${size}"`);
  await page.setContent(`<html><body style="margin:0;background:#070908">${markup}</body></html>`);
  await page.screenshot({ path: path.join(dir, name), clip: { x: 0, y: 0, width: size, height: size } });
}
await browser.close();
console.log('✓ ícones gerados em public/icons');
