// Saúde Jr. — build de produção
//
//   node scripts/build.mjs          → dist/pwa/     app instalável (é o que vai para o GitHub Pages)
//   node scripts/build.mjs claude   → dist/claude/  versão publicada dentro do Claude (dados na conta do Claude)
//   node scripts/build.mjs all      → as duas
//
// Variáveis de ambiente (ou arquivo .env, fora do git — veja .env.example):
//   SUPABASE_URL   endereço do projeto Supabase (ex.: https://abcd.supabase.co). Liga login e sincronização.
//                  Sem ela, o app roda em modo de desenvolvimento, só neste aparelho.
//   A chave pública NÃO entra no código: o app busca na função do servidor (/functions/v1/app/config).
import fs from 'fs';
import path from 'path';
import vm from 'vm';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const at = (...p) => path.join(ROOT, ...p);
const read = (p) => fs.readFileSync(at(p), 'utf8');
const VERSION = JSON.parse(read('package.json')).version;

// .env local (nunca vai para o repositório)
if (fs.existsSync(at('.env'))) {
  for (const line of read('.env').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
const SUPABASE_URL = String(process.env.SUPABASE_URL || '').trim().replace(/\/+$/, '');
if (SUPABASE_URL && !/^https?:\/\/[a-z0-9.-]+(:\d+)?$/i.test(SUPABASE_URL)) {
  console.error(`SUPABASE_URL inválida: "${SUPABASE_URL}". Use só o endereço, ex.: https://abcd.supabase.co`);
  process.exit(1);
}
// segurança: nada de segredo no build
for (const k of Object.keys(process.env)) {
  if (/SERVICE_ROLE|SECRET_KEY|DB_PASSWORD/.test(k) && process.env[k]) console.warn(`⚠ ${k} está definida no ambiente, mas nunca é usada no app (fica só no servidor).`);
}

const LIB = ['src/lib/logic.js', 'src/lib/content.js', 'src/lib/store.js', 'src/lib/photos.js', 'src/lib/cloud.js'];
const APP = ['core', 'screens-main', 'screens-more', 'run', 'food', 'photos-view', 'agenda', 'auth', 'actions'].map((f) => `src/app/${f}.js`);
const SUPABASE_UMD = 'node_modules/@supabase/supabase-js/dist/umd/supabase.js';

// versão pública: começa sem dados pessoais (o perfil inicial pode vir no link: #ini=idade,altura,peso,meta)
const PUBLIC_DEFAULTS = { name: '', age: null, height: null, startWeight: null, goalWeight: null };

const GOOGLE_FONTS = `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..900&family=Figtree:wght@400..800&display=swap">`;
const LOCAL_FONTS = `<link rel="preload" href="fonts/archivo.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="fonts/figtree.woff2" as="font" type="font/woff2" crossorigin>
<style>
@font-face{font-family:"Archivo";font-style:normal;font-display:swap;font-weight:100 900;font-stretch:62% 125%;src:url(fonts/archivo.woff2) format("woff2")}
@font-face{font-family:"Figtree";font-style:normal;font-display:swap;font-weight:300 900;src:url(fonts/figtree.woff2) format("woff2")}
</style>`;

function assemble(target, { fonts, images, defaults, supabase }) {
  const tgt = `window.MV_TARGET = ${JSON.stringify(target)}; window.MV_VERSION = ${JSON.stringify(VERSION)};`
    + (defaults ? ` window.MV_DEFAULTS = ${JSON.stringify(defaults)};` : '')
    + (supabase ? ` window.MV_SUPABASE = ${JSON.stringify({ url: supabase })};` : '');
  const lib = LIB.map(read).join('\n');
  const app = APP.map(read).join('\n');
  // checagem de sintaxe: o build falha se algum script não compila
  for (const [name, code] of [['lib', lib], ['app', `(function(){'use strict';\n${app}\n})`]]) {
    try { new vm.Script(code, { filename: name }); } catch (e) { throw new Error(`Erro de sintaxe em ${name}: ${e.message}`); }
  }
  return read('src/index.html')
    .replace('<!--FONTS-->', () => fonts)
    .replace('/*STYLES*/', () => read('src/styles.css'))
    .replace('/*TARGET*/', () => tgt)
    .replace('<!--VENDOR-->', () => (supabase ? '<script src="vendor/supabase.js"></script>' : ''))
    .replace('/*LIB*/', () => lib)
    .replace('/*IMAGES*/', () => JSON.stringify(images || {}))
    .replace('/*APP*/', () => app);
}

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    const src = path.join(from, f), dst = path.join(to, f);
    if (fs.statSync(src).isDirectory()) copyDir(src, dst); else fs.copyFileSync(src, dst);
  }
}

function buildPwa() {
  const out = at('dist', process.env.PWA_OUT || 'pwa');
  fs.rmSync(out, { recursive: true, force: true });
  copyDir(at('public'), out);
  if (SUPABASE_URL) {
    if (!fs.existsSync(at(SUPABASE_UMD))) throw new Error('Biblioteca do Supabase não encontrada. Rode: npm ci');
    fs.mkdirSync(path.join(out, 'vendor'), { recursive: true });
    fs.copyFileSync(at(SUPABASE_UMD), path.join(out, 'vendor', 'supabase.js'));
    fs.copyFileSync(at('node_modules/@supabase/supabase-js/LICENSE'), path.join(out, 'vendor', 'LICENSE-supabase-js.txt'));
  }
  const [head, body] = assemble('pwa', { fonts: LOCAL_FONTS, defaults: PUBLIC_DEFAULTS, supabase: SUPABASE_URL }).split('<!--BODY-->');
  const connect = SUPABASE_URL ? ` ${SUPABASE_URL} ${SUPABASE_URL.replace(/^http/, 'ws')}` : '';
  const meta = `<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="description" content="Saúde Jr.: treino, corrida até os 10 km, alimentação, água, sono e evolução. App pessoal com conta própria.">
<meta name="theme-color" content="#070908">
<meta name="color-scheme" content="dark">
<meta name="referrer" content="strict-origin-when-cross-origin">
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'${connect} https://calendar.google.com; manifest-src 'self'; worker-src 'self'; base-uri 'self'; form-action 'self'; object-src 'none'">
<link rel="manifest" href="manifest.json">
<link rel="icon" type="image/svg+xml" href="icons/icon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="icons/favicon-32.png">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Saúde Jr.">
<style>html{-webkit-text-size-adjust:100%;background:#070908}body{margin:0;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px);min-height:100dvh}img{max-width:100%}[hidden]{display:none!important}</style>
`;
  fs.writeFileSync(path.join(out, 'index.html'), `<!doctype html>\n<html lang="pt-BR">\n<head>\n${meta}${head}</head>\n<body>${body}</body>\n</html>\n`);
  const manifest = {
    id: './',
    name: 'Saúde Jr.',
    short_name: 'Saúde Jr.',
    description: 'Treino, corrida até os 10 km, alimentação, água, sono e evolução.',
    lang: 'pt-BR',
    dir: 'ltr',
    start_url: './',
    scope: './',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#070908',
    theme_color: '#070908',
    categories: ['health', 'fitness', 'lifestyle'],
    icons: [
      { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
    shortcuts: [
      { name: 'Agenda de hoje', short_name: 'Agenda', url: './?go=agenda', icons: [{ src: 'icons/icon-192.png', sizes: '192x192' }] },
      { name: 'Foto do dia', short_name: 'Foto', url: './?go=fotos', icons: [{ src: 'icons/icon-192.png', sizes: '192x192' }] },
      { name: 'Corrida', short_name: 'Corrida', url: './?go=corrida', icons: [{ src: 'icons/icon-192.png', sizes: '192x192' }] },
    ],
  };
  fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest, null, 2));
  const sw = read('src/sw.js').replace('__VERSION__', VERSION).replace('/*EXTRA_CORE*/', SUPABASE_URL ? "'./vendor/supabase.js'," : '');
  new vm.Script(sw, { filename: 'sw.js' });
  fs.writeFileSync(path.join(out, 'sw.js'), sw);
  fs.writeFileSync(path.join(out, '.nojekyll'), '');
  fs.writeFileSync(path.join(out, '404.html'), `<!doctype html><meta charset="utf-8"><title>Saúde Jr.</title><meta http-equiv="refresh" content="0;url=./"><a href="./">Abrir o Saúde Jr.</a>\n`);
  return out;
}

function buildClaude() {
  const out = at('dist', 'claude');
  fs.rmSync(out, { recursive: true, force: true });
  fs.mkdirSync(out, { recursive: true });
  // fotos-meta pessoais: só na versão privada do Claude, nunca no repositório (pasta private/ fica fora do git)
  const img = (f) => (fs.existsSync(at('private', f)) ? 'data:image/jpeg;base64,' + fs.readFileSync(at('private', f)).toString('base64') : null);
  const before = img('before.jpg'), after = img('after.jpg');
  const html = assemble('artifact', { fonts: GOOGLE_FONTS, images: before && after ? { before, after } : {} }).replace('<!--BODY-->\n', '');
  fs.writeFileSync(path.join(out, 'saude-jr.html'), html);
  // mesma página com o esqueleto que a publicação usa, para testes locais
  const skeleton = `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px/1.4 system-ui,sans-serif;background:#f6f6f4}img{max-width:100%}[hidden]{display:none!important}</style></head><body>${html}</body></html>`;
  fs.writeFileSync(path.join(out, 'harness.html'), skeleton);
  return out;
}

const target = process.argv[2] || 'pwa';
const kb = (f) => (fs.statSync(f).size / 1024).toFixed(0) + ' KB';
if (target === 'pwa' || target === 'all') {
  const o = buildPwa();
  console.log(`✓ PWA ${VERSION} → dist/${process.env.PWA_OUT || 'pwa'} (index.html ${kb(path.join(o, 'index.html'))}) · ${SUPABASE_URL ? 'login e nuvem: ' + SUPABASE_URL : 'sem SUPABASE_URL: modo de desenvolvimento (só neste aparelho)'}`);
}
if (target === 'claude' || target === 'all') { const o = buildClaude(); console.log(`✓ Claude ${VERSION} → dist/claude (saude-jr.html ${kb(path.join(o, 'saude-jr.html'))})`); }
if (!['pwa', 'claude', 'all'].includes(target)) { console.error('Use: node scripts/build.mjs [pwa|claude|all]'); process.exit(1); }
