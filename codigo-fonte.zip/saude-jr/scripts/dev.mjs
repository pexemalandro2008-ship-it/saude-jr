// Desenvolvimento: gera o app, abre um servidor local e refaz o build a cada alteração em src/ ou public/.
//   npm run dev   →  http://localhost:5173/
import fs from 'fs';
import path from 'path';
import { spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import { serve } from './serve.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const port = Number(process.env.PORT || 5173);
const build = () => spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'build.mjs'), 'pwa'], { stdio: 'inherit' });

build();
await serve('dist/pwa', port);
console.log(`\nSaúde Jr. rodando em http://localhost:${port}/  (Ctrl+C para parar)\n`);
let t = null;
for (const dir of ['src', 'public']) {
  fs.watch(path.join(ROOT, dir), { recursive: true }, () => { clearTimeout(t); t = setTimeout(build, 150); });
}
