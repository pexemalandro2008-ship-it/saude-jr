/* ===== Saúde Jr. — telas (comida, evolução, meta, mais) ===== */

/* =============== COMIDA =============== */
function vComida() {
  const k = today(), sub = ui.sub.comida;
  return [
    topBar(),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Alimentação</h1><p class="muted">Barata, simples e brasileira. Sem dieta da moda.</p></div>`,
    `<div class="seg four" role="group">${[['refeicoes', 'Refeições'], ['suplementos', 'Suplementos'], ['marmita', 'Marmita'], ['intestino', 'Intestino']].map(([v, l]) => `<button data-act="seg" data-group="comida" data-v="${v}" aria-pressed="${sub === v}">${l}</button>`).join('')}</div>`,
    sub === 'marmita' ? vMarmita(k) : sub === 'intestino' ? vIntestino(k) : sub === 'suplementos' ? vSuplementos(k) : vRefeicoes(k),
  ].join('');
}
function plateSvg() {
  return `<svg viewBox="0 0 100 100" width="104" height="104" role="img" aria-label="Prato: metade legumes, um quarto proteína, um quarto carboidrato" style="flex:none">
    <circle cx="50" cy="50" r="47" fill="none" style="stroke:var(--line)" stroke-width="2"/>
    <path d="M50 50 L50 6 A44 44 0 0 0 50 94 Z" style="fill:var(--go)"/>
    <path d="M50 50 L50 6 A44 44 0 0 1 94 50 Z" style="fill:var(--fg)"/>
    <path d="M50 50 L94 50 A44 44 0 0 1 50 94 Z" style="fill:var(--warn)"/>
    <path d="M50 6 V94 M50 50 H94" style="stroke:var(--surface)" stroke-width="2.5"/></svg>`;
}
function vMarmita(k) {
  const list = coreRead().marmitas || [], d = MEMO().days[k] || {};
  const dot = (v) => `<i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(${v});margin-right:6px"></i>`;
  return `<section class="card"><span class="eyebrow">Minha marmita</span><div class="h2">Jantar equilibrado, sem pensar</div>
      <div class="row" style="gap:16px;align-items:center">${plateSvg()}<div class="stack-sm small">
        <span>${dot('--go')}<b>Metade legumes</b> <span class="muted">100–200 g</span></span>
        <span>${dot('--fg')}<b>¼ proteína</b> <span class="muted">≥ 25 g de proteína</span></span>
        <span>${dot('--warn')}<b>¼ carboidrato</b> <span class="muted">80–150 g</span></span></div></div>
      <p class="small muted">Em geral, um jantar de emagrecimento fica entre 350 e 650 kcal. O app só mostra calorias e proteína quando você informa os gramas ou os valores do rótulo.</p></section>
    ${list.length ? `<section class="card tight"><span class="eyebrow">Jantar de hoje</span><div class="chips">${list.map((m) => `<button class="chip" data-act="dinner" data-id="${m.id}" aria-pressed="${d.dinner === m.id}">${esc(m.name)}</button>`).join('')}</div></section>` : ''}
    ${list.map((m) => marmitaCard(m, d.dinner)).join('')}
    ${!list.length ? `<section class="card card-flat"><p class="small muted">Cadastre as marmitas que você compra ou prepara. O app avalia a composição e, com os gramas ou o rótulo, mostra calorias e proteína.</p></section>` : ''}
    <button class="btn btn-soft btn-block" data-act="sheet" data-s="marmita">${icon('plus')}Cadastrar marmita</button>
    ${marmitaSugestoes(list)}`;
}
function marmitaSugestoes(list) {
  const have = new Set(list.map((m) => m.name));
  return `<section class="card"><span class="eyebrow">Marmitas fitness · sugestões</span>
    <p class="small muted">Simples, baratas e com comida de verdade. Toque em adicionar e ajuste os gramas se quiser.</p>
    <div>${C.MARMITA_SUGESTOES.map((s, i) => {
      const t = L.marmitaTotals(s, C.FOODS);
      const parts = [[s.protFood, s.protG], [s.carbFood, s.carbG], [s.vegFood, s.vegG]].map(([f, g]) => `${esc(foodName(f))} ${g} g`).join(' · ');
      return `<div class="sug"><div class="grow"><b>${esc(s.name)}</b><br><span class="small muted">${parts}</span><br><span class="tiny faint">≈ ${fmt0(t.kcal)} kcal · ${fmt0(t.prot)} g de proteína (estimativa) · ${esc(s.tip)}</span></div>
        ${have.has(s.name) ? `<span class="badge ok">${icon('check', 'ic-sm')}na lista</span>` : `<button class="btn btn-ghost btn-sm" data-act="addSugMarmita" data-i="${i}">${icon('plus', 'ic-sm')}Adicionar</button>`}</div>`;
    }).join('')}</div>
    <p class="tiny faint">Calorias e proteína estimadas pela tabela de alimentos do app (TACO/USDA), para porções cozidas. Não é prescrição: um nutricionista ajusta as quantidades para você.</p></section>`;
}
function foodName(id) { return id && C.FOODS[id] ? C.FOODS[id].name : id === 'outro' ? 'Outro' : '—'; }
function marmitaCard(m, sel) {
  const tot = L.marmitaTotals(m, C.FOODS), chk = L.marmitaCheck(m, tot);
  const lv = { ok: ['ok', 'Equilibrada'], quase: ['warn', 'Quase lá'], ajustar: ['alert', 'Ajustar'] }[chk.level];
  const src = tot.source === 'rotulo' ? 'do rótulo' : tot.source === 'estimativa' ? 'estimado · TACO/USDA' : tot.source === 'estimativa-media' ? 'estimado · média' : 'não informado';
  const part = (f, g, other) => `${esc(f === 'outro' ? other || 'Outro' : foodName(f))}${fin(L.num(g)) ? ` · ${L.num(g)} g` : ''}`;
  return `<section class="card"><div class="between"><div class="h3">${esc(m.name)}</div><span class="badge ${lv[0]}">${lv[1]}</span></div>
    <div><div class="kv"><span class="k">Proteína</span><span class="v">${part(m.protFood, m.protG, m.protOther)}</span></div>
      <div class="kv"><span class="k">Carboidrato</span><span class="v">${m.carbFood === 'nenhum' ? 'Sem carboidrato' : part(m.carbFood, m.carbG, m.carbOther)}</span></div>
      <div class="kv"><span class="k">Vegetais</span><span class="v">${part(m.vegFood, m.vegG, m.vegOther)}</span></div>
      <div class="kv"><span class="k">Quantidade total</span><span class="v">${fin(L.num(m.qty)) ? L.num(m.qty) + ' g' : '—'}</span></div></div>
    <div class="grid2"><div class="metric"><span class="num">${tot.kcal != null ? fmt0(tot.kcal) : '—'}</span><span class="cap">kcal · ${src}</span></div><div class="metric"><span class="num">${tot.prot != null ? fmt0(tot.prot) : '—'}<span class="unit">g</span></span><span class="cap">proteína · ${src}</span></div></div>
    ${chk.tips.length ? `<div class="note warn">${icon('info')}<div class="stack-sm">${chk.tips.map((t) => `<span>${esc(t)}</span>`).join('')}</div></div>` : `<div class="note go">${icon('check')}<span>Composição equilibrada para o jantar.</span></div>`}
    <div class="btn-row"><button class="btn btn-ghost btn-sm" data-act="sheet" data-s="marmita" data-id="${m.id}">${icon('edit', 'ic-sm')}Editar</button><button class="btn btn-sm ${sel === m.id ? 'btn-soft' : ''}" data-act="dinner" data-id="${m.id}">${sel === m.id ? icon('check', 'ic-sm') + 'Hoje' : 'Usar hoje'}</button></div></section>`;
}
function gutCounter(f, label, sub, v) {
  return `<div class="between"><div class="grow"><b>${label}</b><br><span class="tiny faint">${sub}</span></div>
    <div class="stepper" style="width:150px;flex:none"><button data-act="gut" data-f="${f}" data-d="-1" aria-label="Menos ${label}">${icon('minus', 'ic-sm')}</button><span class="val">${v || 0}</span><button data-act="gut" data-f="${f}" data-d="1" aria-label="Mais ${label}">${icon('plus', 'ic-sm')}</button></div></div>`;
}
function vIntestino(k) {
  const mm = MEMO(), day = mm.days[k] || {}, g = day.gut || {}, p = prof(), fl = g.flags || {};
  const last7 = [0, 1, 2, 3, 4, 5, 6].map((i) => L.addDays(k, i - 6));
  const gd = last7.map((dk) => (mm.days[dk] || {}).gut);
  const flag = L.gutFlag(gd.map((x) => (x ? { blood: !!(x.flags && x.flags.blood), pain: x.flags && x.flags.severe ? 3 : x.pain || 0, bloat: x.bloat || 0, bm: x.bm } : undefined)));
  const scale4 = (f, v) => `<div class="scale" style="--n:4">${['Nenhum', 'Leve', 'Moderado', 'Forte'].map((l, i) => `<button data-act="gutSet" data-f="${f}" data-v="${i}" aria-pressed="${v === i}" style="font-family:var(--body);font-size:13px;font-weight:700">${l}</button>`).join('')}</div>`;
  const regular = gd.filter((x) => x && x.bm === true).length;
  return `${flag === 'urgente' ? `<section class="card card-alert"><div class="row">${icon('info')}<b>Procure avaliação médica o quanto antes</b></div><p class="small">Sangue nas fezes ou dor abdominal forte precisam ser avaliados por um médico. Se a dor for intensa ou vier com febre, vá a um pronto atendimento.</p></section>`
    : flag === 'atencao' ? `<section class="card card-warn"><div class="row">${icon('info')}<b>Vale conversar com um médico</b></div><p class="small">Vários dias sem evacuar ou com desconforto e estufamento frequentes. Se continuar, marque uma consulta. O app não faz diagnóstico.</p></section>` : ''}
    <section class="card"><span class="eyebrow">Intestino em dia · hoje</span>
      ${gutCounter('fiber', 'Porções de fibra', 'feijão, aveia, integrais, frutas com casca', g.fiber)}
      ${gutCounter('fruits', 'Frutas', 'meta: 2 a 3 por dia', g.fruits)}
      ${gutCounter('veg', 'Verduras e legumes', 'meta: 2 ou mais porções', g.veg)}
      <div class="kv"><span class="k">Água</span><span class="v">${fmt0(day.water || 0)} / ${fmt0(p.waterGoal)} ml</span></div></section>
    <section class="card"><span class="eyebrow">Como está hoje</span>
      <div class="field"><span class="lbl">Evacuou hoje?</span><div class="seg"><button data-act="gutSet" data-f="bm" data-v="1" aria-pressed="${g.bm === true}">Sim</button><button data-act="gutSet" data-f="bm" data-v="0" aria-pressed="${g.bm === false}">Ainda não</button></div></div>
      ${g.bm === true ? `<div class="field"><span class="lbl">Como estava?</span><div class="chips">${[['dura', 'Endurecida'], ['normal', 'Normal'], ['mole', 'Amolecida']].map(([v, l]) => `<button class="chip" data-act="gutSet" data-f="form" data-v="${v}" aria-pressed="${g.form === v}">${l}</button>`).join('')}</div></div>` : ''}
      <div class="field"><span class="lbl">Desconforto abdominal</span>${scale4('pain', g.pain)}</div>
      <div class="field"><span class="lbl">Estufamento (inchaço)</span>${scale4('bloat', g.bloat)}</div>
      <div class="field"><span class="lbl">Azia</span>${scale4('heartburn', g.heartburn)}</div>
      <div class="field"><label for="gut-notes">Observações</label><textarea id="gut-notes" data-change="gutNotes" maxlength="300" placeholder="Ex.: azia depois do almoço, comi fritura">${esc(g.notes || '')}</textarea></div></section>
    <section class="card"><div class="between"><span class="eyebrow">Regularidade · 7 dias</span><span class="badge ${regular >= 5 ? 'ok' : ''}">${regular}/7 dias</span></div>
      <div class="week">${last7.map((dk, i) => { const x = gd[i]; const st = x && x.bm === true ? 'done' : ''; return `<div class="d ${st} ${dk === k ? 'today' : ''}"><span>${WD1[L.weekday(dk)]}</span><b>${L.parse(dk).getDate()}</b><span class="m">${x && x.bm === true ? icon('check') : ''}</span></div>`; }).join('')}</div>
      ${gutTrend(gd)}</section>
    <section class="card"><span class="eyebrow">Sinais de alerta</span><p class="small muted">Marque se acontecer. O app não faz diagnóstico: ele avisa quando procurar um médico.</p>
      ${C.GUT_RED_FLAGS.map(([id, l]) => `<div class="switch-row"><span>${l}</span><button class="switch" role="switch" aria-checked="${!!fl[id]}" aria-label="${esc(l)}" data-act="gutFlag" data-f="${id}"></button></div>`).join('')}
      ${fl.change || fl.fever ? `<div class="note warn">${icon('info')}<span>Esses sinais merecem avaliação médica. Marque uma consulta.</span></div>` : ''}</section>
    <section class="card"><span class="eyebrow">Dicas simples</span><ul class="clean">${C.GUT_TIPS.map((t) => `<li>${icon('leaf', 'ic-sm')}<span class="small">${t}</span></li>`).join('')}</ul></section>`;
}

/** tendência simples dos últimos 7 dias (médias de 0 a 3) */
function gutTrend(gd) {
  const days = gd.filter(Boolean);
  if (days.length < 2) return '<p class="tiny faint">Registre alguns dias para ver a tendência.</p>';
  const avg = (f) => { const v = days.map((x) => x[f]).filter(fin); return v.length ? L.avg(v) : null; };
  const lvl = (v) => (v == null ? '—' : v < 0.5 ? 'nenhum' : v < 1.5 ? 'leve' : v < 2.5 ? 'moderado' : 'forte');
  const fib = avg('fiber'), fr = avg('fruits');
  return `<div class="trend-row"><div><span class="cap">Desconforto</span><b>${lvl(avg('pain'))}</b></div><div><span class="cap">Inchaço</span><b>${lvl(avg('bloat'))}</b></div><div><span class="cap">Azia</span><b>${lvl(avg('heartburn'))}</b></div></div>
    <p class="tiny faint">Média dos dias registrados${fib != null ? ` · fibras ${fmt1(fib)} porções/dia` : ''}${fr != null ? ` · frutas ${fmt1(fr)}/dia` : ''}.</p>`;
}

/* =============== EVOLUÇÃO =============== */
function vEvolucao() {
  const sub = ui.sub.evolucao;
  return [
    topBar(),
    `<div class="stack-sm" style="padding:4px 2px"><h1>${sub === 'meta' ? 'Minha meta' : sub === 'fotos' ? 'Fotos diárias' : 'Minha evolução'}</h1></div>`,
    seg('evolucao', [['progresso', 'Evolução'], ['fotos', 'Fotos'], ['meta', 'Minha meta']], sub),
    sub === 'meta' ? vMeta() : sub === 'fotos' ? vFotos() : vProgresso(),
  ].join('');
}
function weightChart(range) {
  const all = MEMO().trend;
  if (!all.length) return `<p class="small muted">Registre seu peso para ver o gráfico.</p>`;
  const k = today();
  const from = range === 'all' ? all[0].date : L.addDays(k, -range);
  let pts = all.filter((p) => p.date >= from);
  if (!pts.length) pts = [all[all.length - 1]];
  const x0 = pts[0].date;
  const x1 = pts[pts.length - 1].date > k ? pts[pts.length - 1].date : k;
  const span = Math.max(1, L.diffDays(x0, x1));
  let lo = Math.min(...pts.map((p) => Math.min(p.kg, p.trend))), hi = Math.max(...pts.map((p) => Math.max(p.kg, p.trend)));
  const pg = phaseGoal();
  const showGoal = pg != null && pg >= lo - 6;
  if (showGoal) lo = Math.min(lo, pg);
  if (hi - lo < 2) { const c = (hi + lo) / 2; lo = c - 1; hi = c + 1; }
  lo -= 0.6; hi += 0.6;
  const rg = hi - lo, step = rg <= 5 ? 1 : rg <= 12 ? 2 : rg <= 30 ? 5 : 10;
  const ticks = []; for (let t = Math.ceil(lo / step) * step; t <= hi; t += step) ticks.push(t);
  const W = 340, H = 196, l = 34, r = 50, t = 10, b = 24;
  const X = (dk) => l + (L.diffDays(x0, dk) / span) * (W - l - r);
  const Y = (v) => t + (1 - (v - lo) / rg) * (H - t - b);
  const last = pts[pts.length - 1];
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.date).toFixed(1)},${Y(p.trend).toFixed(1)}`).join('');
  const area = pts.length > 1 ? `${line}L${X(last.date).toFixed(1)},${H - b}L${X(pts[0].date).toFixed(1)},${H - b}Z` : '';
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Gráfico da tendência de peso de ${fmt1(pts[0].trend)} para ${fmt1(last.trend)} kg">
    <defs><linearGradient id="gArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--go);stop-opacity:.22"/><stop offset="1" style="stop-color:var(--go);stop-opacity:0"/></linearGradient></defs>
    ${ticks.map((v) => `<line class="grid-l" x1="${l}" x2="${W - r}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}"/><text class="axis" x="${l - 6}" y="${(Y(v) + 4).toFixed(1)}" text-anchor="end">${v}</text>`).join('')}
    ${showGoal ? `<line class="goal" x1="${l}" x2="${W - r}" y1="${Y(pg).toFixed(1)}" y2="${Y(pg).toFixed(1)}"/><text class="goal-t" x="${W - r + 6}" y="${(Y(pg) + 4).toFixed(1)}">${fmtKg(pg)}</text>` : ''}
    ${area ? `<path d="${area}" style="fill:url(#gArea)"/>` : ''}
    ${pts.map((p) => `<circle class="raw" cx="${X(p.date).toFixed(1)}" cy="${Y(p.kg).toFixed(1)}" r="3"/>`).join('')}
    ${pts.length > 1 ? `<path class="trend" d="${line}"/>` : ''}
    <circle class="end" cx="${X(last.date).toFixed(1)}" cy="${Y(last.trend).toFixed(1)}" r="6"/>
    <text class="end-t" x="${(X(last.date) + 10).toFixed(1)}" y="${(Y(last.trend) - 8).toFixed(1)}">${fmt1(last.trend)}</text>
    <text class="axis" x="${l}" y="${H - 6}">${dShort(x0)}</text><text class="axis" x="${W - r}" y="${H - 6}" text-anchor="end">${dShort(x1)}</text></svg>`;
}
function metric(label, value, unit, cap) {
  const long = String(value).replace(/<[^>]+>/g, '').length > 6;
  return `<div class="metric"><span class="cap">${label}</span><span class="num${long ? ' sm' : ''}">${value}${unit ? `<span class="unit">${unit}</span>` : ''}</span>${cap ? `<span class="cap">${cap}</span>` : ''}</div>`;
}
function vProgresso() {
  const mm = MEMO(), p = prof();
  const cur = curWeight(), start = p.startWeight, diff = cur - start;
  const ws = waistSeries(), w0 = ws[0], w1 = ws[ws.length - 1];
  const trainings = mm.sessions.filter((s) => s.completed).length;
  const lw = lastWeigh(), rate = mm.rate, pg = phaseGoal();
  const weekly = L.weeklyAverages(mm.weights).slice(-8);
  const rows = weekly.map((w, i) => ({ w, d: i ? w.kg - weekly[i - 1].kg : null })).reverse();
  return `<section class="card"><div class="between"><span class="eyebrow">Peso · tendência</span><span class="badge ${diff < -0.05 ? 'ok' : ''}">${signed(diff)} kg</span></div>
      <div class="row" style="align-items:baseline"><span class="num" style="font-size:54px">${fmt1(cur)}</span><span class="muted">kg</span>${rate != null ? `<span class="small muted" style="margin-left:auto">${signed(rate)} kg/sem</span>` : ''}</div>
      ${seg('range', [['30', '30 dias'], ['90', '90 dias'], ['all', 'Tudo']], String(ui.chartRange))}
      ${weightChart(ui.chartRange)}
      <div class="row wrap tiny muted" style="gap:14px"><span class="row" style="gap:6px"><i class="lg-trend"></i>tendência</span><span class="row" style="gap:6px"><i class="lg-raw"></i>pesagens</span>${pg ? `<span class="row" style="gap:6px"><i class="lg-goal"></i>meta da fase</span>` : ''}</div>
      <p class="tiny faint">${lw ? `Última pesagem: ${fmt1(lw.kg)} kg em ${dShort(lw.date)}. ` : ''}A linha verde suaviza as oscilações do dia a dia (água, sal, intestino). É ela que importa.</p>
      <div class="btn-row"><button class="btn btn-soft" data-act="sheet" data-s="peso">${icon('scale')}Peso</button><button class="btn btn-ghost" data-act="sheet" data-s="medidas">${icon('tape')}Medidas</button></div></section>
    <div class="grid2">
      ${metric('Peso inicial', fmt1(start), 'kg')}${metric('Peso atual', fmt1(cur), 'kg', 'tendência')}
      ${metric('Diferença', signed(diff), 'kg')}${metric('Ritmo', rate != null ? signed(rate) : '—', 'kg/sem', rate == null ? 'precisa de 2+ semanas' : '')}
      ${metric('Cintura inicial', w0 ? fmt1(w0.waist) : '—', 'cm')}${metric('Cintura atual', w1 ? fmt1(w1.waist) : '—', 'cm')}
      ${metric('Centímetros perdidos', w0 && w1 ? fmt1(Math.max(0, w0.waist - w1.waist)) : '—', 'cm')}${metric('IMC', fmt1(L.bmi(cur, p.height)), '', 'indicador auxiliar')}
      ${metric('Treinos realizados', fmt0(trainings))}${metric('🔥 Sequência atual', fmt0(streakNow()), 'dias')}
      ${metric('Maior sequência', fmt0(streakBest()), 'dias')}${metric('Dias ativos', fmt0(activeDays()))}
    </div>
    ${summaryCard()}
    ${rows.length ? `<section class="card"><span class="eyebrow">Média semanal</span><div class="tbl-wrap"><table class="tbl"><thead><tr><th>Semana de</th><th class="r">Média</th><th class="r">Variação</th></tr></thead><tbody>
      ${rows.map(({ w, d }) => `<tr><td>${dShort(w.week)} <span class="faint tiny">· ${w.n} pesage${w.n === 1 ? 'm' : 'ns'}</span></td><td class="r">${fmt1(w.kg)} kg</td><td class="r ${d != null && d < 0 ? 'go-text' : ''}">${d == null ? '—' : signed(d)}</td></tr>`).join('')}</tbody></table></div></section>` : ''}
    ${measuresCard()}
    ${achievementsCard()}
    ${photosLinkCard()}`;
}
/** medidas corporais: cintura, quadril, braço e peito */
function measuresCard() {
  const all = MEMO().measures;
  if (!all.length) return `<section class="card card-flat"><div class="between"><span class="small muted">Medidas: cintura, quadril, braço e peito.</span><button class="btn btn-ghost btn-sm" data-act="sheet" data-s="medidas">${icon('tape', 'ic-sm')}Medir</button></div></section>`;
  const first = all[0], last = all[all.length - 1];
  const diff = (f) => (fin(first[f]) && fin(last[f]) && all.length > 1 ? ` <span class="tiny ${last[f] < first[f] ? 'go-text' : 'faint'}">${signed(last[f] - first[f])}</span>` : '');
  const cell = (f, l) => `<div class="metric"><span class="cap">${l}</span><span class="num sm">${fin(last[f]) ? fmt1(last[f]) : '—'}<span class="unit">cm</span></span><span class="cap">${fin(first[f]) && all.length > 1 ? 'início ' + fmt1(first[f]) : '&nbsp;'}${diff(f)}</span></div>`;
  return `<section class="card"><div class="between"><span class="eyebrow">Medidas</span><span class="tiny faint">última: ${dShort(last.date)}</span></div>
    <div class="grid2">${cell('waist', 'Cintura')}${cell('hip', 'Quadril')}${cell('arm', 'Braço')}${cell('chest', 'Peito')}</div>
    <div>${all.slice(-5).reverse().map((m) => `<div class="kv"><span class="k">${dShort(m.date)}</span><span class="v small">${[['waist', 'cintura'], ['hip', 'quadril'], ['arm', 'braço'], ['chest', 'peito']].filter(([f]) => fin(m[f])).map(([f, l]) => `${l} ${fmt1(m[f])}`).join(' · ')}</span></div>`).join('')}</div>
    <button class="btn btn-ghost btn-block btn-sm" data-act="sheet" data-s="medidas">${icon('tape', 'ic-sm')}Registrar medidas</button>
    <p class="tiny faint">Meça a cada 2 semanas, no mesmo horário. Cintura na altura do umbigo; braço relaxado, no meio; peito na linha dos mamilos.</p></section>`;
}
/** resumo da semana ou do mês: água, sono, energia, treinos, cardio e consistência */
function summaryCard() {
  const mes = ui.sumRange === 'mes', n = mes ? 30 : 7, k = today(), p = prof(), mm = MEMO();
  const days = Array.from({ length: n }, (_, i) => L.addDays(k, i - n + 1));
  const from = days[0];
  const dd = days.map((d) => mm.days[d] || {});
  const water = dd.map((d) => (d.water > 0 ? d.water : null));
  const sleep = dd.map((d) => (d.sleep && fin(d.sleep.hours) ? d.sleep.hours : null));
  const energy = dd.map((d) => { const s = d.sleep || {}; return fin(s.day) ? s.day : fin(s.energy) ? s.energy : null; });
  const start = startDate();
  const score = days.map((d) => (d < start ? null : Math.round(dayInfo(d).score * 100)));
  const trains = mm.sessions.filter((s) => s.completed && s.date >= from).length;
  const cardio = mm.cardio.filter((c) => c.date >= from).reduce((a, c) => a + (c.minutes || 0), 0) + mm.runs.filter((r) => r.date >= from).reduce((a, r) => a + (r.minutes || 0), 0);
  const cons = days.filter((d) => d >= start && d <= k && isConsistent(d)).length, possible = days.filter((d) => d >= start && d <= k).length;
  const avg = (arr) => { const v = arr.filter(fin); return v.length ? L.avg(v) : null; };
  const tr = mm.trend.filter((t) => t.date >= from), wDiff = tr.length > 1 ? tr[tr.length - 1].trend - tr[0].trend : null;
  const style = mes ? 'style="--n:30;--g:2px"' : '';
  const labels = mes ? `<div class="between tiny faint"><span>${dShort(from)}</span><span>${dShort(k)}</span></div>` : `<div class="minilabels">${days.map((d) => `<span>${WD1[L.weekday(d)]}</span>`).join('')}</div>`;
  const chart = (title, vals, good, max, cap) => `<div class="stack-sm"><div class="between"><span class="lbl">${title}</span><span class="tiny muted">${cap}</span></div><div class="minibars" ${style} aria-hidden="true">${vals.map((v) => `<div class="b ${v == null ? '' : v >= good ? 'on' : 'mid'}" style="height:${v == null ? 4 : Math.max(6, Math.round((Math.min(v, max) / max) * 100))}%"></div>`).join('')}</div>${labels}</div>`;
  return `<section class="card" id="resumo"><div class="between"><span class="eyebrow">Resumo ${mes ? 'do mês' : 'da semana'}</span>${icon('chart', 'ic-sm')}</div>
    ${seg('sumRange', [['semana', '7 dias'], ['mes', '30 dias']], mes ? 'mes' : 'semana')}
    <div class="grid3">${metric('Treinos', trains)}${metric('Cardio', cardio, 'min')}${metric('Consistência', possible ? cons + '/' + possible : '—', '', 'dias')}</div>
    ${wDiff != null ? `<p class="small">Peso no período: <b class="${wDiff < 0 ? 'go-text' : ''}">${signed(wDiff)} kg</b> (tendência)</p>` : ''}
    ${chart('Água', water, p.waterGoal, p.waterGoal * 1.15, avg(water) != null ? `média ${fmt0(avg(water))} ml` : 'sem registro')}
    ${chart('Sono', sleep, 7, 10, avg(sleep) != null ? `média ${fmt1(avg(sleep))} h` : 'sem registro')}
    ${chart('Energia', energy, 6, 10, avg(energy) != null ? `média ${fmt1(avg(energy))}/10` : 'sem registro')}
    ${chart('Dia concluído', score, Math.round(L.CONSISTENT * 100), 100, 'verde = dia consistente')}
    <p class="tiny faint">Verde: meta do dia batida. Amarelo: abaixo da meta. Cinza: sem registro.</p></section>`;
}
function achievementsCard() {
  const mm = MEMO(), p = prof();
  const best = streakBest(), tr = mm.sessions.filter((s) => s.completed).length, lost = Math.max(0, p.startWeight - curWeight());
  const ws = waistSeries(), wl = ws.length > 1 ? ws[0].waist - ws[ws.length - 1].waist : 0;
  const list = [
    ...[1, 7, 14, 30, 60, 90].map((n) => [`🔥 ${n} dia${n === 1 ? '' : 's'}`, best >= n]),
    ...[1, 10, 25, 50, 100].map((n) => [n === 1 ? 'Primeiro treino' : `${n} treinos`, tr >= n]),
    ...[5, 10, 15, 20, 25, 30, 35].filter((n) => n <= Math.max(5, p.startWeight - p.goalWeight + 0.5)).map((n) => [`−${n} kg`, lost >= n]),
    ...[5, 10, 15, 20].map((n) => [`−${n} cm de cintura`, wl >= n]),
  ];
  const on = list.filter((x) => x[1]).length;
  return `<section class="card"><div class="between"><span class="eyebrow">Conquistas</span><span class="badge ${on ? 'ok' : ''}">${on}/${list.length}</span></div>
    <div class="chips">${list.map(([l, o]) => `<span class="chip" aria-pressed="${o}" style="${o ? '' : 'opacity:.55'}">${o ? icon('check', 'ic-sm') : ''}${l}</span>`).join('')}</div></section>`;
}
function photosLinkCard() {
  const ph = frontPhotos(), last = ph[ph.length - 1];
  return `<button class="card" data-act="seg" data-group="evolucao" data-v="fotos"><div class="between"><span class="eyebrow">Fotos diárias</span><span class="badge">${ph.length} foto${ph.length === 1 ? '' : 's'} · 🔥 ${photoStreakNow()}</span></div>
    <p class="small muted">${last ? `Última: ${dShort(last.date)}. Veja a linha do tempo e compare o antes e o agora.` : 'Tire a primeira foto hoje: em alguns meses, a comparação fala mais que a balança.'}</p></button>`;
}

/* =============== MINHA META =============== */
function hitDate(kg) { const t = MEMO().trend.find((p) => p.trend <= kg + 0.001); return t ? t.date : null; }
function markDone(mk) {
  const core = coreRead(), mm = MEMO();
  const n = mm.sessions.filter((s) => s.completed).length;
  if (mk.auto === 'treinos12') return n >= 12;
  if (mk.auto === 'treinos100') return n >= 100;
  if (mk.auto && mk.auto.indexOf('double:') === 0) { const e = (core.ex || {})[mk.auto.slice(7)] || {}; return e.first > 0 && e.best >= 2 * e.first; }
  return !!(core.marks || {})[mk.id];
}
function vMeta() {
  const p = prof(), m = metaNumbers(), k = today(), mm = MEMO();
  const lmLo = Math.round(m.goal * 0.82), lmHi = Math.round(m.goal * 0.85);
  const waistGoal = Math.floor(p.height / 2);
  const [pLo, pHi] = proteinRange();
  const r = mm.rate, realPct = r != null && r < 0 ? -r / m.cur : null;
  const months = (w) => Math.max(1, Math.round(w / 4.345));
  const scen = [[0.01, 'Ritmo forte', '1% do peso por semana'], [0.007, 'Ritmo firme', '0,7% do peso por semana'], [0.005, 'Ritmo constante', '0,5% do peso por semana']];
  const allMs = milestonesList();
  const next = allMs.find((x) => m.cur > x + 0.05);
  const fullFast = months(L.weeksTo(m.start, m.goal, 0.01) || 0), fullSlow = months(L.weeksTo(m.start, m.goal, 0.005) || 0);
  const ws = waistSeries(), wNow = ws.length ? ws[ws.length - 1].waist : null;
  const total = m.start - m.goal;
  const t2 = Math.round(m.goal + total * 0.55), t3 = Math.round(m.goal + total * 0.28);
  const week = progWeek(k);
  const eta = (kg) => (m.cur <= kg ? null : monYear(L.dateAfterWeeks(k, L.weeksTo(m.cur, kg, 0.007))));
  const stages = [
    { st: C.STAGES[0], kg: `${fmtKg(m.start)} → ~${fmt0(L.weightAfter(m.start, 0.007, 4))} kg`, done: week > 4, when: `semanas 1 a 4 · até ${dShort(L.addDays(startDate(), 27))}` },
    { st: C.STAGES[1], kg: `até ~${t2} kg`, done: m.cur <= t2, when: eta(t2) ? `previsão ~${eta(t2)}` : 'concluída' },
    { st: C.STAGES[2], kg: `até ~${t3} kg`, done: m.cur <= t3, when: eta(t3) ? `previsão ~${eta(t3)}` : 'concluída' },
    { st: C.STAGES[3], kg: `até ${fmtKg(m.goal)} kg`, done: m.cur <= m.goal, when: eta(m.goal) ? `previsão ~${eta(m.goal)}` : 'concluída' },
    { st: C.STAGES[4], kg: `${fmtKg(m.goal)} → ${fmtKg(m.goal + 2)}–${fmtKg(m.goal + 4)} kg, cintura parada`, done: false, when: 'depois da meta · 3 a 6 meses' },
  ];
  const nowIdx = stages.findIndex((s) => !s.done);
  const gp = prof().showGoalPhotos !== false ? goalPair() : null;
  const phBox = (ph, label, kg, goal) => ph ? `<div class="ph ${goal ? 'goal' : ''}">${photoImg(ph, label)}<div class="tag"><span>${label}</span><b>${kg}</b></div></div>` : `<button class="ph ph-empty" data-act="photoAdd" data-pose="${goal ? 'meta' : 'inicio'}">${icon('camera')}<span>${goal ? 'Foto-meta' : 'Foto de início'}</span></button>`;
  const photos = gp
    ? `<div class="pair${gp.own ? ' own' : ''}">${phBox(gp.start, 'Início', fmtKg(p.startWeight) + ' kg', false)}${phBox(gp.goal, 'Meta', fmtKg(m.goal) + ' kg', true)}</div>
       <div class="btn-row">${gp.start && gp.goal ? `<button class="btn btn-soft btn-sm" data-act="sheet" data-s="compare">${icon('swap', 'ic-sm')}Comparar</button>` : `<button class="btn btn-soft btn-sm" data-act="photoAdd" data-pose="${gp.start ? 'meta' : 'inicio'}">${icon('camera', 'ic-sm')}Adicionar foto</button>`}<button class="btn btn-ghost btn-sm" data-act="goalPhotos" data-v="0">Ocultar fotos</button></div>
       <p class="tiny faint">${gp.own ? 'Suas fotos de referência.' : 'Imagem-meta ilustrativa: mostra o destino, não é garantia.'} O resultado real é construído semana a semana.${gp.own ? '' : ' <button class="link-btn" data-act="photoAdd" data-pose="inicio" style="display:inline;padding:0">Usar minhas próprias fotos</button>'}</p>`
    : prof().showGoalPhotos === false ? `<section class="card card-flat"><div class="between"><span class="small muted">Fotos da meta ocultas.</span><button class="btn btn-sm btn-ghost" data-act="goalPhotos" data-v="1">Mostrar</button></div></section>`
    : `<section class="card"><span class="eyebrow">Foto de início e foto-meta</span><p class="small muted">Coloque uma foto de hoje e, se quiser, uma imagem de referência do físico que você busca. Ficam guardadas só para você.</p>
       <div class="btn-row"><button class="btn btn-soft btn-sm" data-act="photoAdd" data-pose="inicio">${icon('camera', 'ic-sm')}Foto de início</button><button class="btn btn-ghost btn-sm" data-act="photoAdd" data-pose="meta">${icon('camera', 'ic-sm')}Foto-meta</button></div></section>`;
  const ri = runPlanInfo(k);
  const runGoal = `<button class="card" data-act="tabSub" data-to="treino" data-sub="corrida"><div class="between"><span class="eyebrow">Meta de corrida</span><span class="badge ok">${ri.daysToRace >= 0 ? `faltam ${Math.ceil(ri.daysToRace / 7)} semanas` : 'prova passou'}</span></div>
    <div class="h3">${esc(ri.rc.race.name)} · 10 km</div><p class="small muted">${dShort(ri.rc.race.date)}/${ri.rc.race.date.slice(0, 4)} · semana ${ri.w} de ${ri.N} · ${esc(ri.phase.name)}</p></button>`;
  return `<div class="stack-sm" style="padding:2px 2px 0"><span class="eyebrow go">Onde você vai chegar</span><p class="muted">${fmtKg(m.goal)} kg com músculo, energia e disciplina, e depois um pouco mais forte.</p></div>
    ${photos}
    ${runGoal}
    <section class="card"><div class="between"><span class="eyebrow">Caminho percorrido</span><span class="badge ok">${m.pct}%</span></div>
      <div class="row" style="align-items:baseline"><span class="num" style="font-size:54px">${fmt1(m.lost)}</span><span class="muted">de ${fmt1(m.total)} kg</span></div>
      <div class="bar"><i style="width:${m.pct}%"></i></div>
      <div class="plates">${allMs.map((x) => { const hd = hitDate(x); const est = hd ? dShort(hd) : x === next ? 'próxima' : eta(x) || ''; return `<div class="plate ${hd ? 'hit' : ''} ${x === next ? 'next' : ''}"><b>${fmtKg(x)}</b><small>${est}</small></div>`; }).join('')}</div>
      <p class="tiny faint">Cada anilha é uma meta intermediária de 5 kg. Tendência atual: ${fmt1(m.cur)} kg.</p></section>
    <section class="card"><span class="eyebrow">Quando você chega aos ${fmtKg(m.goal)} kg</span><div>
      ${realPct != null && m.cur > m.goal ? `<div class="kv"><span class="k"><b class="go-text">Seu ritmo real</b><br><span class="tiny faint">${fmt1(-r)} kg/sem · ${(realPct * 100).toFixed(1).replace('.', ',')}% do peso</span></span><span class="v">${monYear(L.dateAfterWeeks(k, L.weeksTo(m.cur, m.goal, realPct)))}<br><span class="tiny faint">~${months(L.weeksTo(m.cur, m.goal, realPct))} meses</span></span></div>` : ''}
      ${scen.map(([pc, name, desc]) => { const w = L.weeksTo(m.cur, m.goal, pc); return `<div class="kv"><span class="k"><b>${name}</b><br><span class="tiny faint">${desc}</span></span><span class="v">${m.cur <= m.goal ? 'alcançada' : `${monYear(L.dateAfterWeeks(k, w))}<br><span class="tiny faint">~${months(w)} meses</span>`}</span></div>`; }).join('')}</div>
      ${realPct != null && realPct > 0.012 && week > 3 ? `<div class="note warn">${icon('info')}<span>Seu ritmo está acima de 1% do peso por semana. Garanta proteína e treino de força para não perder músculo, e converse com um nutricionista.</span></div>` : ''}
      <p class="tiny faint">Calculado a partir da sua tendência atual (${fmt1(m.cur)} kg). É projeção, não promessa: depende de consistência, sono, alimentação e fatores individuais. Ritmo saudável: 0,5% a 1% do peso por semana.</p></section>
    <section class="card"><span class="eyebrow">Os números da meta</span><div class="grid2">
      ${metric('Peso', fmtKg(m.goal), 'kg', `IMC ${fmt1(L.bmi(m.goal, p.height))}: com músculo, o IMC engana`)}
      ${metric('Cintura', '< ' + waistGoal, 'cm', `metade da sua altura${wNow ? ` · hoje ${fmt1(wNow)} cm` : ''}`)}
      ${metric('Massa magra', `${lmLo}–${lmHi}`, 'kg', 'o que o visual da foto pede (15–18% de gordura)')}
      ${metric('Proteína', `${pLo}–${pHi}`, 'g/dia', 'para proteger o músculo')}</div></section>
    <section class="card"><span class="eyebrow">O caminho</span><div class="road">${stages.map((s, i) => `<div class="stage ${s.done ? 'done' : ''} ${i === nowIdx ? 'now' : ''}"><div class="rail"><span class="node">${s.done ? icon('check', 'ic-sm') : i + 1}</span><span class="line"></span></div>
      <div class="body"><div class="between"><span class="h3">${s.st.name}</span>${i === nowIdx ? '<span class="badge ok">agora</span>' : ''}</div><span class="small"><b>${s.kg}</b> · <span class="muted">${s.when}</span></span><span class="small muted">${s.st.what}</span><span class="small">${s.st.feel}</span></div></div>`).join('')}</div></section>
    <section class="card"><span class="eyebrow">A versão um pouco mais forte</span>
      <p>Perto de ${fmtKg(m.goal)}–${fmtKg(m.goal + 2)} kg a estratégia muda: comer na manutenção, proteína alta e treino de força mais pesado por 3 a 6 meses. O peso pode subir 2 a 4 kg, de músculo, com a cintura parada.</p>
      <p class="small muted">O juiz é a fita métrica, não a balança: cintura parada e cargas subindo significam que você está ficando mais forte.</p></section>
    <section class="card"><span class="eyebrow">Marcos de força e condicionamento</span><div class="stack-sm">
      ${C.STRENGTH_MARKS.map((mk) => { const on = markDone(mk); return `<button class="check" data-act="mark" data-id="${mk.id}" aria-pressed="${on}" ${mk.auto ? 'data-auto="1"' : ''}><span class="box">${icon('check')}</span><span class="grow">${mk.label}</span>${mk.auto ? '<span class="tiny faint">automático</span>' : ''}</button>`; }).join('')}</div></section>
    <section class="card"><span class="eyebrow">O que faz isso acontecer</span><ul class="clean">
      <li>${icon('dumbbell', 'ic-sm')}<span>3 treinos de força por semana (4 a partir da Fase 2, se quiser)</span></li>
      <li>${icon('walk', 'ic-sm')}<span>Cardio de baixo impacto 3 a 5 vezes por semana, subindo 5 min por semana</span></li>
      <li>${icon('trend', 'ic-sm')}<span>Passos: comece em ${fmt0(p.stepsGoal)} e some 1.000 a cada 2 semanas, até 8 a 10 mil</span></li>
      <li>${icon('bowl', 'ic-sm')}<span>Proteína ${pLo}–${pHi} g por dia e metade do prato de vegetais</span></li>
      <li>${icon('moon', 'ic-sm')}<span>Sono de 7 horas ou mais</span></li>
      <li>${icon('drop', 'ic-sm')}<span>Água todo dia e álcool no mínimo</span></li></ul>
      <p class="small"><b>80% de consistência por 12 meses vence 100% por 3 semanas.</b></p></section>
    <section class="card"><span class="eyebrow">Leitura do especialista</span>
      <p>A meta da foto é realista para ${(p.height / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} m. Com ${fmtKg(m.goal)} kg, o abdômen desenhado costuma aparecer com cerca de 15–18% de gordura corporal (estimativa visual). Na prática, isso é terminar com ${lmLo}–${lmHi} kg de massa magra: o treino de força e a proteína existem para você não perder músculo no caminho.</p>
      <p>Perder ${fmt0(total)} kg com saúde leva, em geral, de ${fullFast} a ${fullSlow} meses no ritmo recomendado. Ir mais rápido aumenta a chance de perder músculo e de o peso voltar.</p>
      <p>Seus joelhos agradecem: estudos com adultos acima do peso mostram que cada 1 kg perdido tira cerca de 4 kg de carga do joelho a cada passo. Com ${fmt0(total)} kg a menos, são uns ${fmt0(total * 4)} kg a menos em cada passada.</p>
      <p>Faça uma avaliação com médico e nutricionista no início (exames e bioimpedância) e repita a cada 8 a 12 semanas. É ela que confirma, ou ajusta, a meta final.</p></section>
    <button class="btn btn-ghost btn-block" data-act="sheet" data-s="meta">${icon('edit')}Ajustar meta</button>
    <p class="tiny faint">Conteúdo educativo. Não substitui avaliação de médico, nutricionista ou profissional de educação física.</p>`;
}

/* =============== MAIS =============== */
function vMais() {
  const p = prof();
  const rows = [
    ['perfil', 'user', 'Meus dados e configurações', 'Peso, altura, horários, metas, equipamentos'],
    ['agenda', 'clock', 'Agenda e semana', 'Organizar o dia: treino, refeições, blocos fixos'],
    ['sono', 'moon', 'Recuperação', 'Sono e energia'],
    ['hormonal', 'pulse', 'Saúde hormonal', 'Hábitos que sustentam, sem atalhos'],
    ['lembretes', 'bell', 'Lembretes e alarmes', 'Acordar, água, treino, refeições, dormir'],
    ['seguranca', 'shield', 'Segurança', 'Quando parar e quando procurar ajuda'],
    ['instalar', 'download', PWA ? 'App e backup' : 'Instalar o app e backup', PWA ? 'Instalação, backup e restauração' : 'Celular, tablet e computador'],
    ['privacidade', 'lock', 'Privacidade e termos', 'Onde ficam seus dados, exportar e apagar'],
  ];
  return [
    topBar(),
    `<div class="stack-sm" style="padding:4px 2px"><h1>${p.name ? esc(firstName(p.name)) : 'Perfil'}</h1><p class="muted">${[p.age ? p.age + ' anos' : '', p.height ? (p.height / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + ' m' : '', fin(curWeight()) ? fmt1(curWeight()) + ' kg' : ''].filter(Boolean).join(' · ')}</p></div>`,
    `<nav class="list">${rows.map(([to, ic, t, s]) => `<button class="list-row" data-act="go" data-to="${to}"><span class="ico">${icon(ic)}</span><span class="grow"><b>${t}</b><br><span class="small muted">${s}</span></span>${icon('chevR', 'chev')}</button>`).join('')}</nav>`,
    CLOUD && ui.user ? `<section class="card card-flat"><div class="between"><span class="small muted ellipsis" style="min-width:0">${icon('user', 'ic-sm')} ${esc(ui.user.email || '')}</span><button class="btn btn-ghost btn-sm" data-act="askLogout">${icon('logout', 'ic-sm')}Sair</button></div></section>` : '',
    `<section class="card card-flat"><span class="eyebrow">Sobre</span><p class="small muted">Saúde Jr. é um sistema pessoal de hábitos, treino e corrida. Conteúdo educativo: não faz diagnóstico e não prescreve remédios, hormônios ou dietas extremas. Para questões de saúde, procure médico, nutricionista ou profissional de educação física.</p></section>`,
  ].join('');
}
function minibars(values, goodMin, max) {
  return `<div class="minibars" aria-hidden="true">${values.map((v) => `<div class="b ${v == null ? '' : v >= goodMin ? 'on' : 'mid'}" style="height:${v == null ? 4 : Math.max(6, Math.round((Math.min(v, max) / max) * 100))}%"></div>`).join('')}</div>`;
}
function vSono() {
  const k = today(), mm = MEMO(), p = prof();
  const days = [0, 1, 2, 3, 4, 5, 6].map((i) => L.addDays(k, i - 6));
  const sl = days.map((d) => (mm.days[d] || {}).sleep || null);
  const hours = sl.map((s) => (s && fin(s.hours) ? s.hours : null));
  const en = sl.map((s) => (s && fin(s.energy) ? s.energy : null));
  const avgH = L.avg(hours.filter(fin)), avgE = L.avg(en.filter(fin));
  const last14 = Array.from({ length: 14 }, (_, i) => (mm.days[L.addDays(k, i - 13)] || {}).sleep || null);
  const flag = L.fatigueFlag(last14);
  const signs = p.sleepSigns || {}, anySign = C.SLEEP_SIGNS.some(([id]) => signs[id]);
  const s = (mm.days[k] || {}).sleep || {};
  return [
    subTop('Recuperação'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Sono e energia</h1><p class="muted">Recuperação é parte do treino.</p></div>`,
    flag || anySign ? `<section class="card card-warn"><div class="row">${icon('info')}<b>Vale uma avaliação profissional</b></div><p class="small">${flag ? 'Seu cansaço ou seu sono curto aparecem há vários dias. ' : ''}${anySign ? 'Os sinais que você marcou merecem atenção. ' : ''}Converse com um médico (clínico geral). O app acompanha seus hábitos, mas não faz diagnóstico.</p></section>` : '',
    `<section class="card"><div class="between"><span class="eyebrow">Hoje</span>${s.hours ? `<span class="badge ${s.hours >= 7 ? 'ok' : 'warn'}">${fmt1(s.hours)} h</span>` : ''}</div>
      ${s.hours ? `<div><div class="kv"><span class="k">Dormiu · acordou</span><span class="v">${esc(s.bed)} · ${esc(s.wake)}</span></div><div class="kv"><span class="k">Qualidade</span><span class="v">${s.quality ? ['Ruim', 'Regular', 'Boa', 'Ótima'][s.quality - 1] : '—'}</span></div><div class="kv"><span class="k">Energia ao acordar</span><span class="v">${s.energy ? s.energy + '/10' : '—'}</span></div>${s.notes ? `<div class="kv"><span class="k">Observações</span><span class="v small">${esc(s.notes)}</span></div>` : ''}</div>` : '<p class="small muted">Ainda sem registro de hoje.</p>'}
      <button class="btn btn-soft btn-block" data-act="sheet" data-s="sono">${icon('moon')}${s.hours ? 'Editar sono' : 'Registrar sono'}</button>
      <div class="field"><span class="lbl">Disposição durante o dia</span><div class="scale">${Array.from({ length: 10 }, (_, i) => `<button data-act="dayEnergy" data-v="${i + 1}" aria-pressed="${s.day === i + 1}">${i + 1}</button>`).join('')}</div><span class="hint">Registre no fim da tarde ou à noite.</span></div></section>`,
    `<section class="card"><div class="between"><span class="eyebrow">Últimos 7 dias</span><span class="tiny muted">média ${avgH != null ? fmt1(avgH) + ' h' : '—'} · energia ${avgE != null ? fmt1(avgE) : '—'}/10</span></div>
      ${minibars(hours, 7, 10)}<div class="minilabels">${days.map((d) => `<span>${WD1[L.weekday(d)]}</span>`).join('')}</div>
      <p class="tiny faint">Verde: 7 horas ou mais. Amarelo: menos que isso.</p></section>`,
    sleepHistory(mm, k),
    `<section class="card"><span class="eyebrow">Sinais para conversar com um médico</span><p class="small muted">Marque se acontece com você.</p>
      ${C.SLEEP_SIGNS.map(([id, l]) => `<div class="switch-row"><span class="small">${l}</span><button class="switch" role="switch" aria-checked="${!!signs[id]}" aria-label="${esc(l)}" data-act="sleepSign" data-f="${id}"></button></div>`).join('')}</section>`,
    `<section class="card"><span class="eyebrow">Dormir melhor</span><ul class="clean">${C.SLEEP_TIPS.map((t) => `<li>${icon('moon', 'ic-sm')}<span class="small">${t}</span></li>`).join('')}</ul></section>`,
  ].join('');
}
function sleepHistory(mm, k) {
  const rows = [];
  for (let i = 0; i < 14; i++) {
    const d = L.addDays(k, -i), s = (mm.days[d] || {}).sleep;
    if (s && (fin(s.hours) || fin(s.day) || fin(s.energy))) rows.push([d, s]);
  }
  if (!rows.length) return '';
  return `<section class="card"><span class="eyebrow">Histórico · 14 dias</span><div>${rows.map(([d, s]) => `<div class="kv"><span class="k">${WD[L.weekday(d)]} ${dShort(d)}</span><span class="v small">${fin(s.hours) ? fmt1(s.hours) + ' h' : '—'}${s.quality ? ' · ' + ['ruim', 'regular', 'boa', 'ótima'][s.quality - 1] : ''}${fin(s.energy) ? ` · acordou ${s.energy}/10` : ''}${fin(s.day) ? ` · dia ${s.day}/10` : ''}${s.notes ? `<br><span class="faint">${esc(s.notes)}</span>` : ''}</span></div>`).join('')}</div></section>`;
}
function vHormonal() {
  const k = today(), mm = MEMO();
  const days = [0, 1, 2, 3, 4, 5, 6].map((i) => L.addDays(k, i - 6));
  const dd = days.map((d) => mm.days[d] || {});
  const hrs = dd.map((d) => d.sleep && d.sleep.hours).filter(fin);
  const en = dd.map((d) => d.sleep && d.sleep.energy).filter(fin);
  const strength = mm.sessions.filter((s) => s.completed && s.date >= days[0]).length;
  const cardioMin = mm.cardio.filter((c) => c.date >= days[0]).reduce((a, c) => a + (c.minutes || 0), 0);
  const alc = dd.reduce((a, d) => a + (d.alcohol || 0), 0);
  const stress = dd.map((d) => d.stress).filter(fin);
  const rate = mm.rate;
  const avgS = L.avg(hrs), avgE = L.avg(en), avgSt = L.avg(stress);
  const today0 = mm.days[k] || {};
  const row = (label, val, state, hint) => `<div class="kv"><span class="k">${label}${hint ? `<br><span class="tiny faint">${hint}</span>` : ''}</span><span class="v">${val} ${state === 'ok' ? `<span class="badge ok">${icon('check', 'ic-sm')}</span>` : state === 'warn' ? '<span class="badge warn">atenção</span>' : ''}</span></div>`;
  return [
    subTop('Saúde hormonal'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Saúde hormonal</h1><p class="muted">Hábitos que sustentam a saúde, inclusive a hormonal. Sem “hacks”, sem promessas.</p></div>`,
    `<section class="card"><span class="eyebrow">Hoje</span>
      <div class="field"><span class="lbl">Álcool (doses)</span><div class="chips">${[0, 1, 2, 3, 4].map((v) => `<button class="chip sq" data-act="alcohol" data-v="${v}" aria-pressed="${(today0.alcohol || 0) === v && today0.alcohol != null}">${v === 4 ? '4+' : v}</button>`).join('')}</div></div>
      <div class="field"><span class="lbl">Estresse</span><div class="scale" style="--n:5">${[1, 2, 3, 4, 5].map((v) => `<button data-act="stress" data-v="${v}" aria-pressed="${today0.stress === v}">${v}</button>`).join('')}</div><span class="hint">1 = tranquilo · 5 = muito estressado</span></div></section>`,
    `<section class="card"><span class="eyebrow">Sua semana</span><div>
      ${row('Sono (média)', avgS != null ? fmt1(avgS) + ' h' : '—', avgS == null ? '' : avgS >= 7 ? 'ok' : 'warn', 'meta: 7 h ou mais')}
      ${row('Treinos de força', strength, strength >= 2 ? 'ok' : '', 'meta: 2 a 4 por semana')}
      ${row('Cardio', cardioMin + ' min', cardioMin >= 60 ? 'ok' : '', 'baixo impacto')}
      ${row('Tendência de peso', rate != null ? signed(rate) + ' kg/sem' : '—', rate != null && rate < 0 ? 'ok' : '', '')}
      ${row('Álcool', alc + (alc === 1 ? ' dose' : ' doses'), alc <= 3 ? 'ok' : alc > 7 ? 'warn' : '', 'quanto menos, melhor')}
      ${row('Estresse (média)', avgSt != null ? fmt1(avgSt) + '/5' : '—', avgSt == null ? '' : avgSt <= 2.5 ? 'ok' : avgSt >= 4 ? 'warn' : '', '')}
      ${row('Energia (média)', avgE != null ? fmt1(avgE) + '/10' : '—', avgE == null ? '' : avgE >= 6 ? 'ok' : avgE <= 4 ? 'warn' : '', 'ao acordar')}</div></section>`,
    `<section class="card"><span class="eyebrow">O que sustenta a saúde hormonal</span><ul class="clean">${C.HORMONE_HABITS.map(([t, s]) => `<li>${icon('check', 'ic-sm')}<span><b>${t}.</b> <span class="muted small">${s}</span></span></li>`).join('')}</ul></section>`,
    `<section class="card"><span class="eyebrow">Quando conversar com um médico</span><ul class="dots small">${C.HORMONE_DOCTOR.map((t) => `<li>${t}</li>`).join('')}</ul>
      <p class="small muted">Sintomas não bastam para saber nada sobre testosterona. Se quiser investigar, marque com um clínico geral, endocrinologista ou urologista: o médico pede os exames adequados (em geral coletados pela manhã) e interpreta com você.</p></section>`,
    `<section class="card card-flat"><span class="eyebrow">O que este app não faz</span><p class="small muted">Não recomenda testosterona, anabolizantes, “boosters”, hormônios ou medicamentos. Esses produtos, sem indicação e acompanhamento médico, trazem riscos sérios, como infertilidade e problemas no coração e no fígado.</p></section>`,
  ].join('');
}
function vLembretes() {
  const p = prof(), r = p.reminders, k = today();
  const perm = typeof Notification === 'undefined' ? 'indisponível' : Notification.permission;
  const sw = (key, label, sub) => `<div class="switch-row"><span><b>${label}</b>${sub ? `<br><span class="tiny faint">${sub}</span>` : ''}</span><button class="switch" role="switch" aria-checked="${!!r[key]}" aria-label="${esc(label)}" data-act="remToggle" data-f="${key}"></button></div>`;
  const list = reminderList(k);
  const mt = mealTimesAll();
  return [
    subTop('Lembretes'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Lembretes e avisos</h1><p class="muted">Com o app aberto, os avisos aparecem na tela com som e vibração.</p></div>`,
    `<section class="card"><span class="eyebrow">O que avisar</span>
      ${sw('wake', 'Acordar', `às ${esc(p.wakeTime)}`)}
      ${sw('photo', 'Foto do dia', 'logo depois de acordar')}
      ${sw('train', 'Treino e corrida', `às ${esc(p.trainTime)}, com a frase do dia`)}
      ${sw('meals', 'As 6 refeições', C.MEALS6.map((m) => `${m.short} ${mt[m.id]}`).join(' · '))}
      ${sw('supps', 'Suplementos', suppList().length ? `${suppList().length} cadastrado${suppList().length === 1 ? '' : 's'}` : 'nenhum cadastrado')}
      ${sw('water', 'Água', 'ao longo do dia')}
      ${r.water ? `<div class="field"><label for="r-every">Frequência da água</label><select id="r-every" data-change="remEvery">${[[60, 'A cada 1 hora'], [90, 'A cada 1 h 30'], [120, 'A cada 2 horas'], [180, 'A cada 3 horas']].map(([v, l]) => `<option value="${v}" ${Number(r.waterEvery) === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>` : ''}
      ${sw('weigh', 'Pesagem da semana', `${WD_LONG[r.weighDay] || 'segunda-feira'} às ${esc(r.weighTime || '07:00')}`)}
      ${r.weigh ? `<div class="grid2"><div class="field"><label for="r-wday">Dia da pesagem</label><select id="r-wday" data-change="remSet" data-f="weighDay" data-t="int">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<option value="${w}" ${Number(r.weighDay) === w ? 'selected' : ''}>${WD_LONG[w]}</option>`).join('')}</select></div><div class="field"><label for="r-wtime">Horário</label><input id="r-wtime" type="time" value="${esc(r.weighTime || '07:00')}" data-change="remSet" data-f="weighTime" data-t="time"></div></div>` : ''}
      ${sw('checklist', 'Checklist do dia', `revisar às ${esc(r.checklistTime || '21:00')}`)}
      ${r.checklist ? `<div class="field"><label for="r-ctime">Horário do checklist</label><input id="r-ctime" type="time" value="${esc(r.checklistTime || '21:00')}" data-change="remSet" data-f="checklistTime" data-t="time"></div>` : ''}
      ${sw('sleep', 'Desacelerar para dormir', `30 min antes das ${esc(p.bedTime)}`)}
      <div class="grid3 times"><div class="field"><label for="r-wake">Acordar</label><input id="r-wake" type="time" value="${esc(p.wakeTime)}" data-change="pf" data-f="wakeTime" data-t="time"></div><div class="field"><label for="r-train">Treino</label><input id="r-train" type="time" value="${esc(p.trainTime)}" data-change="pf" data-f="trainTime" data-t="time"></div><div class="field"><label for="r-bed">Dormir</label><input id="r-bed" type="time" value="${esc(p.bedTime)}" data-change="pf" data-f="bedTime" data-t="time"></div></div>
      <div class="btn-row"><button class="btn btn-ghost btn-sm" data-act="sheet" data-s="horarios">${icon('bowl', 'ic-sm')}Horários das refeições</button><button class="btn btn-ghost btn-sm" data-act="go" data-to="agenda">${icon('clock', 'ic-sm')}Agenda</button></div></section>`,
    `<section class="card"><span class="eyebrow">Avisos com o celular bloqueado</span>
      ${PWA
        ? `<p class="small muted">Baixe o calendário do Saúde Jr. e abra no celular: as 6 refeições, o treino, a foto, os suplementos e a hora de dormir viram lembretes do seu calendário, que tocam mesmo com o app fechado.</p>
           <button class="btn btn-go btn-block" data-act="exportIcs">${icon('download')}Baixar calendário de lembretes</button>
           <p class="tiny faint">iPhone: toque no arquivo e em “Adicionar tudo”. Android (Samsung e outros): abra o arquivo com o app de Calendário. No Google Agenda, importe pelo computador em calendar.google.com › Configurações › Importar.</p>`
        : `<p class="small muted">Aqui dentro do Claude, os avisos só aparecem com o app aberto. Para receber com o celular bloqueado, abra o app do Claude no celular e peça: “crie no meu calendário os lembretes do Saúde Jr.” com os horários abaixo. A versão instalável do app também gera esse calendário.</p>
           <pre id="alarmsText" class="small" style="white-space:pre-wrap;margin:0;padding:12px;background:var(--surface-2);border-radius:12px;font-family:var(--body)">${esc(alarmsText())}</pre>
           <button class="btn btn-soft btn-block btn-sm" data-act="copyAlarms">${icon('copy', 'ic-sm')}Copiar horários</button>`}</section>`,
    `<section class="card"><span class="eyebrow">Google Agenda · Android</span>
      <p class="small muted">O jeito mais confiável de receber os avisos no Android com o celular bloqueado: toque em cada lembrete abaixo e em <b>Salvar</b>. Eles se repetem sozinhos todos os dias (ou nos dias do treino).</p>
      <div>${fixedReminders().map((e) => `<div class="kv"><span class="grow" style="min-width:0"><b>${esc(e.time)} · ${esc(e.title)}</b>${e.days ? `<br><span class="tiny faint">${esc(daysText(e.days))}</span>` : ''}</span><a class="btn btn-ghost btn-sm" style="flex:none" href="${esc(gcalLink(e))}" target="_blank" rel="noopener">Adicionar</a></div>`).join('')}</div>
      <p class="tiny faint">No Google Agenda, deixe a notificação padrão em “no horário do evento” (Configurações › sua agenda › Notificações do evento). Mudou algum horário no app? Apague o evento antigo e adicione de novo.</p></section>`,
    `<section class="card"><span class="eyebrow">Próximos de hoje</span><div>${list.filter((x) => L.minutesOf(x.time) >= nowMin()).slice(0, 8).map((x) => `<div class="kv"><span class="k">${esc(x.title)}</span><span class="v">${x.time}</span></div>`).join('') || '<p class="small muted">Nenhum aviso restante hoje.</p>'}</div>
      <div class="btn-row"><button class="btn btn-ghost btn-sm" data-act="testReminder">${icon('bell', 'ic-sm')}Testar aviso</button><button class="btn btn-ghost btn-sm" data-act="notifPerm">Notificações: ${perm === 'granted' ? 'ativas' : perm === 'denied' ? 'bloqueadas' : perm === 'default' ? 'ativar' : 'n/d'}</button></div></section>`,
  ].join('');
}
function vPerfil() {
  const p = prof(), me = ui.me;
  const num = (id, f, label, val, step, unit) => `<div class="field"><label for="${id}">${label}${unit ? ` (${unit})` : ''}</label><input id="${id}" ${step && step < 1 ? 'type="text" inputmode="decimal" autocomplete="off"' : `type="number" inputmode="numeric" step="${step || 1}"`} value="${decv(val)}" data-change="pf" data-f="${f}" data-t="num"></div>`;
  const cloud = Store.mode === 'cloud';
  const opt = (list, cur) => list.map(([v, l, s]) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(l)}${s ? ' · ' + esc(s) : ''}</option>`).join('');
  const goals = C.GOALS.includes(p.goal) || !p.goal ? C.GOALS : [p.goal, ...C.GOALS];
  const account = CLOUD
    ? `<section class="card" id="conta"><div class="row"><span class="ico avatar">${icon('user')}</span>
        <div class="grow" style="min-width:0"><b id="meName">${esc(p.name || (ui.user && ui.user.name) || 'Sua conta')}</b><br><span class="small muted ellipsis" id="meEmail">${esc((ui.user && ui.user.email) || '')}</span></div><span class="dot ${syncInfo()[0]}"></span></div>
        <p class="tiny faint">${ui.offlineUser ? 'Sem internet agora: seus registros ficam guardados aqui e vão para a conta quando a conexão voltar.' : 'Dados privados na sua conta, sincronizados entre seus aparelhos. Ninguém mais tem acesso.'}</p>
        <div class="btn-row acct"><button class="btn btn-ghost btn-sm" data-act="changePass">${icon('key', 'ic-sm')}Trocar senha</button><button class="btn btn-ghost btn-sm" data-act="askLogout">${icon('logout', 'ic-sm')}Sair da conta</button></div></section>`
    : `<section class="card"><div class="row">${me && me.avatarUrl ? `<img src="${esc(me.avatarUrl)}" alt="" width="44" height="44" style="border-radius:50%">` : `<span class="ico avatar">${icon('user')}</span>`}
      <div class="grow"><b id="meName">${esc(me && me.name ? me.name : 'Sua conta')}</b><br><span class="small muted">${cloud ? 'Dados privados, salvos na sua conta e sincronizados' : 'Dados salvos só neste aparelho'}</span></div><span class="dot ${syncInfo()[0]}"></span></div>
      ${!cloud ? `<p class="tiny faint">${PWA ? 'Modo de desenvolvimento: sem conta, os dados ficam só neste aparelho.' : 'Para sincronizar entre aparelhos, abra o app pelo link da sua conta Claude.'}</p>` : ''}</section>`;
  return [
    subTop('Perfil'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Perfil e configurações</h1></div>`,
    account,
    `<section class="card"><span class="eyebrow">Você</span>
      <div class="field"><label for="pf-name">Nome</label><input id="pf-name" type="text" value="${esc(p.name)}" data-change="pf" data-f="name" data-t="text"></div>
      ${CLOUD && ui.user ? `<div class="field"><label for="pf-email">E-mail</label><input id="pf-email" type="email" value="${esc(ui.user.email)}" readonly aria-readonly="true"><span class="hint">É o e-mail de entrada na conta.</span></div>` : ''}
      <div class="grid2">${num('pf-age', 'age', 'Idade', p.age)}${num('pf-height', 'height', 'Altura', p.height, 1, 'cm')}</div>
      <div class="grid2">${num('pf-start', 'startWeight', 'Peso inicial', p.startWeight, 0.1, 'kg')}${num('pf-goalw', 'goalWeight', 'Meta de peso', p.goalWeight, 0.5, 'kg')}</div>
      <div class="field"><label for="pf-goal">Objetivo</label><select id="pf-goal" data-change="pf" data-f="goal" data-t="text">${goals.map((g) => `<option ${g === p.goal ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select></div>
      <div class="field"><label for="pf-activity">Nível de atividade</label><select id="pf-activity" data-change="pf" data-f="activityLevel" data-t="text"><option value="">Escolha</option>${opt(C.ACTIVITY_LEVELS, p.activityLevel)}</select></div>
      <div class="field"><label for="pf-pref">Treino preferido</label><select id="pf-pref" data-change="pf" data-f="trainPref" data-t="text"><option value="">Escolha</option>${opt(C.TRAIN_PREFS, p.trainPref)}</select></div>
      <div class="kv"><span class="k">Peso atual (tendência)</span><span class="v">${fmt1(curWeight())} kg</span></div>
      <button class="btn btn-soft btn-block btn-sm" data-act="sheet" data-s="peso">${icon('scale', 'ic-sm')}Registrar peso de hoje</button></section>`,
    `<section class="card"><span class="eyebrow">Rotina</span>
      <div class="field"><span class="lbl">Semana de treinos</span><p class="small">${[1, 2, 3, 4, 5, 6, 0].map((w) => `${WD[w]} ${({ gym: 'academia', run: 'corrida', rest: 'descanso' })[weekPlan()[w]]}`).join(' · ')}</p><button class="btn btn-ghost btn-sm" data-act="go" data-to="agenda">${icon('edit', 'ic-sm')}Mudar a semana</button></div>
      <div class="grid2"><div class="field"><label for="pf-train">Treino</label><input id="pf-train" type="time" value="${esc(p.trainTime)}" data-change="pf" data-f="trainTime" data-t="time"></div><div class="field"><label for="pf-wake">Acordar</label><input id="pf-wake" type="time" value="${esc(p.wakeTime)}" data-change="pf" data-f="wakeTime" data-t="time"></div></div>
      <div class="grid2"><div class="field"><label for="pf-bed">Dormir</label><input id="pf-bed" type="time" value="${esc(p.bedTime)}" data-change="pf" data-f="bedTime" data-t="time"></div>${num('pf-steps', 'stepsGoal', 'Meta de passos', p.stepsGoal, 500)}</div>
      ${num('pf-water', 'waterGoal', 'Meta de água', p.waterGoal, 250, 'ml')}
      <p class="hint">A meta de água é ajustável: considere sede, calor, treino e orientação médica.</p>
      <button class="link-btn" data-act="go" data-to="lembretes">Configurar lembretes e notificações</button></section>`,
    `<section class="card"><span class="eyebrow">Preferências alimentares</span>
      <div class="switch-row"><span>Sem lactose</span><button class="switch" role="switch" aria-checked="${!!p.prefs.lactose}" aria-label="Sem lactose" data-act="pref" data-f="lactose"></button></div>
      <div class="switch-row"><span>Não como carne vermelha</span><button class="switch" role="switch" aria-checked="${!!p.prefs.noRedMeat}" aria-label="Não como carne vermelha" data-act="pref" data-f="noRedMeat"></button></div>
      <div class="field"><label for="pf-notes">Observações</label><textarea id="pf-notes" data-change="prefNotes" placeholder="Ex.: não gosto de peixe, almoço no restaurante da empresa">${esc(p.prefs.notes)}</textarea></div></section>`,
    `<section class="card"><span class="eyebrow">Equipamentos disponíveis</span><p class="small muted">O treino troca sozinho o exercício quando falta um aparelho.</p>
      <div class="chips">${C.EQUIP.map((e) => `<button class="chip" data-act="equip" data-id="${e.id}" aria-pressed="${(p.equipment || []).includes(e.id)}">${esc(e.label)}</button>`).join('')}</div></section>`,
    `<section class="card"><span class="eyebrow">Programa</span><div class="kv"><span class="k">Início</span><span class="v">${dShort(startDate())} · semana ${progWeek()}</span></div>
      <button class="btn btn-ghost btn-block btn-sm" data-act="askRestart">Recomeçar a Fase 1 hoje</button>
      <div class="switch-row"><span>Mostrar fotos da meta</span><button class="switch" role="switch" aria-checked="${p.showGoalPhotos !== false}" aria-label="Mostrar fotos da meta" data-act="goalPhotos" data-v="${p.showGoalPhotos !== false ? 0 : 1}"></button></div>
      <button class="link-btn" data-act="go" data-to="seguranca">Revisar questionário de segurança</button></section>`,
    `<section class="card"><span class="eyebrow">Meus dados</span>
      <div class="btn-row"><button class="btn btn-ghost btn-sm" data-act="exportJson">${icon('download', 'ic-sm')}Backup</button><button class="btn btn-ghost btn-sm" data-act="importAsk">${icon('undo', 'ic-sm')}Restaurar</button></div>
      <button class="btn btn-ghost btn-block btn-sm" data-act="exportCsv">${icon('download', 'ic-sm')}Pesos (CSV)</button>
      <button class="btn btn-danger btn-block btn-sm" data-act="askReset">${icon('trash', 'ic-sm')}Apagar todos os meus dados</button></section>`,
  ].join('');
}
function vSeguranca() {
  const p = prof(), s = p.safety || { answers: {} }, a = s.answers || {};
  return [
    subTop('Segurança'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Segurança</h1><p class="muted">Primeiro segurança, depois consistência, depois progressão.</p></div>`,
    `<section class="card card-alert tight"><div class="row">${icon('heart')}<b>Pare e procure ajuda</b></div><p class="small">${C.STOP_SIGNS}</p></section>`,
    `<section class="card"><span class="eyebrow">Questionário antes de treinar</span><p class="small muted">Marque as que forem sim.</p>
      ${C.SAFETY_QUESTIONS.map(([id, q]) => `<div class="switch-row"><span class="small">${q}</span><button class="switch" role="switch" aria-checked="${!!a[id]}" aria-label="${esc(q)}" data-act="safetyQ" data-q="${id}"></button></div>`).join('<hr class="divider">')}
      ${s.flag ? `<div class="note warn">${icon('info')}<span>Com pelo menos um “sim”, faça uma avaliação médica antes de intensificar os treinos. Até lá, caminhadas leves e cargas baixas.</span></div>
        <div class="switch-row"><span><b>Já fui avaliado e liberado</b></span><button class="switch" role="switch" aria-checked="${!!s.cleared}" aria-label="Já fui avaliado e liberado" data-act="safetyCleared"></button></div>`
    : `<div class="note go">${icon('check')}<span>Nenhum “sim”. Mesmo assim, um check-up médico é recomendado para quem está voltando a treinar.</span></div>`}</section>`,
    `<section class="card"><span class="eyebrow">Quando procurar um profissional</span><ul class="dots small">
      <li>Dor articular que piora de um treino para o outro: profissional de educação física ou fisioterapeuta.</li>
      <li>Sangue nas fezes, dor abdominal forte ou mudança do intestino por semanas: médico.</li>
      <li>Cansaço persistente, ronco alto ou sonolência forte durante o dia: médico.</li>
      <li>Dúvidas sobre hormônios: médico, com exames adequados.</li>
      <li>Quantidades de comida, suplementos ou restrições: nutricionista.</li></ul></section>`,
    `<p class="tiny faint">O Saúde Jr. é educativo e de acompanhamento. Não faz diagnóstico, não prescreve medicamentos, hormônios, anabolizantes, dietas extremas ou jejuns prolongados.</p>`,
  ].join('');
}

function vInstalar() {
  const standalone = PWA && ((window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone);
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent || '');
  return [
    subTop(PWA ? 'App' : 'Instalar'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>${PWA ? 'App e backup' : 'Instalar o Saúde Jr.'}</h1></div>`,
    PWA
      ? `<section class="card ${standalone ? '' : 'card-now'}"><span class="eyebrow ${standalone ? '' : 'go'}">${standalone ? 'Instalado' : 'Instalar no aparelho'}</span>
          ${standalone ? '<p>O Saúde Jr. está instalado neste aparelho e funciona mesmo sem internet.</p>'
            : ui.installEvt ? `<p class="small muted">Um toque e o app vai para a sua tela inicial e para a lista de aplicativos.</p><button class="btn btn-go btn-block" data-act="installApp">${icon('download')}Instalar Saúde Jr.</button>`
            : ios ? '<ol class="dots small"><li>Abra este endereço no <b>Safari</b>.</li><li>Toque no botão <b>Compartilhar</b> (quadrado com seta).</li><li>Escolha <b>Adicionar à Tela de Início</b> e confirme.</li></ol>'
            : '<ol class="dots small"><li>No <b>Chrome</b> do celular, toque no menu <b>⋮</b>.</li><li>Escolha <b>Instalar app</b> (ou <b>Adicionar à tela inicial</b>).</li><li>No computador (Chrome ou Edge), use o ícone de instalar na barra de endereço.</li></ol>'}</section>`
      : `<section class="card card-now"><span class="eyebrow go">Ícone na tela do celular</span><p class="small muted">Este link funciona no celular, no tablet e no computador, com os dados sincronizados na sua conta Claude. Para abrir pelo ícone, como um app:</p>
          <ol class="dots small"><li><b>iPhone:</b> abra o link no Safari › botão Compartilhar › <b>Adicionar à Tela de Início</b>.</li><li><b>Android:</b> abra o link no Chrome › menu ⋮ › <b>Adicionar à tela inicial</b>.</li><li><b>Computador:</b> salve o link nos favoritos.</li></ol></section>
        <section class="card"><span class="eyebrow">Versão app completa</span><p class="small muted">Existe também a versão instalável do Saúde Jr.: funciona sem internet, mede a distância das corridas por GPS e cria um calendário de lembretes que toca com o celular bloqueado. Ela precisa ser publicada em um endereço seu (por exemplo, GitHub Pages, gratuito). Para levar seus dados: aqui, toque em <b>Fazer backup</b>; lá, em <b>Restaurar</b>.</p></section>`,
    `<section class="card"><span class="eyebrow">Backup</span><p class="small muted">${CLOUD ? 'Seus dados ficam na sua conta: é só entrar em outro aparelho. O backup em arquivo é uma cópia extra, e serve também para trazer dados da versão antiga.' : PWA ? 'Neste modo, os dados ficam neste aparelho. Faça backup para trocar de celular ou usar em outro aparelho.' : 'Seus dados já ficam na sua conta. O backup serve para levar tudo para o app instalado.'} As fotos não entram no arquivo de backup.</p>
      <div class="btn-row"><button class="btn btn-soft btn-sm" data-act="exportJson">${icon('download', 'ic-sm')}Fazer backup</button><button class="btn btn-ghost btn-sm" data-act="importAsk">${icon('undo', 'ic-sm')}Restaurar</button></div></section>`,
    `<p class="tiny faint">${CLOUD ? 'Saúde Jr. · seus dados ficam na sua conta, protegidos. Sem anúncios e sem rastreadores.' : 'Saúde Jr. · seus dados são seus: nada é enviado para servidores de terceiros.'}</p>`,
  ].join('');
}

/* =============== PRIVACIDADE E TERMOS =============== */
function vPrivacidade() {
  const where = CLOUD
    ? 'Seus registros ficam na sua conta do Saúde Jr., num banco de dados protegido (Supabase, servidores em São Paulo). Regras de segurança do próprio banco garantem que cada conta só lê e grava os próprios dados. Uma cópia fica neste aparelho para o app abrir rápido e funcionar sem internet; ao sair da conta, essa cópia é apagada.'
    : PWA
      ? 'Neste modo, tudo fica só neste aparelho, no armazenamento do navegador. Nada é enviado para servidores. Sem internet, o app continua funcionando.'
      : 'Nesta versão dentro do Claude, os dados ficam na área privada da sua conta Claude, visível só para você, e sincronizam entre seus aparelhos.';
  return [
    subTop('Privacidade', CLOUD && !ui.user ? 'auth' : undefined),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Privacidade e termos</h1><p class="muted">Versão de ${dShort('2026-09-29')}/2026.</p></div>`,
    `<section class="card"><span class="eyebrow">Seus dados</span>
      <p class="small">O Saúde Jr. guarda o que você registra: perfil, peso, medidas, treinos e cargas, cardio e corridas, refeições, água, sono, energia, intestino, suplementos, hábitos e fotos (opcionais).</p>
      <p class="small">${where}</p>
      <p class="small">As fotos são dados pessoais sensíveis: ${CLOUD ? 'ficam numa pasta privada da sua conta, que só você acessa, e ' : ''}nunca são publicadas nem compartilhadas pelo app.</p>
      <p class="small">${CLOUD ? 'Sua senha é guardada pelo sistema de contas do Supabase de forma protegida (nunca em texto); nem o app nem o código têm acesso a ela. O código do app é público e não contém nenhum dado pessoal, senha ou chave secreta.' : 'O app não pede senha e não cria conta.'}</p>
      <p class="small">Sem anúncios, sem rastreadores, sem venda de dados.</p></section>`,
    CLOUD && !ui.user ? '' : `<section class="card"><span class="eyebrow">Seus controles</span>
      <div class="btn-row"><button class="btn btn-soft btn-sm" data-act="exportJson">${icon('download', 'ic-sm')}Exportar dados</button><button class="btn btn-ghost btn-sm" data-act="importAsk">${icon('undo', 'ic-sm')}Restaurar</button></div>
      <button class="btn btn-danger btn-block btn-sm" data-act="askReset">${icon('trash', 'ic-sm')}Apagar todos os meus dados</button>
      <p class="tiny faint">O backup é um arquivo .json com seus registros (sem as fotos). Guarde em lugar seguro.</p></section>`,
    `<section class="card"><span class="eyebrow">Termos de uso</span><ul class="dots small">
      <li>O Saúde Jr. é uma ferramenta pessoal de acompanhamento de hábitos, com conteúdo educativo.</li>
      <li>Não é serviço médico: não faz diagnóstico, não prescreve medicamentos, hormônios, anabolizantes, dietas extremas ou jejuns prolongados.</li>
      <li>Projeções de peso e de prova são estimativas, não promessas. O resultado depende de fatores individuais.</li>
      <li>Antes de aumentar a intensidade dos treinos, procure um médico, nutricionista ou profissional de educação física.</li>
      <li>${esc(C.STOP_SIGNS)}</li></ul></section>`,
  ].join('');
}
