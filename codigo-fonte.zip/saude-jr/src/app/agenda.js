/* ===== Saúde Jr. — agenda do dia, semana e plano mensal da academia ===== */
const KIND_ICON = { wake: 'clock', photo: 'camera', pre: 'bowl', gym: 'dumbbell', run: 'walk', meal: 'bowl', supp: 'shield', custom: 'clock', wind: 'moon', sleep: 'moon' };
function agendaAct(it) {
  switch (it.kind) {
    case 'meal': return { act: 'sheet', data: { s: 'refeicao', m: it.id.slice(5) } };
    case 'supp': return { act: 'tabSub', data: { to: 'comida', sub: 'suplementos' } };
    case 'photo': return { act: 'photoAdd', data: { pose: 'frente' } };
    case 'gym': return { act: 'tabSub', data: { to: 'treino', sub: 'academia' } };
    case 'run': return { act: 'tabSub', data: { to: 'treino', sub: 'corrida' } };
    default: return { act: 'agendaCheck', data: { id: it.id, kind: it.kind } };
  }
}
function agendaRow(k, it, isNext) {
  const done = agendaDone(k, it), a = agendaAct(it);
  return `<div class="ag-row ${done ? 'done' : ''} ${isNext ? 'next' : ''}">
    <span class="ag-time">${esc(it.time)}</span>
    <button class="ag-main" data-act="${a.act}" ${attrs(a.data)}><span class="ag-ic">${icon(KIND_ICON[it.kind] || 'clock', 'ic-sm')}</span><span class="grow" style="min-width:0"><b>${esc(it.label)}</b>${it.sub ? `<span class="ag-sub">${esc(it.sub)}</span>` : ''}</span></button>
    <button class="ag-check" data-act="agendaCheck" data-id="${esc(it.id)}" data-kind="${it.kind}" aria-pressed="${done}" aria-label="Marcar ${esc(it.label)} como feito">${icon('check')}</button></div>`;
}
function agendaNextIdx(k, items) {
  const n = nowMin();
  const i = items.findIndex((it) => !agendaDone(k, it) && L.minutesOf(it.time) >= n - 15);
  return i < 0 ? items.length : i;
}
function agendaCard(k) {
  const items = agendaFor(k), nx = agendaNextIdx(k, items);
  const start = Math.max(0, Math.min(nx - 1, items.length - 5));
  const show = items.slice(start, start + 5);
  const done = items.filter((it) => agendaDone(k, it)).length;
  return `<section class="card"><div class="between"><span class="eyebrow">Agenda de hoje</span><span class="badge ${done === items.length ? 'ok' : ''}">${done}/${items.length}</span></div>
    <div class="agenda">${show.map((it) => agendaRow(k, it, items.indexOf(it) === nx)).join('')}</div>
    <button class="btn btn-ghost btn-block btn-sm" data-act="go" data-to="agenda">Ver o dia todo e organizar a semana</button></section>`;
}
const PLAN_LABEL = { gym: 'Academia', run: 'Corrida', rest: 'Descanso' };
function vAgenda() {
  const k = ui.agendaDay === 'amanha' ? L.addDays(today(), 1) : today();
  const items = agendaFor(k), nx = k === today() ? agendaNextIdx(k, items) : -1;
  const p = prof(), wp = weekPlan(), custom = p.custom || [];
  const nRun = Object.values(wp).filter((v) => v === 'run').length, nGym = Object.values(wp).filter((v) => v === 'gym').length;
  return [
    subTop('Agenda'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Minha agenda</h1><p class="muted">Blocos fixos primeiro, depois treino, refeições e sono. O resto se encaixa.</p></div>`,
    seg('agendaDay', [['hoje', 'Hoje'], ['amanha', 'Amanhã']], ui.agendaDay === 'amanha' ? 'amanha' : 'hoje'),
    `<section class="card"><div class="between"><span class="eyebrow">${dLong(k)}</span><span class="badge">${PLAN_LABEL[dayPlan(k)]}</span></div><div class="agenda">${items.map((it, i) => agendaRow(k, it, i === nx)).join('')}</div></section>`,
    `<section class="card"><span class="eyebrow">Minha semana</span><p class="small muted">Com a meta dos 10 km: 3 dias de corrida ou caminhada e 2–3 de academia, com pelo menos 1 dia de descanso.</p>
      <div class="stack-sm">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<div class="week-row"><span class="wk-d">${WD[w]}</span><div class="seg" style="flex:1">${['gym', 'run', 'rest'].map((v) => `<button data-act="weekSet" data-w="${w}" data-v="${v}" aria-pressed="${wp[w] === v}">${PLAN_LABEL[v]}</button>`).join('')}</div></div>`).join('')}</div>
      <p class="tiny ${nRun > 4 || nGym + nRun > 6 ? 'warn-text' : 'faint'}">${nGym} de academia · ${nRun} de corrida · ${7 - nGym - nRun} de descanso${nGym + nRun > 6 ? '. Reserve ao menos 1 dia de descanso.' : ''}</p>
      <button class="btn btn-ghost btn-block btn-sm" data-act="weekSuggest">Usar a semana sugerida</button></section>`,
    `<section class="card"><span class="eyebrow">Horários base</span>
      <div class="grid3"><div class="field"><label for="ag-wake">Acordar</label><input id="ag-wake" type="time" value="${esc(p.wakeTime)}" data-change="pf" data-f="wakeTime" data-t="time"></div>
      <div class="field"><label for="ag-train">Treino</label><input id="ag-train" type="time" value="${esc(p.trainTime)}" data-change="pf" data-f="trainTime" data-t="time"></div>
      <div class="field"><label for="ag-bed">Dormir</label><input id="ag-bed" type="time" value="${esc(p.bedTime)}" data-change="pf" data-f="bedTime" data-t="time"></div></div>
      <button class="btn btn-ghost btn-block btn-sm" data-act="sheet" data-s="horarios">${icon('bowl', 'ic-sm')}Horários das 6 refeições</button></section>`,
    `<section class="card"><span class="eyebrow">Blocos fixos</span><p class="small muted">Trabalho, estudo, igreja, buscar filho… Tudo que tem hora marcada entra aqui para o dia caber.</p>
      ${custom.length ? `<div>${custom.map((c) => `<div class="kv"><span class="grow"><b>${esc(c.label)}</b><br><span class="small muted">${esc(c.time)}${c.end ? '–' + esc(c.end) : ''} · ${!c.days || c.days.length === 7 ? 'todos os dias' : [1, 2, 3, 4, 5, 6, 0].filter((d) => c.days.includes(d)).map((d) => WD[d].toLowerCase()).join(', ')}</span></span><button class="btn btn-icon btn-ghost" style="width:44px;min-height:44px" data-act="sheet" data-s="bloco" data-id="${c.id}" aria-label="Editar ${esc(c.label)}">${icon('edit', 'ic-sm')}</button></div>`).join('')}</div>` : ''}
      <button class="btn btn-soft btn-block btn-sm" data-act="sheet" data-s="bloco">${icon('plus', 'ic-sm')}Adicionar bloco</button></section>`,
    `<section class="card card-flat"><span class="eyebrow">Para o tempo render</span><ul class="clean">
      <li>${icon('check', 'ic-sm')}<span class="small">Domingo: prepare 3–4 marmitas e lave as frutas da semana.</span></li>
      <li>${icon('check', 'ic-sm')}<span class="small">Na noite anterior: roupa do treino separada e garrafa de água cheia.</span></li>
      <li>${icon('check', 'ic-sm')}<span class="small">Leve o lanche da manhã e o da tarde de casa.</span></li>
      <li>${icon('check', 'ic-sm')}<span class="small">Celular longe da cama: dormir no horário é o que sustenta o treino das ${esc(p.trainTime)}.</span></li></ul></section>`,
  ].join('');
}
function blocoSheet(d) {
  const c = d.id ? (prof().custom || []).find((x) => x.id === d.id) : null, v = c || { days: [1, 2, 3, 4, 5] };
  return { title: c ? 'Editar bloco' : 'Novo bloco fixo', body: `
    <div class="field"><label for="bl-label">Nome</label><input id="bl-label" type="text" value="${esc(v.label || '')}" placeholder="Ex.: Trabalho"></div>
    <div class="grid2"><div class="field"><label for="bl-time">Início</label><input id="bl-time" type="time" value="${esc(v.time || '08:00')}"></div><div class="field"><label for="bl-end">Fim</label><input id="bl-end" type="time" value="${esc(v.end || '')}"></div></div>
    <div class="field"><span class="lbl">Dias</span><div class="days" id="bl-days">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<button class="chip" data-act="toggleChip" data-w="${w}" aria-pressed="${(v.days || []).includes(w)}" aria-label="${WD_LONG[w]}">${WD[w]}</button>`).join('')}</div></div>
    <button class="btn btn-go btn-block" data-act="saveBloco" data-id="${esc(v.id || '')}">Salvar</button>
    ${c ? `<button class="btn btn-danger btn-block btn-sm" data-act="delBloco" data-id="${c.id}">${icon('trash', 'ic-sm')}Excluir bloco</button>` : ''}` };
}

/* ---------------- plano mensal da academia ---------------- */
const monthPlanFor = (k) => ((coreRead().monthPlans || {})[L.monthKey(k || today())]) || null;
const prevMonthKey = (k) => { const [y, m] = L.monthKey(k).split('-').map(Number); return m === 1 ? `${y - 1}-12` : `${y}-${L.pad(m - 1)}`; };
function defaultMonthPlan(k) {
  const cfg = C.weekConfig(progWeek(k)), out = {};
  for (const t of ['A', 'B']) out[t] = C.PROGRAM[t].slots.map((slot) => { const exId = slotChoice(slot); return { exId, slotId: slot.id, role: slot.role, sets: cfg[slot.role][0], reps: repsFor(exId, slot.role, cfg), rest: cfg.rest[slot.role] }; });
  return out;
}
function monthPlanCard(k) {
  const all = coreRead().monthPlans || {}, mp = monthPlanFor(k), mk = L.monthKey(k), prev = all[prevMonthKey(k)];
  const decided = Object.prototype.hasOwnProperty.call(all, mk);
  const mName = MONTHS_LONG[Number(mk.slice(5)) - 1];
  if (!mp && prev && !decided) {
    return `<section class="card card-now"><span class="eyebrow go">Novo mês, novo plano</span><p class="small">Em ${MONTHS_LONG[Number(prevMonthKey(k).slice(5)) - 1]} você usou um plano personalizado. Quer manter para ${mName} ou usar a sugestão da fase atual?</p>
      <div class="btn-row"><button class="btn btn-soft btn-sm" data-act="monthKeep">Manter</button><button class="btn btn-ghost btn-sm" data-act="monthDefault">Usar sugestão</button></div></section>`;
  }
  return `<section class="card"><div class="between"><span class="eyebrow">Plano de ${mName}</span><span class="badge ${mp ? 'ok' : ''}">${mp ? 'personalizado' : 'sugestão do app'}</span></div>
    <p class="small muted">${mp ? 'Seus treinos deste mês seguem o que você definiu. Ajuste quando quiser.' : 'A cada mês você pode trocar exercícios, séries e repetições. Sem mexer, o app ajusta sozinho pela fase.'}</p>
    <button class="btn btn-ghost btn-block btn-sm" data-act="go" data-to="planoMes">${icon('edit', 'ic-sm')}${mp ? 'Editar plano do mês' : 'Personalizar este mês'}</button></section>`;
}
function vPlanoMes() {
  const k = today(), mp = monthPlanFor(k) || defaultMonthPlan(k), custom = !!monthPlanFor(k);
  const mName = MONTHS_LONG[Number(L.monthKey(k).slice(5)) - 1];
  return [
    subTop('Plano do mês', 'treino'),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Plano de ${mName}</h1><p class="muted">${custom ? 'Personalizado por você.' : 'Sugestão do app para a sua fase. Toque em um exercício para mudar.'}</p></div>`,
    ...['A', 'B'].map((t) => `<section class="card"><div class="between"><span class="eyebrow">${C.PROGRAM[t].title}</span><span class="tiny faint">${esc(C.PROGRAM[t].focus)}</span></div>
      <div>${(mp[t] || []).map((e, i) => `<button class="list-row" style="padding:12px 0;min-height:56px" data-act="sheet" data-s="planItem" data-t="${t}" data-i="${i}"><span class="grow" style="min-width:0"><b>${esc((C.EX[e.exId] || {}).name || e.exId)}</b><br><span class="small muted">${e.sets} × ${esc(e.reps)} · descanso ${e.rest} s</span></span>${icon('chevR', 'chev')}</button>`).join('')}</div>
      <button class="btn btn-soft btn-block btn-sm" data-act="sheet" data-s="planItem" data-t="${t}" data-i="new">${icon('plus', 'ic-sm')}Adicionar exercício</button></section>`),
    custom ? `<button class="btn btn-ghost btn-block" data-act="monthDefault">Voltar à sugestão do app</button>` : '',
    `<p class="tiny faint">Mudanças valem para os treinos deste mês. No mês seguinte, o app pergunta se você quer manter.</p>`,
  ].join('');
}
function planItemSheet(d) {
  const k = today(), mp = monthPlanFor(k) || defaultMonthPlan(k), list = mp[d.t] || [];
  const isNew = d.i === 'new', e = isNew ? { exId: 'legpress', sets: 3, reps: '10–12', rest: 90 } : list[Number(d.i)];
  if (!e) return { title: 'Exercício', body: '' };
  const groups = {};
  Object.entries(C.EX).forEach(([id, ex]) => { const g = ex.group.split(' · ')[0]; (groups[g] = groups[g] || []).push([id, ex.name]); });
  return { title: isNew ? 'Adicionar exercício' : 'Editar exercício', body: `
    <div class="field"><label for="pi-ex">Exercício</label><select id="pi-ex">${Object.entries(groups).map(([g, arr]) => `<optgroup label="${esc(g)}">${arr.map(([id, n]) => `<option value="${id}" ${id === e.exId ? 'selected' : ''}>${esc(n)}</option>`).join('')}</optgroup>`).join('')}</select></div>
    <div class="grid2"><div class="field"><label for="pi-sets">Séries</label><div class="stepper"><button data-act="nudge" data-for="pi-sets" data-d="-1" aria-label="Menos séries">${icon('minus')}</button><input id="pi-sets" type="number" inputmode="numeric" value="${e.sets}"><button data-act="nudge" data-for="pi-sets" data-d="1" aria-label="Mais séries">${icon('plus')}</button></div></div>
      <div class="field"><label for="pi-reps">Repetições ou tempo</label><input id="pi-reps" type="text" value="${esc(e.reps)}" placeholder="10–12 ou 30–40 s"></div></div>
    <div class="field"><label for="pi-rest">Descanso</label><select id="pi-rest">${[45, 60, 75, 90, 120, 150].map((s) => `<option value="${s}" ${Number(e.rest) === s ? 'selected' : ''}>${s} s</option>`).join('')}</select></div>
    <button class="btn btn-go btn-block" data-act="savePlanItem" data-t="${d.t}" data-i="${d.i}">Salvar</button>
    ${isNew ? '' : `<button class="btn btn-danger btn-block btn-sm" data-act="delPlanItem" data-t="${d.t}" data-i="${d.i}">${icon('trash', 'ic-sm')}Tirar do treino</button>`}` };
}
