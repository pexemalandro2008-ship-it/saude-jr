/* ===== Saúde Jr. — telas ===== */
const ui = {
  route: 'splash', sub: { treino: 'academia', comida: 'refeicoes', evolucao: 'progresso' }, openEx: 0, ob: null, finish: null,
  chartRange: 90, sheet: null, me: null, owner: null, back: 'mais', assets: undefined, downloads: undefined,
  agendaDay: 'hoje', run: null, runResult: null, photoPose: 'frente', tl: null, installEvt: null,
};
const TABS = [['home', 'Hoje', 'home'], ['treino', 'Treino', 'dumbbell'], ['comida', 'Alimentação', 'bowl'], ['evolucao', 'Evolução', 'trend'], ['mais', 'Perfil', 'user']];
const ROUTE_TAB = { auth: 'home', home: 'home', agenda: 'home', treino: 'treino', sessao: 'treino', fim: 'treino', corrida: 'treino', planoMes: 'treino', comida: 'comida', evolucao: 'evolucao', mais: 'mais', sono: 'mais', hormonal: 'mais', lembretes: 'mais', perfil: 'mais', seguranca: 'mais', instalar: 'mais', privacidade: 'mais' };
const NO_TABS = new Set(['splash', 'onboarding', 'sessao', 'fim', 'corrida', 'auth']);

const attrs = (o) => Object.entries(o || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ');
const btnHtml = (b, cls) => (b ? `<button class="btn ${cls || 'btn-go btn-block'}" data-act="${b.act}" ${attrs(b.data)}>${b.icon ? icon(b.icon) : ''}${esc(b.label)}</button>` : '');

function syncInfo() {
  const s = Store.status;
  if (s === 'ok') return ['ok', 'Salvo'];
  if (s === 'syncing') return ['syncing', 'Salvando…'];
  if (s === 'offline') return ['offline', 'Offline · salvo aqui'];
  if (s === 'error') return ['error', 'Sem sincronizar'];
  if (s === 'local') return ['', 'Neste aparelho'];
  return ['', '…'];
}
function topBar() {
  const [cls, label] = syncInfo();
  return `<header class="top"><div class="brand"><span class="brand-mark">${icon('logo')}</span>Saúde Jr.</div>
    <button class="top-btn" data-act="go" data-to="perfil" aria-label="Perfil e sincronização"><span class="dot ${cls}"></span><span id="syncLabel">${label}</span></button></header>`;
}
function subTop(title, back) {
  return `<header class="top"><button class="back" data-act="go" data-to="${back || ui.back || 'mais'}">${icon('chevL')}Voltar</button><span class="eyebrow">${esc(title)}</span></header>`;
}
function ring(pct, size, label) {
  const r = 26, c = 2 * Math.PI * r, off = c * (1 - pct / 100);
  return `<svg class="ring" viewBox="0 0 64 64" ${size ? `style="width:${size}px;height:${size}px"` : ''} role="img" aria-label="${pct}% do dia concluído">
    <circle class="bg" cx="32" cy="32" r="${r}" fill="none" stroke-width="7"/>
    <circle class="fg" cx="32" cy="32" r="${r}" fill="none" stroke-width="7" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}" transform="rotate(-90 32 32)"/>
    <text x="32" y="38" text-anchor="middle">${label || pct + '%'}</text></svg>`;
}
function seg(group, items, cur) {
  return `<div class="seg" role="group">${items.map(([v, l]) => `<button data-act="seg" data-group="${group}" data-v="${v}" aria-pressed="${cur === v}">${l}</button>`).join('')}</div>`;
}
function canShowGoalPhotos() { return !!(IMG.before && IMG.after) && prof().showGoalPhotos !== false && ui.owner !== false; }

/* =============== ABERTURA =============== */
function vSplash() {
  if (CLOUD) {
    return `<div class="splash"><div class="brand"><span class="brand-mark">${icon('logo')}</span>Saúde Jr.</div><div class="loader" aria-label="Carregando"></div><p class="small muted">Abrindo a sua conta…</p>
      ${ui.splashSlow ? `<p class="small muted" style="max-width:300px">A internet está lenta.</p><button class="btn btn-ghost btn-sm" data-act="authOffline">Continuar sem internet</button>` : ''}</div>`;
  }
  return `<div class="splash"><div class="brand"><span class="brand-mark">${icon('logo')}</span>Saúde Jr.</div><div class="loader" aria-label="Carregando"></div><p class="small muted">Carregando seus dados…</p>
    ${ui.splashSlow ? `<p class="small muted" style="max-width:300px">Se aparecer um pedido de permissão, toque em permitir: é assim que o app guarda seus dados na sua conta.</p><button class="btn btn-ghost btn-sm" data-act="skipCloud">Usar sem sincronizar por enquanto</button>` : ''}</div>`;
}

/* =============== BOAS-VINDAS / CADASTRO =============== */
function obInit() {
  const d = Object.assign({}, DEFAULTS);
  d.name = ui.user && ui.user.name ? ui.user.name : ui.me && ui.me.name ? firstName(ui.me.name) : '';
  d.waist = '';
  try {
    const m = /(?:^|[#&])ini=([\d.,]+)/.exec(location.hash || '');
    if (m) {
      const [age, height, weight, goal] = m[1].split(',').map(Number);
      if (age >= 14 && age <= 100) d.age = age;
      if (height >= 120 && height <= 230) d.height = height;
      if (weight >= 40 && weight <= 300) d.startWeight = weight;
      if (goal >= 40 && goal < (d.startWeight || 999)) d.goalWeight = goal;
      if (history.replaceState) history.replaceState(null, '', location.pathname + location.search);
    }
  } catch (e) { /* link sem perfil */ }
  ui.ob = { step: 0, d, safety: {} };
}
function vOnboarding() {
  if (!ui.ob) obInit();
  const { step, d } = ui.ob;
  const bars = `<div class="ob-steps" aria-hidden="true">${[0, 1, 2, 3].map((i) => `<i class="${i <= step ? 'on' : ''}"></i>`).join('')}</div>`;
  if (step === 0) {
    return `<section class="ob-hero">
      <div class="brand"><span class="brand-mark">${icon('logo')}</span>Saúde Jr.</div>
      <div class="h1">${fin(d.startWeight) ? `${fmt0(d.startWeight)} kg hoje.<br>` : 'Saúde em primeiro lugar.<br>'}<span class="go-text">A virada começa agora.</span></div>
      <p class="muted">Construir, passo a passo, uma versão mais saudável, forte, disciplinada e ativa de você. Menos complexidade, mais execução.</p>
    </section>
    <section class="card"><ul class="clean">
      <li>${icon('check', 'ic-sm')}<span>O que fazer agora e a agenda do dia, numa tela só</span></li>
      <li>${icon('check', 'ic-sm')}<span>Academia guiada e plano de corrida até a prova de 10 km</span></li>
      <li>${icon('check', 'ic-sm')}<span>6 refeições com frutas e fibras, avisos e seus suplementos</span></li>
      <li>${icon('check', 'ic-sm')}<span>Foto diária e evolução pela tendência, sem obsessão com a balança</span></li>
    </ul></section>
    <button class="btn btn-go btn-block" data-act="obNext">Começar</button>
    <p class="tiny faint center">Leva 1 minuto. Você pode mudar tudo depois.</p>`;
  }
  if (step === 1) {
    return `${bars}<div class="stack-sm"><span class="eyebrow">Passo 1 de 3</span><div class="h1">Seu ponto de partida</div></div>
    <section class="card">
      <div class="field"><label for="ob-name">Como quer ser chamado?</label><input id="ob-name" type="text" autocomplete="given-name" value="${esc(d.name)}" placeholder="Seu nome"></div>
      <div class="grid2">
        <div class="field"><label for="ob-age">Idade</label><input id="ob-age" type="number" inputmode="numeric" value="${esc(d.age)}"></div>
        <div class="field"><label for="ob-height">Altura (cm)</label><input id="ob-height" type="number" inputmode="numeric" value="${esc(d.height)}"></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="ob-weight">Peso hoje (kg)</label><input id="ob-weight" type="text" inputmode="decimal" autocomplete="off" value="${decv(d.startWeight)}"></div>
        <div class="field"><label for="ob-waist">Cintura (cm)</label><input id="ob-waist" type="text" inputmode="decimal" autocomplete="off" value="${decv(d.waist)}" placeholder="opcional"></div>
      </div>
      <p class="hint">Cintura: fita na altura do umbigo, sem apertar, depois de soltar o ar.</p>
      <div class="field"><label for="ob-goal">Meta de peso pessoal (kg)</label><input id="ob-goal" type="text" inputmode="decimal" autocomplete="off" value="${decv(d.goalWeight)}"></div>
      <p class="hint">Meta escolhida por você. Valide com médico e nutricionista numa avaliação física. O app trabalha com metas intermediárias de 5 em 5 kg.</p>
    </section>
    <div class="btn-row"><button class="btn btn-ghost" data-act="obBack">Voltar</button><button class="btn btn-go" data-act="obNext">Continuar</button></div>`;
  }
  if (step === 2) {
    return `${bars}<div class="stack-sm"><span class="eyebrow">Passo 2 de 3</span><div class="h1">Sua rotina</div></div>
    <section class="card">
      <div class="field"><span class="lbl">Dias de treino</span>
        <div class="days">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<button class="chip" data-act="obDay" data-w="${w}" aria-pressed="${d.trainDays.includes(w)}" aria-label="${WD_LONG[w]}">${WD[w]}</button>`).join('')}</div>
        <p class="hint">O app alterna academia e corrida/caminhada nesses dias. Para a meta dos 10 km, 5 dias com 2 de descanso funcionam bem. Dá para ajustar depois na Agenda.</p></div>
      <div class="grid2">
        <div class="field"><label for="ob-train">Horário do treino</label><input id="ob-train" type="time" value="${esc(d.trainTime)}"></div>
        <div class="field"><label for="ob-wake">Acordar</label><input id="ob-wake" type="time" value="${esc(d.wakeTime)}"></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="ob-bed">Dormir</label><input id="ob-bed" type="time" value="${esc(d.bedTime)}"></div>
        <div class="field"><label for="ob-steps">Meta de passos</label><input id="ob-steps" type="number" inputmode="numeric" step="500" value="${esc(d.stepsGoal)}"></div>
      </div>
      <div class="field"><label for="ob-water">Meta de água (ml por dia)</label><input id="ob-water" type="number" inputmode="numeric" step="250" value="${esc(d.waterGoal)}">
        <p class="hint">Ponto de partida ajustável, não uma regra universal. Ajuste pela sede, pelo calor e pelos treinos, e siga a orientação do seu médico se tiver alguma restrição.</p></div>
      <div class="field"><label for="ob-activity">Nível de atividade hoje</label><select id="ob-activity"><option value="">Escolha</option>${C.ACTIVITY_LEVELS.map(([v, l, s]) => `<option value="${v}" ${d.activityLevel === v ? 'selected' : ''}>${l} · ${s}</option>`).join('')}</select></div>
      <div class="field"><label for="ob-pref">Treino preferido</label><select id="ob-pref"><option value="">Escolha</option>${C.TRAIN_PREFS.map(([v, l]) => `<option value="${v}" ${d.trainPref === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    </section>
    <div class="btn-row"><button class="btn btn-ghost" data-act="obBack">Voltar</button><button class="btn btn-go" data-act="obNext">Continuar</button></div>`;
  }
  const s = ui.ob.safety;
  return `${bars}<div class="stack-sm"><span class="eyebrow">Passo 3 de 3</span><div class="h1">Segurança primeiro</div>
    <p class="muted">Marque as que forem <b>sim</b>. Isso não é diagnóstico: serve para saber se vale falar com um médico antes de intensificar.</p></div>
    <section class="card">${C.SAFETY_QUESTIONS.map(([id, q]) => `<div class="switch-row"><span class="small">${q}</span><button class="switch" role="switch" aria-checked="${!!s[id]}" aria-label="${esc(q)}" data-act="obSafety" data-q="${id}"></button></div>`).join('<hr class="divider">')}</section>
    <div class="note">${icon('shield')}<span>${C.STOP_SIGNS}</span></div>
    <div class="btn-row"><button class="btn btn-ghost" data-act="obBack">Voltar</button><button class="btn btn-go" data-act="obFinish">Pronto</button></div>`;
}

/* =============== HOJE =============== */
function vHome() {
  const k = today(), p = prof(), info = dayInfo(k);
  const yest = L.addDays(k, -1);
  const restart = startDate() <= L.addDays(k, -2) && !isConsistent(yest) && info.score < L.CONSISTENT;
  const na = nextAction();
  return [
    topBar(),
    `<section class="hello"><h1>${greeting()}${p.name ? ', ' + esc(firstName(p.name)) : ''}.</h1><p class="muted">Hoje é ${dLong(k)}</p>${p.goal ? `<p class="small muted goal-line">${icon('target', 'ic-sm')}${esc(p.goal)}${fin(p.goalWeight) ? ` · meta ${fmtKg(p.goalWeight)} kg` : ''}</p>` : ''}</section>`,
    startDayCard(k, info),
    safetyCard(),
    restart ? `<div class="note go">${icon('flame')}<span><b>Ontem acabou. Hoje começa novamente.</b></span></div>` : '',
    nowCard(na),
    installHint(),
    weekTipCard(),
    trainCard(k, na.btn && (na.btn.act === 'startSession' || na.btn.act === 'runStart')),
    waterCard(k, info),
    `<div class="grid2">${weightTile()}${streakTile()}</div>`,
    `<div class="grid3">${stepsTile(info)}${sleepTile(info)}${energyTile(info)}</div>`,
    foodCard(k),
    agendaCard(k),
    checklistCard(k, info),
    photoCard(k),
    metaCard(),
    `<section class="card"><span class="eyebrow">Frase de hoje</span><p class="quote">${esc(phraseOf(k))}</p></section>`,
  ].join('');
}
/** botão COMEÇAR O DIA: sono, energia, primeiro copo de água e o plano do dia, em um toque */
function startDayCard(k, info) {
  const d = info.d;
  if (d.started) {
    const t = new Date(d.started);
    return `<div class="note go start-done">${icon('check')}<span>Dia começado às ${L.pad(t.getHours())}:${L.pad(t.getMinutes())}. Siga o card <b>Agora</b>.</span></div>`;
  }
  if (nowMin() >= 17 * 60) return '';
  const plan = dayPlan(k), p = prof();
  const trainTxt = plan === 'gym' ? `${C.PROGRAM[nextType()].title} às ${p.trainTime}` : plan === 'run' ? `Corrida/caminhada às ${p.trainTime}` : 'Descanso ativo (caminhada leve)';
  return `<section class="card card-start"><div class="stack-sm"><span class="eyebrow go">${icon('sun', 'ic-sm')} Seu dia</span>
      <p class="small muted">${esc(trainTxt)} · 6 refeições · ${fmt0(p.waterGoal)} ml de água</p></div>
    <button class="btn btn-go btn-block btn-xl" data-act="sheet" data-s="comecarDia">${icon('sun')}COMEÇAR O DIA</button></section>`;
}
function installHint() {
  if (!PWA) return '';
  const standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone;
  let hidden = ui.hideInstall; try { hidden = hidden || localStorage.getItem('mv1:hideInstall') === '1'; } catch (e) { /* ok */ }
  if (standalone || hidden) return '';
  return `<section class="card tight"><div class="between"><span class="eyebrow go">Instale o app</span><button class="btn btn-icon btn-ghost" style="width:40px;min-height:40px" data-act="installHintOff" aria-label="Dispensar">${icon('x', 'ic-sm')}</button></div>
    <p class="small muted">Com o Saúde Jr. instalado, ele abre pelo ícone, funciona sem internet e fica na sua lista de aplicativos.</p>
    ${ui.installEvt ? `<button class="btn btn-go btn-block" data-act="installApp">${icon('download')}Instalar agora</button>` : `<button class="btn btn-soft btn-block" data-act="go" data-to="instalar">${icon('download')}Como instalar</button>`}</section>`;
}
function weekTipCard() {
  const p = prof();
  if (p.week || p.weekTip === false || runDays().length >= 3) return '';
  return `<section class="card tight"><div class="between"><span class="eyebrow">Sua semana para os 10 km</span><button class="btn btn-icon btn-ghost" style="width:40px;min-height:40px" data-act="weekTipOff" aria-label="Dispensar">${icon('x', 'ic-sm')}</button></div>
    <p class="small muted">Para chegar bem na prova: 3 dias de corrida ou caminhada e 2 de academia, com descanso entre eles.</p>
    <div class="btn-row"><button class="btn btn-soft btn-sm" data-act="weekSuggest">Usar sugerida</button><button class="btn btn-ghost btn-sm" data-act="go" data-to="agenda">Montar a minha</button></div></section>`;
}
function safetyCard() {
  const s = prof().safety;
  if (!s || !s.flag || s.cleared) return '';
  return `<section class="card card-warn tight"><div class="row">${icon('shield')}<b>Converse com um médico antes de intensificar</b></div>
    <p class="small">Você marcou pontos que merecem avaliação. Até lá: caminhadas leves e cargas bem baixas, sem forçar.</p>
    <div class="btn-row"><button class="btn btn-sm btn-ghost" data-act="go" data-to="seguranca">Ver orientações</button><button class="btn btn-sm" data-act="safetyCleared">Já fui liberado</button></div></section>`;
}
function nowCard(na) {
  return `<section class="card card-now" aria-live="polite"><div class="between"><span class="eyebrow go">Agora</span><span class="tiny faint">${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span></div>
    <div class="stack-sm"><div class="now-title">${esc(na.title)}</div>${na.text ? `<p class="muted">${esc(na.text)}</p>` : ''}</div>
    ${btnHtml(na.btn)}${na.alt ? `<button class="link-btn" data-act="${na.alt.act}" ${attrs(na.alt.data)}>${esc(na.alt.label)}</button>` : ''}</section>`;
}
function checklistCard(k, info) {
  const pct = Math.round(info.score * 100);
  const n = L.CHECK_KEYS.filter((x) => info.st[x]).length;
  return `<section class="card" id="hoje"><div class="card-head"><div class="stack-sm"><span class="eyebrow">Hoje</span><div class="h2">Dia concluído: ${pct}%</div></div>${ring(pct, 0, n + '/8')}</div>
    <div class="checks">${L.CHECK_KEYS.map((key) => `<button class="check" data-act="check" data-k="${key}" aria-pressed="${info.st[key]}"><span class="box">${icon('check')}</span><span>${checkLabel(key, k)}</span></button>`).join('')}</div>
    <p class="tiny faint">Toque para marcar. Água, treino, passos e sono se marcam sozinhos quando você registra. Metade do checklist já conta para a sequência.</p></section>`;
}
function runCard(k, agoraIsRun) {
  const rs = runSessionFor(k), info = rs ? rs.info : runPlanInfo(k);
  const badge = `<span class="badge">Corrida · semana ${info.w}/${info.N}</span>`;
  if (ui.run && ui.run.active) return `<section class="card card-now"><span class="eyebrow go">Sessão em andamento</span><div class="h2">${esc(ui.run.title)}</div><button class="btn btn-go btn-block" data-act="go" data-to="corrida">${icon('play')}Voltar à sessão</button></section>`;
  const done = runsOn(k);
  if (done.length) {
    const r = done[done.length - 1];
    return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span><span class="badge ok">${icon('check', 'ic-sm')}Feito</span></div>
      <div class="stack-sm"><div class="h2">${esc(r.title || 'Sessão')}</div><p class="small muted">${r.minutes} min${r.km ? ` · ${fmt1(r.km)} km` : ''} · ${esc(placeName(r.place))}</p></div></section>`;
  }
  if (!rs) return '';
  const s = sessionToRun(rs.s);
  return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span>${badge}</div>
    <div class="stack-sm"><div class="h2">${esc(s.title)}</div>${(() => { const sum = sessionSummary(s), pl = s.place === 'praia' ? 'praia, areia firme' : s.place === 'orla' ? 'orla' : ''; const line = [s.title.includes(sum) ? '' : sum, pl].filter(Boolean).join(' · '); return line ? `<p class="small muted">${esc(line)}</p>` : ''; })()}${s.note ? `<p class="small muted">${esc(s.note)}</p>` : ''}</div>
    ${sessionLocked(rs.s) ? `<p class="small warn-text">Versão caminhada até a liberação médica.</p>` : ''}
    ${agoraIsRun ? `<button class="btn btn-ghost btn-block" data-act="tabSub" data-to="treino" data-sub="corrida">Ver plano da corrida</button>` : `<button class="btn btn-go btn-block" data-act="runStart" data-idx="${rs.idx}">${icon('play')}Começar sessão</button>`}</section>`;
}
function photoCard(k) {
  const todayP = photosMeta().filter((p) => p.date === k && (p.pose || 'frente') === 'frente');
  const st = photoStreakNow();
  return `<section class="card tight"><div class="between"><span class="eyebrow">Foto do dia</span><span class="badge ${todayP.length ? 'ok' : ''}">${todayP.length ? 'feita' : 'pendente'} · 🔥 ${st}</span></div>
    ${todayP.length ? `<div class="row"><div class="thumbs"><div class="ph">${photoImg(todayP[0])}</div></div><p class="small muted grow">Foto de hoje salva. Com o tempo, a linha do tempo mostra a mudança.</p></div><button class="btn btn-ghost btn-block btn-sm" data-act="tabSub" data-to="evolucao" data-sub="fotos">Ver minhas fotos</button>`
      : `<button class="btn btn-soft btn-block" data-act="photoAdd" data-pose="frente">${icon('camera')}Tirar a foto de hoje</button>`}</section>`;
}
function trainCard(k, agoraIsTrain) {
  if (isRunDay(k) || k === runCfg().race.date) return runCard(k, agoraIsTrain);
  const week = progWeek(k), ph = C.phaseOf(week);
  const act = activeSession();
  const badge = `<span class="badge">Fase ${ph} · Semana ${week}</span>`;
  if (act) {
    const st = sessionStats(act);
    return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span>${badge}</div>
      <div class="stack-sm"><div class="h2">${esc(sessionTitle(act))} em andamento</div><p class="small muted">${st.done} de ${st.total} exercícios feitos</p></div>
      <div class="bar"><i style="width:${Math.round((st.done / st.total) * 100)}%"></i></div>
      <button class="btn btn-go btn-block" data-act="resumeSession">${icon('play')}Continuar treino</button></section>`;
  }
  const done = MEMO().sessions.filter((s) => s.date === k && s.completed);
  if (done.length) {
    const s = done[done.length - 1], st = sessionStats(s);
    return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span><span class="badge ok">${icon('check', 'ic-sm')}Feito</span></div>
      <div class="stack-sm"><div class="h2">${esc(sessionTitle(s))} concluído</div><p class="small muted">${st.min} min · ${st.done}/${st.total} exercícios · ${st.sets} séries</p></div>
      <p class="small">Próximo: <b>${C.PROGRAM[nextType()].title}</b> ${nextTrainDayText(k)}.</p></section>`;
  }
  if (!isTrainDay(k)) {
    return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span>${badge}</div>
      <div class="stack-sm"><div class="h2">Descanso ativo</div><p class="small muted">Caminhada leve de 20–30 min. O músculo cresce no descanso; o hábito cresce no movimento.</p></div>
      <button class="btn btn-soft btn-block" data-act="sheet" data-s="cardio" data-kind="caminhada">${icon('walk')}Registrar caminhada</button>
      <button class="link-btn" data-act="startSession" data-type="${nextType()}">Quero treinar mesmo assim (${C.PROGRAM[nextType()].title})</button></section>`;
  }
  const t = nextType(), prog = C.PROGRAM[t];
  return `<section class="card"><div class="between"><span class="eyebrow">Treino de hoje</span>${badge}</div>
    <div class="stack-sm"><div class="h2">${prog.title}</div><p class="small muted">${prog.focus} · ${((monthPlanFor(k) || {})[t] || prog.slots).length} exercícios · ~${estMinutes(t, week)} min</p><p class="small muted">Cardio: ${C.cardioPlan(week).minutes} min leve depois da musculação (bike, esteira ou elíptico).</p></div>
    ${agoraIsTrain
      ? `<div class="btn-row"><button class="btn btn-ghost" data-act="tab" data-to="treino">Ver exercícios</button><button class="btn btn-ghost" data-act="startSession" data-type="R">Rápido · 25 min</button></div>`
      : `<button class="btn btn-go btn-block" data-act="startSession" data-type="${t}">${icon('play')}Começar treino</button>
    <button class="btn btn-ghost btn-block" data-act="startSession" data-type="R">${icon('bolt')}Treino rápido · 25 min</button>`}</section>`;
}
function nextTrainDayText(k) {
  for (let i = 1; i <= 7; i++) { const d = L.addDays(k, i); if (isGymDay(d)) return i === 1 ? 'amanhã' : `na ${WD_LONG[L.weekday(d)]}`; }
  return '';
}
function waterCard(k, info) {
  const p = prof(), ml = info.d.water || 0, goal = p.waterGoal || 3000;
  const n = Math.min(20, Math.max(4, Math.ceil(goal / 250)));
  const per = goal / n, on = Math.min(n, Math.floor(ml / per + 0.001));
  return `<section class="card"><div class="card-head"><span class="eyebrow">Água</span><button class="link-btn" data-act="sheet" data-s="agua">Meta ${fmt0(goal)} ml</button></div>
    <div class="row" style="align-items:baseline"><span class="num" style="font-size:50px">${fmt0(ml)}</span><span class="muted">/ ${fmt0(goal)} ml</span>${ml >= goal ? `<span class="badge ok" style="margin-left:auto">${icon('check', 'ic-sm')}Meta batida</span>` : ''}</div>
    <div class="cups" style="--n:${n}" aria-hidden="true">${Array.from({ length: n }, (_, i) => `<span class="cup ${i < on ? 'on' : ''}"></span>`).join('')}</div>
    <p class="small muted">${on} de ${n} copos${Math.round(per) !== 250 ? ` de ${fmt0(per)} ml` : ' de 250 ml'}</p>
    <div class="water-btns"><button class="btn" data-act="water" data-ml="250">+250</button><button class="btn" data-act="water" data-ml="500">+500</button><button class="btn" data-act="water" data-ml="750">+750</button><button class="btn btn-icon btn-ghost" data-act="waterUndo" aria-label="Desfazer último registro de água">${icon('undo')}</button></div></section>`;
}
function weightTile() {
  const cur = curWeight(), pg = phaseGoal(), r = MEMO().rate;
  const rateTxt = r == null ? 'pese 1 a 3 vezes por semana' : `Tendência ${signed(r)} kg/sem`;
  return `<button class="tile" data-act="sheet" data-s="peso"><span class="eyebrow">Peso</span><span class="num">${fmt1(cur)}<span class="unit">kg</span></span>
    <span class="cap">${rateTxt}</span><span class="cap">${pg ? `Meta da fase ↓ <b>${fmtKg(pg)} kg</b><br>faltam ${fmt1(cur - pg)} kg` : 'Meta final alcançada'}</span></button>`;
}
function streakTile() {
  const n = streakNow();
  return `<button class="tile" data-act="tab" data-to="evolucao"><span class="eyebrow">🔥 Consistência</span><span class="num">${n}<span class="unit">${n === 1 ? 'dia' : 'dias'}</span></span>
    <span class="cap">Maior sequência: ${streakBest()}<br>Dias ativos: ${activeDays()}</span></button>`;
}
function stepsTile(info) {
  const p = prof(), s = info.d.steps || 0, k = today();
  const cmin = MEMO().cardio.filter((c) => c.date === k).reduce((a, c) => a + (c.minutes || 0), 0) + runsOn(k).reduce((a, r) => a + (r.minutes || 0), 0);
  return `<button class="tile" data-act="sheet" data-s="passos"><span class="eyebrow">Passos</span><span class="num">${fmt0(s)}</span><span class="cap">meta ${fmt0(p.stepsGoal)}${cmin ? `<br>${cmin} min de cardio` : ''}</span></button>`;
}
function sleepTile(info) {
  const s = info.d.sleep;
  return `<button class="tile" data-act="sheet" data-s="sono"><span class="eyebrow">Sono</span><span class="num">${s && s.hours ? fmt1(s.hours) : '—'}<span class="unit">h</span></span><span class="cap">${s && s.quality ? ['Ruim', 'Regular', 'Boa', 'Ótima'][s.quality - 1] : 'registrar'}</span></button>`;
}
function energyTile(info) {
  const s = info.d.sleep || {}, v = s.day || s.energy;
  return `<button class="tile" data-act="sheet" data-s="energia"><span class="eyebrow">Energia</span><span class="num">${v || '—'}<span class="unit">/10</span></span><span class="cap">${s.day ? 'hoje' : s.energy ? 'ao acordar' : 'como está?'}</span></button>`;
}
function foodCard(k) {
  const st = dayFoodStats(k);
  return `<section class="card tight"><div class="between"><span class="eyebrow">Alimentação</span><span class="badge ${st.done >= 5 ? 'ok' : ''}">${st.done}/6 refeições</span></div>
    <div class="grid3">${metric('Refeições', st.done, '/6')}${metric('Proteína', st.prot, '/4', 'refeições')}${metric('Frutas', Math.min(st.fruits, 9), '/3')}</div>
    <button class="btn btn-soft btn-block" data-act="tab" data-to="comida">${icon('bowl')}Ver alimentação</button></section>`;
}
function mealButtons(k, id, cur) {
  const opts = [['ok', 'Segui', 'check'], ['troca', 'Troquei', 'swap'], ['fora', 'Fugi', 'x']];
  return `<div class="chips" role="group" aria-label="Registrar refeição">${opts.map(([v, l, ic]) => `<button class="chip" data-act="meal" data-k="${k}" data-m="${id}" data-v="${v}" aria-pressed="${cur === v}">${icon(ic, 'ic-sm')}${l}</button>`).join('')}</div>`;
}
function metaNumbers() {
  const p = prof(), start = p.startWeight, goal = p.goalWeight, cur = curWeight();
  const total = Math.max(0.1, start - goal), lost = Math.max(0, start - cur);
  const pct = Math.round(L.clamp((lost / total) * 100, 0, 100));
  const wFast = L.weeksTo(cur, goal, 0.01), wSlow = L.weeksTo(cur, goal, 0.005);
  const k = today();
  const range = cur <= goal ? 'meta alcançada' : `${monYear(L.dateAfterWeeks(k, wFast))} a ${monYear(L.dateAfterWeeks(k, wSlow))}`;
  return { start, goal, cur, total, lost, pct, range, left: Math.max(0, cur - goal) };
}
function metaCard() {
  const m = metaNumbers();
  const thumbs = canShowGoalPhotos() ? `<div class="thumbs" aria-hidden="true"><div class="ph"><img src="${IMG.before}" alt=""></div><div class="ph"><img src="${IMG.after}" alt=""></div></div>` : '';
  return `<button class="card" data-act="go" data-to="meta"><div class="between" style="align-items:flex-start"><div class="stack-sm grow"><span class="eyebrow">Minha meta</span>
      <span class="num" style="font-size:44px">${fmtKg(m.goal)}<span class="unit">kg</span></span>
      <span class="small muted">Faltam ${fmt1(m.left)} kg · ${m.pct}% do caminho</span><span class="small muted">Previsão: ${m.range}</span></div>${thumbs}</div>
    <div class="bar thin"><i style="width:${m.pct}%"></i></div></button>`;
}

/* =============== TREINO =============== */
function weekStrip(k) {
  const ws = L.weekStart(k), mm = MEMO();
  return `<div class="week">${[0, 1, 2, 3, 4, 5, 6].map((i) => {
    const d = L.addDays(ws, i), w = L.weekday(d);
    const pl = dayPlan(d), plan = pl !== 'rest', done = mm.trainedDates.has(d) || mm.cardioDates.has(d);
    return `<div class="d ${plan ? 'plan' : ''} ${done ? 'done' : ''} ${d === k ? 'today' : ''}" aria-label="${WD_LONG[w]}${pl === 'gym' ? ', academia' : pl === 'run' ? ', corrida' : ', descanso'}${done ? ', feito' : ''}"><span>${WD1[w]}</span><b>${L.parse(d).getDate()}</b><span class="m">${done ? icon('check') : ''}</span><span class="wk-t">${pl === 'gym' ? 'Acad.' : pl === 'run' ? 'Corr.' : 'Desc.'}</span></div>`;
  }).join('')}</div>`;
}
function vTreino() {
  const sub = ui.sub.treino === 'corrida' ? 'corrida' : 'academia';
  return [
    topBar(),
    `<div class="stack-sm" style="padding:4px 2px"><h1>Treino</h1><p class="muted">Segurança, consistência, progressão. Nessa ordem.</p></div>`,
    seg('treino', [['academia', 'Academia'], ['corrida', 'Corrida e caminhada']], sub),
    sub === 'corrida' ? vCorrida() : vAcademia(),
  ].join('');
}
function vAcademia() {
  const k = today(), week = progWeek(k), ph = C.phaseOf(week), phase = C.PHASES[ph];
  const act = activeSession();
  const t = nextType(), prog = C.PROGRAM[t], cfg = C.weekConfig(week);
  const planList = (monthPlanFor(k) || defaultMonthPlan(k))[t] || [];
  const list = planList.map((e) => {
    const ex = C.EX[e.exId] || {}, st = exRead(e.exId);
    const repsTxt = ex.kind === 'time' ? (() => { const r = L.parseRange(e.reps), b = st.secBonus || 0; return `${r[0] + b}–${r[1] + b} s`; })() : e.reps;
    const load = ex.kind === 'reps' && st.load > 0 ? ` · ${fmtKg(st.load)} kg` : '';
    return `<li class="between"><span class="grow"><b>${esc(ex.name || e.exId)}</b><br><span class="small muted">${esc(ex.group || '')}</span></span><span class="small tnum" style="text-align:right;white-space:nowrap">${e.sets} × ${esc(repsTxt)}<br><span class="faint">${e.rest} s${load}</span></span></li>`;
  }).join('');
  const wc = weekCardio(k), plan = C.cardioPlan(week);
  const cpct = Math.round(L.clamp(wc.min / (plan.sessions * plan.minutes), 0, 1) * 100);
  return [
    `<section class="card"><div class="between"><span class="eyebrow">${phase.name}</span><span class="badge">Semana ${week}</span></div><p class="small muted">${phase.goal}</p>${weekStrip(k)}</section>`,
    act
      ? `<section class="card card-now"><span class="eyebrow go">Em andamento</span><div class="h2">${esc(sessionTitle(act))}</div><button class="btn btn-go btn-block" data-act="resumeSession">${icon('play')}Continuar treino</button></section>`
      : `<section class="card"><div class="between"><div class="stack-sm"><span class="eyebrow">Próximo treino</span><div class="h2">${prog.title}</div></div><span class="badge">~${estMinutes(t, week)} min</span></div>
        <p class="small muted">Aquecimento: ${C.WARMUP}</p>
        <ul class="clean exlist">${list}</ul>
        <button class="btn btn-go btn-block" data-act="startSession" data-type="${t}">${icon('play')}Começar treino</button>
        <button class="link-btn" data-act="startSession" data-type="${t === 'A' ? 'B' : 'A'}">Fazer o ${t === 'A' ? 'Treino B' : 'Treino A'} hoje</button></section>`,
    monthPlanCard(k),
    `<section class="card"><div class="stack-sm"><span class="eyebrow">Modo sem desculpas</span><div class="h2">Treino rápido</div><p class="small muted">Sem tempo ou sem disposição? Uma versão curta e segura. Um dia ruim não vira uma semana parada.</p></div>
      <div class="btn-row"><button class="btn btn-soft" data-act="startSession" data-type="R">${icon('bolt')}Academia · 25 min</button><button class="btn btn-ghost" data-act="startSession" data-type="H">${icon('home')}Em casa · 20 min</button></div></section>`,
    `<section class="card"><div class="between"><span class="eyebrow">Cardio da semana</span><span class="badge ${wc.n >= plan.sessions ? 'ok' : ''}">${wc.n}/${plan.sessions} · ${wc.min}/${plan.sessions * plan.minutes} min</span></div>
      <p class="small muted">${plan.text}</p><div class="bar"><i style="width:${cpct}%"></i></div>
      <button class="btn btn-soft btn-block" data-act="sheet" data-s="cardio">${icon('plus')}Registrar cardio</button>
      <ul class="dots small muted">${C.CARDIO_RULES.map((r) => `<li>${r}</li>`).join('')}</ul></section>`,
    historyCard(),
    `<details class="fold"><summary>Como o treino evolui ${icon('chevR')}</summary><div class="fold-body small muted">
      <p>Depois de cada exercício, marque <b>como foi</b>. Se você completou todas as séries no topo das repetições e marcou <b>Fácil</b> ou <b>Na medida</b>, a carga sobe no próximo treino. <b>Difícil</b> mantém a carga. <b>No limite</b> reduz um pouco para você manter a técnica.</p>
      <p>A cada semana o programa ajusta séries e repetições: Fase 1 (semanas 1–4) adaptação, Fase 2 (5–12) construção, Fase 3 (13+) força.</p>
      <p>Máquina ocupada ou sem o aparelho? Use <b>Trocar</b> dentro do exercício: o app lembra da troca nos próximos treinos.</p></div></details>`,
  ].join('');
}
function historyCard() {
  const mm = MEMO();
  const items = [
    ...mm.sessions.filter((s) => s.completed).map((s) => ({ date: s.date, at: s.finishedAt || s.startedAt, html: (() => { const st = sessionStats(s); return `<b>${esc(sessionTitle(s))}</b><br><span class="small muted">${st.min} min · ${st.done}/${st.total} exercícios · ${st.sets} séries</span>`; })(), del: null })),
    ...mm.cardio.map((c) => ({ date: c.date, at: c.at || 0, html: `<b>${esc((C.CARDIO_KINDS.find((x) => x.id === c.kind) || {}).label || 'Cardio')}</b><br><span class="small muted">${c.minutes} min${c.km ? ` · ${fmt1(c.km)} km` : ''}${c.kcal ? ` · ~${fmt0(c.kcal)} kcal` : ''} · esforço ${c.rpe || '—'}/10</span>`, del: c.id })),
  ].sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.at - a.at)).slice(0, 10);
  if (!items.length) return `<section class="card"><span class="eyebrow">Histórico</span><p class="small muted">Seus treinos e cardios aparecem aqui. O primeiro é o mais importante.</p></section>`;
  return `<section class="card"><span class="eyebrow">Histórico</span><div>${items.map((it) => `<div class="kv"><span class="grow" style="min-width:0">${it.html}</span><span class="row" style="flex:none"><span class="small faint">${WD[L.weekday(it.date)]} ${dShort(it.date)}</span>${it.del ? `<button class="btn btn-icon btn-ghost" style="width:40px;min-height:40px" data-act="askDelCardio" data-id="${it.del}" aria-label="Apagar este cardio">${icon('x', 'ic-sm')}</button>` : ''}</span></div>`).join('')}</div></section>`;
}

/* =============== SESSÃO DE TREINO =============== */
function vSessao() {
  const s = activeSession();
  if (!s) { ui.route = 'treino'; return vTreino(); }
  const st = sessionStats(s);
  const quick = s.type === 'R' || s.type === 'H';
  const q = s.type === 'R' ? C.QUICK : s.type === 'H' ? C.QUICK_HOME : null;
  return `<div class="sess-top"><div class="between">
      <button class="back" data-act="sessLeave">${icon('chevL')}Sair</button>
      <div class="center"><div class="eyebrow">${esc(sessionTitle(s))}${quick ? '' : ` · F${s.phase} · S${s.week}`}</div><div class="clock" id="sessClock">${clockText(s)}</div></div>
      <button class="btn btn-sm btn-soft" data-act="sessFinishAsk">Finalizar</button></div>
      <div class="bar thin"><i style="width:${Math.round((st.done / st.total) * 100)}%"></i></div></div>
    ${quick ? `<section class="card card-flat"><span class="eyebrow">${esc(q.subtitle)}</span><p class="small muted">Faça em circuito: um exercício de cada, ${q.rounds} voltas, ${q.rest} s de descanso entre eles. Marque cada volta como uma série.</p></section>` : ''}
    <section class="ex ${s.warmupDone ? 'done' : ''}"><div class="ex-head"><span class="ex-n">${s.warmupDone ? icon('check') : icon('walk', 'ic-sm')}</span><span class="grow"><span class="ex-title">Aquecimento</span><span class="ex-sub">${esc(quick ? q.warmup : C.WARMUP)}</span></span>
      <button class="set-done" data-act="warmup" aria-pressed="${!!s.warmupDone}" aria-label="Aquecimento feito">${icon('check')}</button></div></section>
    ${s.items.map((it, i) => exCard(it, i, quick)).join('')}
    <section class="card card-flat"><span class="eyebrow">Volta à calma</span><p class="small muted">${esc(quick ? q.cooldown : C.COOLDOWN)}</p></section>
    <button class="btn btn-go btn-block" data-act="sessFinishAsk">${icon('check')}Finalizar treino</button>
    <p class="tiny faint center">${C.STOP_SIGNS}</p>`;
}
function clockText(s) {
  const sec = Math.max(0, Math.floor((Date.now() - s.startedAt) / 1000));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), ss = sec % 60;
  return (h ? h + ':' + L.pad(m) : L.pad(m)) + ':' + L.pad(ss);
}
function exCard(it, i, quick) {
  const ex = C.EX[it.exId], open = ui.openEx === i;
  const setsDone = it.sets.filter((x) => x.done).length;
  const hasLoad = it.kind === 'reps' && (ex.inc > 0 || it.load > 0);
  const loadTxt = it.kind === 'time' ? 'isometria' : hasLoad ? (fin(it.load) && it.load > 0 ? `${fmtKg(it.load)} kg` : 'defina a carga') : 'peso do corpo';
  const head = `<button class="ex-head" data-act="exToggle" data-i="${i}" aria-expanded="${open}"><span class="ex-n">${it.done ? icon('check') : i + 1}</span>
    <span class="grow"><span class="ex-title">${esc(ex.name)}</span><span class="ex-sub">${it.sets.length} × ${esc(it.reps)} · ${it.rest} s · ${loadTxt}</span></span>
    <span class="badge ${it.done ? 'ok' : ''}">${setsDone}/${it.sets.length}</span></button>`;
  if (!open) return `<section class="ex ${it.done ? 'done' : ''}">${head}</section>`;
  const unit = it.kind === 'time' ? 's' : 'rep';
  return `<section class="ex open">${head}<div class="ex-body">
    <div class="stack-sm"><span class="badge" style="justify-self:start">${esc(ex.group)}</span><p class="small">${esc(ex.cue)}</p></div>
    ${it.suggestion ? `<div class="suggest">${icon('trend', 'ic-sm')}<span>Último treino: ${esc(it.suggestion)}</span></div>` : ''}
    ${hasLoad ? `<div class="field"><label for="load${i}">Carga (kg)</label><div class="stepper"><button data-act="exLoad" data-i="${i}" data-d="-1" aria-label="Diminuir carga">${icon('minus')}</button><input id="load${i}" type="text" inputmode="decimal" autocomplete="off" data-change="exLoadInput" data-i="${i}" value="${fin(it.load) ? decv(it.load) : ''}" placeholder="0"><button data-act="exLoad" data-i="${i}" data-d="1" aria-label="Aumentar carga">${icon('plus')}</button></div>${!(it.load > 0) ? `<p class="hint">${esc(ex.start)}</p>` : ''}</div>` : `<p class="hint">${esc(ex.start)}</p>`}
    <div class="stack-sm">${it.sets.map((st, j) => `<div class="set-row"><span class="sn">${quick ? 'Volta' : 'Série'} ${j + 1}</span>
      <div class="stepper"><button data-act="setReps" data-i="${i}" data-j="${j}" data-d="-1" aria-label="Menos">${icon('minus', 'ic-sm')}</button><span class="val">${st.reps}<small>${unit}</small></span><button data-act="setReps" data-i="${i}" data-j="${j}" data-d="1" aria-label="Mais">${icon('plus', 'ic-sm')}</button></div>
      <button class="set-done" data-act="setDone" data-i="${i}" data-j="${j}" aria-pressed="${st.done}" aria-label="Série ${j + 1} feita">${icon('check')}</button></div>`).join('')}</div>
    <div class="stack-sm"><span class="lbl">Como foi?</span><div class="diff">${C.DIFFICULTY.map((d) => `<button data-act="exDiff" data-i="${i}" data-v="${d.v}" aria-pressed="${it.difficulty === d.v}">${d.label}<small>${d.hint}</small></button>`).join('')}</div></div>
    <div class="field"><label for="note${i}">Observações</label><textarea id="note${i}" data-change="exNote" data-i="${i}" placeholder="Ex.: banco na posição 4, senti o joelho…">${esc(it.note)}</textarea></div>
    <div class="btn-row"><button class="btn btn-ghost" data-act="sheet" data-s="trocar" data-i="${i}">${icon('swap')}Trocar</button><button class="btn btn-go" data-act="exDone" data-i="${i}">${icon('check')}Concluir</button></div>
  </div></section>`;
}
function vFim() {
  const f = ui.finish;
  if (!f) { ui.route = 'home'; return vHome(); }
  const s = findSession(f.id), st = s ? sessionStats(s) : { min: 0, done: 0, total: 0, sets: 0, vol: 0 };
  const res = (f.results || []).filter((r) => r.kind === 'reps' || r.kind === 'time');
  const k = today(), total = MEMO().sessions.filter((x) => x.completed).length;
  return `<section class="ob-hero"><span class="eyebrow go">Treino concluído</span><div class="h1">${esc(s ? sessionTitle(s) : 'Treino')}<br><span class="go-text">feito.</span></div></section>
    <div class="grid3"><div class="metric"><span class="num">${st.min}</span><span class="cap">minutos</span></div><div class="metric"><span class="num">${st.sets}</span><span class="cap">séries</span></div><div class="metric"><span class="num">${st.vol ? fmt0(st.vol) : '—'}</span><span class="cap">kg de volume</span></div></div>
    ${res.length ? `<section class="card"><span class="eyebrow">Próximo treino</span><div>${res.map((r) => `<div class="kv"><span class="k">${esc(r.name)}</span><span class="v">${r.kind === 'time' ? (r.action === 'up' ? '+5 s' : r.action === 'down' ? '−5 s' : 'mantém') : r.action === 'up' ? `<span class="go-text">${fmtKg(r.to)} kg ↑</span>` : r.action === 'down' ? `${fmtKg(r.to)} kg ↓` : r.action === 'reps' ? '+2 repetições' : fin(r.from) && r.from > 0 ? `${fmtKg(r.from)} kg` : 'mantém'}</span></div>`).join('')}</div><p class="tiny faint">A carga sobe só quando você completa tudo com folga. Técnica sempre em primeiro lugar.</p></section>` : ''}
    <section class="card"><div class="between"><span class="eyebrow">Treinos realizados</span><span class="num" style="font-size:34px">${total}</span></div>${total === 1 ? '<p class="small muted">O primeiro de muitos. O mais difícil já foi.</p>' : ''}<p class="quote">${esc(phraseOf(k))}</p></section>
    <button class="btn btn-go btn-block" data-act="finishDone">Voltar ao início</button>`;
}
