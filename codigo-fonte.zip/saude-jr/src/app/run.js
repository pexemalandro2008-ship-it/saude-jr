/* ===== Saúde Jr. — corrida e caminhada (ao ar livre, orla e praia) ===== */
const GPS_OK = PWA && typeof navigator !== 'undefined' && 'geolocation' in navigator;
const BLOCK_LABEL = { r: 'Corra', w: 'Caminhe', b: 'Caminhada rápida' };
const BLOCK_BIG = { r: 'CORRA', w: 'CAMINHE', b: 'CAMINHE RÁPIDO' };
const fmtClock = (sec) => { sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return (h ? h + ':' + L.pad(m) : m) + ':' + L.pad(s); };
const fmtDur = (sec) => { const m = Math.round(sec / 60); return m >= 60 ? `${Math.floor(m / 60)} h ${L.pad(m % 60)}` : `${m} min`; };
function sessionKindLabel(s) {
  return { test: 'Teste', long: 'Longo', race: 'Prova', run: 'Corrida', runwalk: 'Trote + caminhada', walk: 'Caminhada' }[s.kind] || 'Sessão';
}
function sessionSummary(s) {
  const tot = L.blocksSeconds(s.blocks), run = L.runSeconds(s.blocks);
  if (s.targetKm) return `${String(s.targetKm).replace('.', ',')} km · cerca de ${fmtDur(tot)}${run ? ', com pausas de caminhada' : ''}`;
  return `${fmtDur(tot)}${run ? ` · ${fmtDur(run)} correndo` : ''}`;
}
function runWeekSlots(k) {
  const info = runPlanInfo(k), days = runDays(), ws = L.weekStart(k);
  const dayOf = (idx) => {
    if (!days.length) return null;
    if (days.length === 1) return idx === 2 ? days[0] : null;
    if (days.length === 2) return idx === 0 ? days[0] : idx === 2 ? days[1] : null;
    return idx === 0 ? days[0] : idx === 1 ? days[1] : days[days.length - 1];
  };
  const runs = MEMO().runs.filter((r) => r.date >= ws && r.date <= L.addDays(ws, 6));
  return info.sessions.map((s0, idx) => {
    const wd = dayOf(idx);
    const date = wd == null ? null : L.addDays(ws, (wd + 6) % 7);
    let s = s0;
    if (s.kind === 'race' && date !== info.rc.race.date) s = S_EVE;
    const done = runs.some((r) => r.idx === idx && r.week === info.w);
    return { idx, s, date, wd, done };
  });
}
function vCorrida() {
  const k = today(), info = runPlanInfo(k), rc = info.rc, locked = runLocked();
  const slots = runWeekSlots(k);
  const mm = MEMO();
  const allKm = mm.runs.reduce((a, r) => a + (r.km || 0), 0);
  const ws = L.weekStart(k);
  const wkRuns = mm.runs.filter((r) => r.date >= ws);
  const wkKm = wkRuns.reduce((a, r) => a + (r.km || 0), 0), wkMin = wkRuns.reduce((a, r) => a + (r.minutes || 0), 0);
  const longest = mm.runs.reduce((a, r) => Math.max(a, r.maxRun || 0), 0);
  const tests = mm.runs.filter((r) => r.kind === 'test' && r.km && r.minutes);
  const weeks = Array.from({ length: 8 }, (_, i) => L.addDays(ws, -7 * (7 - i)));
  const kmWeek = weeks.map((w0) => mm.runs.filter((r) => r.date >= w0 && r.date <= L.addDays(w0, 6)).reduce((a, r) => a + (r.km || 0), 0));
  const maxKm = Math.max(5, ...kmWeek), anyKm = kmWeek.some((v) => v > 0);
  const pct = Math.round(L.clamp((info.w - 1) / Math.max(1, info.N - 1), 0, 1) * 100);
  const raceDone = info.daysToRace < 0;
  const history = mm.runs.slice().reverse().slice(0, 8);
  return `
  <section class="card card-now"><div class="between"><span class="eyebrow go">Meta de corrida</span><span class="badge ok">${raceDone ? 'prova passou' : `faltam ${Math.ceil(info.daysToRace / 7)} semanas`}</span></div>
    <div class="stack-sm"><div class="h2">${esc(rc.race.name)}</div><p class="small muted">${esc(rc.race.city || '')} · ${dLong(rc.race.date)} de ${rc.race.date.slice(0, 4)}</p></div>
    <div class="bar"><i style="width:${pct}%"></i></div>
    <p class="small"><b>Semana ${info.w} de ${info.N}</b> · ${esc(info.phase.name)}. <span class="muted">${esc(info.phase.goal)}</span></p>
    ${info.short ? `<div class="note warn">${icon('info')}<span>Menos de 16 semanas até a prova: o objetivo seguro é completar os 10 km caminhando. Nas edições anteriores, a categoria caminhada tinha limite de 2h30: confira o regulamento da sua edição.</span></div>` : ''}
    <button class="link-btn" data-act="sheet" data-s="prova">Mudar prova ou data</button></section>
  ${locked ? `<section class="card card-warn"><div class="row">${icon('shield')}<b>Trotes liberados só depois do médico</b></div>
    <p class="small">No questionário de segurança você marcou ${lockReason()}. Antes de começar a trotar, passe por uma consulta médica e faça os exames que o médico pedir, como o teste ergométrico. Até lá, as sessões com trote viram caminhada rápida.</p>
    <button class="btn btn-sm" data-act="safetyCleared">Já fui avaliado e liberado</button></section>` : ''}
  ${ui.run && ui.run.active ? `<section class="card card-now"><span class="eyebrow go">Sessão em andamento</span><div class="h3">${esc(ui.run.title)}</div><button class="btn btn-go btn-block" data-act="go" data-to="corrida">${icon('play')}Voltar à sessão</button></section>`
    : ui.run && (ui.runResult || ui.run.result) ? `<section class="card card-now"><span class="eyebrow go">Sessão terminada</span><div class="h3">${esc(ui.run.title)}</div><p class="small muted">Registre como foi para contar na sua evolução.</p><div class="btn-row"><button class="btn btn-go" data-act="sheet" data-s="runLog" data-from-run="1">Registrar</button><button class="btn btn-ghost" data-act="runDiscard">Descartar</button></div></section>` : ''}
  ${runDays().length > 0 && runDays().length < 3 ? `<div class="note">${icon('info')}<div class="stack-sm"><span class="small">Com ${runDays().length === 1 ? '1 dia' : '2 dias'} de corrida por semana, você faz só parte das sessões do plano. O ideal para os 10 km são 3 dias.</span><button class="link-btn" data-act="weekSuggest">Usar semana sugerida: 3 corridas + 2 academia</button></div></div>` : ''}
  <section class="card"><div class="between"><span class="eyebrow">Esta semana</span><span class="badge">${slots.filter((x) => x.done).length}/${slots.filter((x) => x.date).length} feitas</span></div>
    <div class="stack-sm">${slots.map((x) => {
      if (!x.date) return '';
      const s = sessionToRun(x.s), isToday = x.date === k;
      return `<div class="run-slot ${x.done ? 'done' : ''} ${isToday ? 'today' : ''}">
        <div class="between"><span class="eyebrow">${WD[L.weekday(x.date)]} ${dShort(x.date)} · ${C.RUN_SESSION_NAMES[x.idx] || 'Sessão'}</span><span class="badge ${x.done ? 'ok' : ''}">${x.done ? icon('check', 'ic-sm') + 'feita' : sessionKindLabel(s)}</span></div>
        <div class="h3">${esc(s.title)}</div>
        <p class="small muted">${esc(sessionSummary(s))}${s.place ? ` · ${s.place === 'praia' ? 'praia, areia firme' : s.place === 'orla' ? 'orla' : esc(s.place)}` : ''}</p>
        ${s.note ? `<p class="tiny faint">${esc(s.note)}</p>` : ''}
        ${x.done ? '' : `<button class="btn ${isToday ? 'btn-go' : 'btn-ghost'} btn-block ${isToday ? '' : 'btn-sm'}" data-act="runStart" data-idx="${x.idx}">${icon('play')}${isToday ? 'Começar sessão' : 'Fazer agora'}</button>`}</div>`;
    }).join('')}</div>
    ${!runDays().length ? `<p class="small muted">Nenhum dia de corrida na sua semana. Defina em Agenda e semana.</p><button class="btn btn-soft btn-sm" data-act="go" data-to="agenda">Ajustar semana</button>` : ''}</section>
  <section class="card"><span class="eyebrow">Sessão livre</span>
    <div class="btn-row"><button class="btn btn-soft" data-act="runFree" data-t="w">${icon('walk')}Caminhada</button><button class="btn btn-soft" data-act="runFree" data-t="r">${icon('bolt')}Corrida</button></div>
    <button class="btn btn-ghost btn-block btn-sm" data-act="sheet" data-s="runLog" data-manual="1">${icon('plus', 'ic-sm')}Registrar treino já feito (relógio, Strava…)</button>
    ${GPS_OK ? '<p class="tiny faint">No app instalado, a distância é medida pelo GPS com a tela ligada.</p>' : '<p class="tiny faint">Distância por GPS disponível no app instalado. Aqui, registre a distância do relógio ou do app do celular.</p>'}</section>
  <section class="card"><span class="eyebrow">Sua evolução na corrida</span>
    <div class="grid3">${metric('Total', fmt1(allKm), 'km')}${metric('Semana', fmt1(wkKm), 'km', `${wkMin} min`)}${metric('Maior trote', longest ? Math.round(longest / 60) : '—', 'min', 'sem parar')}</div>
    ${anyKm ? `<div class="minibars" style="grid-template-columns:repeat(8,minmax(0,1fr))" aria-hidden="true">${kmWeek.map((v) => `<div class="b ${v > 0 ? 'on' : ''}" style="height:${v > 0 ? Math.max(8, Math.round((v / maxKm) * 100)) : 4}%"></div>`).join('')}</div>
    <div class="minilabels" style="grid-template-columns:repeat(8,minmax(0,1fr))">${weeks.map((w0) => `<span>${dShort(w0)}</span>`).join('')}</div>
    <p class="tiny faint">Quilômetros por semana, nas últimas 8 semanas.</p>` : '<p class="tiny faint">Registre a distância das sessões para ver os quilômetros por semana.</p>'}
    ${tests.length ? `<div>${tests.slice(-4).reverse().map((t) => `<div class="kv"><span class="k">Teste ${fmt1(t.km)} km · ${dShort(t.date)}</span><span class="v">${fmtDur(t.minutes * 60)} · ${L.pace(t.minutes * 60, t.km) || '—'}/km</span></div>`).join('')}</div>` : ''}</section>
  ${history.length ? `<section class="card"><span class="eyebrow">Últimas sessões</span><div>${history.map((r) => `<div class="kv"><span class="grow" style="min-width:0"><b>${esc(r.title || 'Sessão')}</b><br><span class="small muted">${r.minutes} min${r.km ? ` · ${fmt1(r.km)} km` : ''}${r.km && r.minutes ? ` · ${L.pace(r.minutes * 60, r.km)}/km` : ''} · ${esc(placeName(r.place))} · esforço ${r.rpe || '—'}/10${r.pain >= 2 ? ' · <span class="alert-text">dor</span>' : ''}</span></span><span class="row" style="flex:none"><span class="small faint">${dShort(r.date)}</span><button class="btn btn-icon btn-ghost" style="width:40px;min-height:40px" data-act="askDelRun" data-id="${r.id}" aria-label="Apagar sessão">${icon('x', 'ic-sm')}</button></span></div>`).join('')}</div></section>` : ''}
  ${painAlert()}
  <details class="fold"><summary>Praia, orla e calor: como treinar${icon('chevR')}</summary><div class="fold-body"><ul class="clean">${C.RUN_TIPS.map(([t, s]) => `<li>${icon('check', 'ic-sm')}<span><b>${t}.</b> <span class="muted small">${s}</span></span></li>`).join('')}</ul></div></details>
  <section class="card"><span class="eyebrow">Ajustar o plano</span><p class="small muted">Não deu para cumprir a semana ou sentiu demais? Volte uma semana. Está sobrando fôlego? Avance uma. A cada mês, revise aqui.</p>
    <div class="btn-row"><button class="btn btn-ghost btn-sm" data-act="runShift" data-d="1">Voltar 1 semana</button><button class="btn btn-ghost btn-sm" data-act="runShift" data-d="-1">Avançar 1 semana</button></div></section>`;
}
const placeName = (id) => (C.RUN_PLACES.find((p) => p[0] === id) || [0, id || '—'])[1];
function lockReason() {
  const a = (prof().safety || {}).answers || {};
  return a.dizzy ? 'tontura ou desmaio nos últimos 12 meses' : a.chest ? 'dor no peito' : a.heart ? 'problema no coração ou pressão alta' : a.supervised ? 'orientação de exercício só com supervisão' : 'pontos que pedem avaliação médica';
}
function provaSheet() {
  const r = runCfg().race, def = C.RACE_DEFAULT;
  return { title: 'Prova alvo', body: `
    <div class="field"><label for="pv-name">Nome da prova</label><input id="pv-name" type="text" value="${esc(r.name)}"></div>
    <div class="grid2"><div class="field"><label for="pv-city">Cidade</label><input id="pv-city" type="text" value="${esc(r.city || '')}"></div><div class="field"><label for="pv-date">Data</label><input id="pv-date" type="date" value="${esc(r.date)}" min="${L.addDays(today(), 1)}"></div></div>
    <div class="chips"><button class="chip" data-act="provaDefault">${esc(def.name)} · ${dShort(def.date)}/${def.date.slice(0, 4)}</button></div>
    <p class="hint">Confira data, horário e regulamento no site oficial da prova. O plano se ajusta sozinho à data: com menos de 16 semanas, a meta segura é completar caminhando.</p>
    <div class="switch-row"><span><b>Recomeçar o plano nesta semana</b><br><span class="tiny faint">Use se ficou muito tempo parado.</span></span><button class="switch" role="switch" aria-checked="false" id="pv-restart" data-act="toggleSwitch" aria-label="Recomeçar o plano nesta semana"></button></div>
    <button class="btn btn-go btn-block" data-act="saveProva">Salvar prova</button>` };
}
function painAlert() {
  const recent = MEMO().runs.filter((r) => r.date >= L.addDays(today(), -7) && r.pain >= 2);
  if (!recent.length) return '';
  const strong = recent.some((r) => r.pain >= 3);
  return `<section class="card ${strong ? 'card-alert' : 'card-warn'}"><div class="row">${icon('info')}<b>${strong ? 'Dor forte: pare de correr e procure avaliação' : 'Dor nos últimos dias'}</b></div>
    <p class="small">${strong ? 'Com dor forte, não treine em cima dela. Procure um médico ou fisioterapeuta.' : 'Troque a próxima corrida por caminhada ou bicicleta e observe. Se a dor voltar ou piorar, procure um fisioterapeuta ou médico.'}</p></section>`;
}

/* ---------------- sessão ao vivo ---------------- */
function runElapsed(r) { return Math.max(0, Math.floor(((r.pausedAt || Date.now()) - r.startedAt - r.pausedTotal) / 1000)); }
function runTotal(r) { return L.blocksSeconds(r.blocks); }
function vCorridaSessao() {
  const r = ui.run;
  if (!r) { ui.route = 'treino'; ui.sub.treino = 'corrida'; return vTreino(); }
  return `<div class="sess-top"><div class="between">
      <button class="back" data-act="runExit">${icon('chevL')}Sair</button>
      <div class="center"><div class="eyebrow">${esc(r.free ? (r.freeType === 'r' ? 'Corrida livre' : 'Caminhada livre') : sessionKindLabel(r))}</div><div class="clock" id="runClock">0:00</div></div>
      <button class="btn btn-sm btn-soft" data-act="runFinishAsk">Finalizar</button></div></div>
    <section class="run-live" id="runLive">
      <div class="run-phase" id="runPhase">—</div>
      <div class="run-left" id="runLeft">0:00</div>
      <div class="small muted" id="runBlock"></div>
      <div class="bar"><i id="runProg" style="width:0%"></i></div>
      <div class="small" id="runNext"></div>
    </section>
    <div class="grid3">
      <div class="metric"><span class="num" id="runKm">${GPS_OK ? '0,00' : '—'}</span><span class="cap">km ${GPS_OK ? '(GPS)' : ''}</span></div>
      <div class="metric"><span class="num" id="runPace">—</span><span class="cap">ritmo /km</span></div>
      <div class="metric"><span class="num sm" id="runTot">—</span><span class="cap" id="runTotCap">${r.free ? 'tempo' : 'de ' + fmtDur(runTotal(r))}</span></div>
    </div>
    <p class="tiny faint center" id="runGps">${GPS_OK ? 'Procurando sinal de GPS…' : ''}</p>
    <div class="${r.free ? 'stack-sm' : 'btn-row'}"><button class="btn btn-go${r.free ? ' btn-block' : ''}" data-act="runPause" id="runPauseBtn">${r.pausedAt ? icon('play') + 'Continuar' : icon('clock') + 'Pausar'}</button>${r.free ? '' : `<button class="btn btn-ghost" data-act="runSkip">Pular bloco</button>`}</div>
    <div class="switch-row"><span>Avisos por voz</span><button class="switch" role="switch" aria-checked="${r.voice !== false}" aria-label="Avisos por voz" data-act="runVoice"></button></div>
    <section class="card card-flat"><span class="eyebrow">${esc(r.title)}</span><p class="small muted">${esc(r.note || 'Mantenha o app aberto e a tela ligada: os avisos de troca vêm por som, voz e vibração.')}</p></section>
    <p class="tiny faint center">${C.STOP_SIGNS}</p>`;
}
function runPersist() {
  try {
    if (!ui.run) return localStorage.removeItem('mv1:run');
    // guarda só a distância somada; nenhuma coordenada fica salva
    const gps = ui.run.gps ? { state: ui.run.gps.state ? { m: ui.run.gps.state.m, last: null } : null } : null;
    localStorage.setItem('mv1:run', JSON.stringify(Object.assign({}, ui.run, { gpsWatch: null, gps })));
  } catch (e) { /* sem armazenamento */ }
}
function runSpeak(text) {
  try {
    if (!ui.run || ui.run.voice === false || !('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance(text); u.lang = 'pt-BR'; u.rate = 1.05;
    window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
  } catch (e) { /* sem voz */ }
}
const minutesSpeech = (s) => (s >= 60 ? `${Math.round(s / 60)} minuto${Math.round(s / 60) === 1 ? '' : 's'}` : `${s} segundos`);
function runCue(b) {
  if (!b) return;
  beep(); if (b.t === 'r') setTimeout(beep, 350);
  vibrate(b.t === 'r' ? [300, 120, 300] : [300]);
  runSpeak(`${BLOCK_LABEL[b.t]} ${minutesSpeech(b.s)}`);
}
function runTick() {
  const r = ui.run;
  if (!r || !r.active) return;
  const el = runElapsed(r);
  let at = null, b = null, nx = null;
  if (!r.free) {
    at = L.blockAt(r.blocks, el); b = r.blocks[at.i]; nx = r.blocks[at.i + 1];
    if (!b) { runComplete(); return; }
    if (at.i !== r.lastIdx) {
      if (r.lastIdx >= 0 || at.i === 0) runCue(b);
      r.lastIdx = at.i; r.warned = false; r.half = false;
      runPersist();
    }
    if (!r.pausedAt) {
      if (nx && nx.t === 'r' && b.t !== 'r' && at.left <= 10 && !r.warned) { r.warned = true; runSpeak('Prepare-se para correr'); }
      if (b.s >= 600 && !r.half && at.left <= b.s / 2 && at.left > 30) { r.half = true; runSpeak(`Metade do bloco. Faltam ${minutesSpeech(Math.round(at.left / 60) * 60)}`); }
    }
  } else if (!r.pausedAt) {
    const m5 = Math.floor(el / 300);
    if (m5 > (r.lastCue || 0)) { r.lastCue = m5; const kmNow = r.gps && r.gps.state ? r.gps.state.m / 1000 : 0; runSpeak(`${m5 * 5} minutos${kmNow >= 0.1 ? ', ' + kmNow.toFixed(1).replace('.', ',') + ' quilômetros' : ''}`); }
  }
  const km = r.gps && r.gps.state ? r.gps.state.m / 1000 : 0;
  if (r.targetKm && km >= r.targetKm && !r.kmDone) { r.kmDone = true; runSpeak(`Você completou ${String(r.targetKm).replace('.', ',')} quilômetros`); beep(); }
  if (Date.now() - (r.savedAt || 0) > 5000) { r.savedAt = Date.now(); runPersist(); }
  const $ = (id) => document.getElementById(id);
  if (ui.route !== 'corrida' || !$('runLive')) return;
  $('runClock').textContent = fmtClock(el);
  if (r.free) {
    $('runPhase').textContent = r.freeType === 'r' ? 'CORRENDO' : 'CAMINHANDO';
    $('runPhase').className = 'run-phase ' + (r.freeType === 'r' ? 'is-run' : 'is-walk');
    $('runLeft').textContent = fmtClock(el);
    $('runBlock').textContent = r.pausedAt ? 'Pausado' : 'Tempo em movimento';
    $('runNext').textContent = '';
    $('runTot').textContent = fmtDur(el);
  } else {
    $('runPhase').textContent = r.pausedAt ? 'PAUSADO' : BLOCK_BIG[b.t];
    $('runPhase').className = 'run-phase ' + (r.pausedAt ? 'is-paused' : b.t === 'r' ? 'is-run' : b.t === 'b' ? 'is-brisk' : 'is-walk');
    $('runLeft').textContent = fmtClock(at.left);
    $('runBlock').textContent = `Bloco ${at.i + 1} de ${r.blocks.length}${b.label ? ' · ' + b.label : ''} · ${BLOCK_LABEL[b.t].toLowerCase()}`;
    $('runProg').style.width = Math.round((el / runTotal(r)) * 100) + '%';
    $('runNext').textContent = nx ? `Depois: ${BLOCK_LABEL[nx.t].toLowerCase()} ${C.fmtMin(nx.s / 60)}` : 'Último bloco';
    $('runTot').textContent = fmtDur(el);
  }
  if (GPS_OK) {
    $('runKm').textContent = km.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    $('runPace').textContent = L.pace(el, km) || '—';
    const acc = r.gps && r.gps.acc;
    $('runGps').textContent = r.gps && r.gps.err ? 'GPS indisponível: registre a distância no fim.' : acc ? `GPS: precisão de ${Math.round(acc)} m${acc > 30 ? ' (aguardando sinal melhor)' : ''}` : 'Procurando sinal de GPS…';
  }
}
function gpsStart() {
  const r = ui.run; if (!GPS_OK || !r) return;
  r.gps = r.gps || { state: null };
  try {
    r.gpsWatch = navigator.geolocation.watchPosition((pos) => {
      if (!ui.run || ui.run.pausedAt) return;
      ui.run.gps.acc = pos.coords.accuracy; ui.run.gps.err = null;
      ui.run.gps.state = L.gpsAccumulate(ui.run.gps.state, { lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy, ts: pos.timestamp });
    }, (err) => { if (ui.run) { ui.run.gps.err = err.code || 1; } }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 30000 });
  } catch (e) { r.gps.err = 1; }
}
function gpsStop() { const r = ui.run; if (r && r.gpsWatch != null) { try { navigator.geolocation.clearWatch(r.gpsWatch); } catch (e) { /* ok */ } r.gpsWatch = null; } }
function runBegin(cfg) {
  ui.run = Object.assign({ active: true, startedAt: Date.now(), pausedAt: null, pausedTotal: 0, lastIdx: -1, voice: true, gps: { state: null } }, cfg);
  unlockAudio(); suspendAlert();
  ui.route = 'corrida'; closeSheet(); render(); wakeLock(true); gpsStart(); runPersist();
  if (cfg.free) runSpeak(cfg.freeType === 'r' ? 'Corrida livre iniciada' : 'Caminhada livre iniciada');
}
function runComplete() {
  const r = ui.run; if (!r || r.completing) return;
  r.completing = true;
  runSpeak('Sessão concluída. Muito bem.'); beep(); vibrate([200, 100, 200, 100, 400]);
  runFinishNow();
}
function runFinishNow() {
  const r = ui.run; if (!r) return;
  if (!r.pausedAt) r.pausedAt = Date.now();
  gpsStop(); wakeLock(false);
  const el = runElapsed(r);
  let runDone = 0;
  if (!r.free) { let acc = 0; for (const b of r.blocks) { const end = acc + b.s; if (b.t === 'r') runDone += Math.max(0, Math.min(el, end) - acc); acc = end; } }
  else if (r.freeType === 'r') runDone = el;
  let maxRun = 0;
  if (!r.free) { let acc = 0; for (const b of r.blocks) { if (b.t === 'r' && acc + b.s <= el) maxRun = Math.max(maxRun, b.s); acc += b.s; } }
  else if (r.freeType === 'r') maxRun = el;
  ui.runResult = r.result = { el, runDone, maxRun, km: r.gps && r.gps.state && r.gps.state.m >= 50 ? Math.round(r.gps.state.m / 10) / 100 : null };
  r.active = false;
  runPersist();
  ui.route = 'treino'; ui.sub.treino = 'corrida';
  render();
  openSheet('runLog', { fromRun: '1' });
}
function runLogSheet(d) {
  const r = d.fromRun ? ui.run : null, res = d.fromRun ? ui.runResult || (r && r.result) : null;
  if (d.fromRun && (!r || !res)) return { title: 'Sessão', body: '<p class="muted">Nenhuma sessão para registrar.</p>' };
  const minutes = res ? Math.max(1, Math.round(res.el / 60)) : '';
  const km = res && res.km ? res.km : '';
  const place = (r && r.place) || ui.lastPlace || 'praia';
  return { title: d.fromRun ? 'Como foi a sessão?' : 'Registrar treino', body: `
    ${d.fromRun ? `<div class="note go">${icon('check')}<span><b>${esc(r.title)}</b> · ${fmtDur(res.el)}${res.runDone ? ` · ${fmtDur(res.runDone)} correndo` : ''}</span></div>` : `
      <div class="field"><span class="lbl">Tipo</span><div class="chips" id="rl-type">${[['w', 'Caminhada'], ['r', 'Corrida'], ['rw', 'Corrida + caminhada']].map(([v, l], i) => `<button class="chip" data-act="pick" data-group="rl-type" data-v="${v}" aria-pressed="${i === 2}">${l}</button>`).join('')}</div></div>`}
    <div class="grid2"><div class="field"><label for="rl-min">Tempo (min)</label><input id="rl-min" type="number" inputmode="numeric" value="${minutes}"></div>
      <div class="field"><label for="rl-km">Distância (km)</label><input id="rl-km" type="text" inputmode="decimal" autocomplete="off" value="${km ? decv(km) : ''}" placeholder="${r && r.targetKm ? 'meta ' + decv(r.targetKm) : 'opcional'}"></div></div>
    <div class="field"><span class="lbl">Onde</span><div class="chips" id="rl-place">${C.RUN_PLACES.map(([v, l]) => `<button class="chip" data-act="pick" data-group="rl-place" data-v="${v}" aria-pressed="${v === place}">${l}</button>`).join('')}</div></div>
    <div class="field"><label for="rl-rpe">Esforço: <b id="rl-rpe-v">5</b>/10 · <span id="rl-rpe-t">${C.RPE(5)}</span></label><input id="rl-rpe" type="range" min="1" max="10" value="5" data-input="rlRpe"></div>
    <div class="field"><span class="lbl">Dor ou incômodo?</span><div class="scale" style="--n:4" id="rl-pain">${['Nenhuma', 'Leve', 'Moderada', 'Forte'].map((l, i) => `<button data-act="pick" data-group="rl-pain" data-v="${i}" data-then="rlPain" aria-pressed="${i === 0}" style="font-family:var(--body);font-size:13px;font-weight:700">${l}</button>`).join('')}</div></div>
    <div class="field" id="rl-area-f" hidden><span class="lbl">Onde dói?</span><div class="chips" id="rl-area">${C.PAIN_AREAS.map(([v, l]) => `<button class="chip" data-act="pick" data-group="rl-area" data-v="${v}" aria-pressed="false">${l}</button>`).join('')}</div></div>
    <button class="btn btn-go btn-block" data-act="runSave" ${d.fromRun ? 'data-from-run="1"' : ''}>Salvar</button>
    ${d.fromRun ? '<button class="link-btn" data-act="runDiscard">Descartar esta sessão</button>' : ''}` };
}
