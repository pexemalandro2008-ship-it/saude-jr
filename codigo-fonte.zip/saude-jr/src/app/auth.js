/* ===== Saúde Jr. — conta: entrar, criar conta, recuperar senha, sair ===== */
const Cloud = window.MVCloud;
const CLOUD = PWA && !!(Cloud && Cloud.configured);

const AUTH_TEXT = {
  login: ['Entrar', 'Use o e-mail e a senha da sua conta.'],
  signup: ['Criar conta', 'Leva 30 segundos. Seus dados ficam na sua conta, protegidos.'],
  forgot: ['Recuperar senha', 'Enviamos um link para o seu e-mail.'],
  newpass: ['Nova senha', 'Escolha a nova senha da sua conta.'],
  offline: ['Sem conexão', 'Não foi possível falar com o servidor agora.'],
};

function authState() { if (!ui.auth) ui.auth = { mode: 'login', email: '', name: '', error: '', info: '', busy: false, sent: false }; return ui.auth; }
function goAuth(mode, extra) {
  const a = authState();
  Object.assign(a, { mode, error: '', info: '', busy: false }, extra || {});
  ui.route = 'auth';
  closeSheet();
  render();
}
const pwField = (id, label, auto, extra) => `<div class="field"><label for="${id}">${label}</label><div class="pw"><input id="${id}" type="password" autocomplete="${auto}" ${extra || ''} data-enter="authSubmit"><button type="button" class="pw-eye" data-act="pwToggle" data-for="${id}" aria-label="Mostrar senha" aria-pressed="false">${icon('eye', 'ic-sm')}</button></div></div>`;

function vAuth() {
  const a = authState(), [title, sub] = AUTH_TEXT[a.mode] || AUTH_TEXT.login;
  const err = a.error ? `<div class="note warn" role="alert">${icon('info')}<span>${esc(a.error)}</span></div>` : '';
  const info = a.info ? `<div class="note go" role="status">${icon('check')}<span>${esc(a.info)}</span></div>` : '';
  const busy = a.busy ? 'disabled aria-busy="true"' : '';
  const head = `<section class="auth-hero"><div class="brand"><span class="brand-mark">${icon('logo')}</span>Saúde Jr.</div>
    <div class="h1">${esc(title)}</div><p class="muted">${esc(sub)}</p></section>`;
  let body = '';
  if (a.mode === 'signup') {
    body = `<section class="card">
      <div class="field"><label for="au-name">Como quer ser chamado?</label><input id="au-name" type="text" autocomplete="given-name" maxlength="40" value="${esc(a.name)}" placeholder="Seu nome" data-enter="authSubmit"></div>
      <div class="field"><label for="au-email">E-mail</label><input id="au-email" type="email" inputmode="email" autocomplete="email" autocapitalize="off" spellcheck="false" value="${esc(a.email)}" placeholder="voce@email.com" data-enter="authSubmit"></div>
      ${pwField('au-pass', 'Senha', 'new-password', 'minlength="8" maxlength="72"')}
      ${pwField('au-pass2', 'Repita a senha', 'new-password', 'minlength="8" maxlength="72"')}
      <p class="hint">Pelo menos 8 caracteres, com letras e números.</p>
      ${err}
      <button class="btn btn-go btn-block" data-act="authSignup" ${busy}>${a.busy ? 'Criando a conta…' : 'Criar conta e entrar'}</button></section>
      <button class="btn btn-ghost btn-block" data-act="authMode" data-m="login">Já tenho conta · Entrar</button>`;
  } else if (a.mode === 'forgot') {
    body = `<section class="card">
      <div class="field"><label for="au-email">E-mail da conta</label><input id="au-email" type="email" inputmode="email" autocomplete="email" autocapitalize="off" spellcheck="false" value="${esc(a.email)}" placeholder="voce@email.com" data-enter="authSubmit"></div>
      ${err}${info}
      <button class="btn ${a.sent ? 'btn-ghost' : 'btn-go'} btn-block" data-act="authForgot" ${busy}>${a.busy ? 'Enviando…' : a.sent ? 'Enviar de novo' : 'Enviar link de recuperação'}</button></section>
      <section class="card"><span class="eyebrow">Depois de receber o e-mail</span>
        <ol class="dots small"><li>Abra o e-mail <b>“Reset Your Password”</b> no celular.</li><li>Toque no link. Se ele abrir o Saúde Jr., é só criar a nova senha.</li><li>Se o link abrir uma página com erro: volte ao e-mail, <b>toque e segure</b> o link, escolha <b>Copiar endereço do link</b> e cole aqui embaixo.</li></ol>
        <div class="field"><label for="au-link">Link do e-mail</label><input id="au-link" type="url" inputmode="url" autocapitalize="off" spellcheck="false" placeholder="https://…" data-enter="authRecover"></div>
        <button class="btn btn-soft btn-block" data-act="authRecover" ${busy}>Continuar com o link</button>
        <details class="fold"><summary>Por que o e-mail não chegou? ${icon('chevR')}</summary><div class="fold-body small muted">
          <p>Veja a caixa de spam e espere até 5 minutos. O servidor de e-mail gratuito envia no máximo 2 e-mails por hora e, por regra do Supabase, só para o e-mail do administrador do app.</p>
          <p>Se você usa outro e-mail, crie a conta com o e-mail do administrador ou peça a ele para ligar um servidor de e-mail próprio (veja docs/AUTENTICACAO.md).</p></div></details></section>
      <button class="btn btn-ghost btn-block" data-act="authMode" data-m="login">Voltar para Entrar</button>`;
  } else if (a.mode === 'newpass') {
    body = `<section class="card">
      ${pwField('au-pass', 'Nova senha', 'new-password', 'minlength="8" maxlength="72"')}
      ${pwField('au-pass2', 'Repita a nova senha', 'new-password', 'minlength="8" maxlength="72"')}
      <p class="hint">Pelo menos 8 caracteres, com letras e números.</p>
      ${err}
      <button class="btn btn-go btn-block" data-act="authNewPass" ${busy}>${a.busy ? 'Salvando…' : 'Salvar nova senha'}</button></section>`;
  } else if (a.mode === 'offline') {
    const su = Cloud && Cloud.storedUser();
    body = `<section class="card"><p class="muted">Confira se o celular está com internet e tente de novo.</p>${err}
      <button class="btn btn-go btn-block" data-act="authRetry" ${busy}>${a.busy ? 'Tentando…' : 'Tentar de novo'}</button>
      ${su && a.canOffline ? `<button class="btn btn-ghost btn-block" data-act="authOffline">Continuar sem internet</button><p class="tiny faint">Seus registros ficam guardados aqui e vão para a sua conta quando a internet voltar.</p>` : ''}</section>`;
  } else {
    body = `<section class="card">
      <div class="field"><label for="au-email">E-mail</label><input id="au-email" type="email" inputmode="email" autocomplete="username" autocapitalize="off" spellcheck="false" value="${esc(a.email)}" placeholder="voce@email.com" data-enter="authSubmit"></div>
      ${pwField('au-pass', 'Senha', 'current-password', 'maxlength="72"')}
      ${err}${info}
      <button class="btn btn-go btn-block" data-act="authLogin" ${busy}>${a.busy ? 'Entrando…' : 'Entrar'}</button>
      <button class="link-btn" data-act="authMode" data-m="forgot">Esqueci a senha</button></section>
      <section class="card card-flat"><div class="between"><span class="small muted">Primeira vez aqui?</span><button class="btn btn-soft btn-sm" data-act="authMode" data-m="signup">Criar conta</button></div></section>`;
  }
  return `<div class="auth">${head}${body}
    <p class="tiny faint center">${icon('lock', 'ic-sm')} Cada conta só enxerga os próprios dados. <button class="link-btn inline" data-act="go" data-to="privacidade">Privacidade e termos</button></p></div>`;
}

const authVal = (id) => (($('#' + id) || {}).value || '');
function authRead() {
  const a = authState();
  if ($('#au-email')) a.email = authVal('au-email').trim();
  if ($('#au-name')) a.name = authVal('au-name').trim();
  // senhas ficam só na memória desta tela (para não precisar digitar de novo depois de um aviso)
  if ($('#au-pass')) a.pw1 = authVal('au-pass');
  if ($('#au-pass2')) a.pw2 = authVal('au-pass2');
  if ($('#au-link')) a.link = authVal('au-link');
  a.showPw = !!($('#au-pass') && $('#au-pass').type === 'text');
}
/** depois de desenhar a tela de conta: devolve o que já estava digitado */
function authAfterRender() {
  const a = ui.auth; if (!a) return;
  const set = (id, v, show) => { const el = document.getElementById(id); if (!el) return; if (v) el.value = v; if (show && el.type === 'password') { el.type = 'text'; const b = document.querySelector(`[data-act="pwToggle"][data-for="${id}"]`); if (b) b.setAttribute('aria-pressed', 'true'); } };
  set('au-pass', a.pw1, a.showPw); set('au-pass2', a.pw2, a.showPw); set('au-link', a.link);
}
function authClearSecrets() { const a = authState(); a.pw1 = ''; a.pw2 = ''; a.link = ''; a.showPw = false; }
function authFail(e) { const a = authState(); a.busy = false; a.error = typeof e === 'string' ? e : Cloud.message(e); render(); }
const PASS_RULE = (p) => (p.length < 8 ? 'A senha precisa ter pelo menos 8 caracteres.' : p.length > 72 ? 'A senha pode ter no máximo 72 caracteres.' : !/[a-zA-ZÀ-ÿ]/.test(p) || !/[0-9]/.test(p) ? 'Use letras e números na senha.' : null);
const EMAIL_OK = (e) => /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)*\.[a-z]{2,}$/i.test(e);

const AUTH_ACT = {
  authMode: (d) => { authRead(); authClearSecrets(); const a = authState(); goAuth(d.m, { sent: d.m === 'forgot' ? a.sent : false }); const f = $(d.m === 'signup' ? '#au-name' : d.m === 'newpass' ? '#au-pass' : '#au-email'); if (f) f.focus(); },
  pwToggle: (d, el) => {
    const inp = document.getElementById(d.for); if (!inp) return;
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    el.setAttribute('aria-pressed', String(show)); el.setAttribute('aria-label', show ? 'Esconder senha' : 'Mostrar senha');
  },
  authSubmit: () => {
    const m = authState().mode;
    const map = { login: 'authLogin', signup: 'authSignup', forgot: 'authForgot', newpass: 'authNewPass', offline: 'authRetry' };
    if (map[m]) return AUTH_ACT[map[m]]();
  },
  authLogin: async () => {
    authRead();
    const a = authState(), pass = authVal('au-pass');
    if (!EMAIL_OK(a.email)) return authFail('Confira o e-mail.');
    if (!pass) return authFail('Digite a senha.');
    a.busy = true; a.error = ''; a.info = ''; render();
    try { const s = await Cloud.signIn(a.email, pass); a.busy = false; authClearSecrets(); if (s && s.user) await startUser(s.user); }
    catch (e) { authFail(e); }
  },
  authSignup: async () => {
    authRead();
    const a = authState(), p1 = authVal('au-pass'), p2 = authVal('au-pass2');
    if (!a.name) return authFail('Diga como quer ser chamado.');
    if (!EMAIL_OK(a.email)) return authFail('Confira o e-mail.');
    const rule = PASS_RULE(p1); if (rule) return authFail(rule);
    if (p1 !== p2) return authFail('As duas senhas não são iguais.');
    a.busy = true; a.error = ''; render();
    try { const s = await Cloud.signUp({ name: a.name, email: a.email, password: p1 }); a.busy = false; authClearSecrets(); if (s && s.user) await startUser(s.user, { fresh: true }); }
    catch (e) { authFail(e); }
  },
  authForgot: async () => {
    authRead();
    const a = authState();
    if (!EMAIL_OK(a.email)) return authFail('Confira o e-mail.');
    a.busy = true; a.error = ''; a.info = ''; render();
    try { await Cloud.requestReset(a.email); a.busy = false; a.sent = true; a.info = 'Pronto. Se houver uma conta com esse e-mail, o link chega em alguns minutos.'; render(); }
    catch (e) { authFail(e); }
  },
  authRecover: async () => {
    authRead();
    const a = authState(), link = authVal('au-link');
    if (!link.trim()) return authFail('Cole o link do e-mail de recuperação.');
    a.busy = true; a.error = ''; render();
    try {
      a.recovering = true;
      const s = await Cloud.useRecovery(link);
      a.busy = false; authClearSecrets();
      if (s && s.user) await startUser(s.user);
      goAuth('newpass', { recovering: true });
    } catch (e) { a.recovering = false; authFail(e); }
  },
  authNewPass: async () => {
    authRead();
    const a = authState(), p1 = authVal('au-pass'), p2 = authVal('au-pass2');
    const rule = PASS_RULE(p1); if (rule) return authFail(rule);
    if (p1 !== p2) return authFail('As duas senhas não são iguais.');
    a.busy = true; a.error = ''; render();
    try {
      await Cloud.updatePassword(p1);
      a.busy = false; a.recovering = false; authClearSecrets();
      ui.route = ui.user && prof().onboarded ? 'home' : 'onboarding';
      if (ui.route === 'onboarding') obInit();
      render(); toast('Senha nova salva');
    } catch (e) { authFail(e); }
  },
  authRetry: async () => { const a = authState(); a.busy = true; render(); await bootCloud(true); },
  authOffline: () => {
    const su = Cloud.storedUser();
    if (!su || !Store.useCacheOffline(su.id)) return authFail('Não há dados guardados neste aparelho. Conecte-se à internet para entrar.');
    ui.user = su; ui.offlineUser = true;
    ui.route = prof().onboarded ? 'home' : 'onboarding';
    if (ui.route === 'onboarding') obInit();
    render(); toast('Sem internet: registros ficam guardados aqui');
  },

  /* conta (perfil) */
  askLogout: () => {
    const pend = Store.pending + pendingPhotoCount();
    openSheet('confirm', {
      title: 'Sair da conta?',
      text: pend ? `Há ${pend} registro${pend === 1 ? '' : 's'} ainda não enviado${pend === 1 ? '' : 's'} para a sua conta. Conecte-se à internet antes de sair, ou eles ficam só neste aparelho até você entrar de novo.` : 'Seus dados continuam guardados na sua conta. Para voltar, é só entrar com e-mail e senha.',
      ok: 'doLogout', okLabel: 'Sair', danger: !!pend,
    });
  },
  doLogout: async () => {
    closeSheet();
    toast('Saindo…');
    const synced = await Promise.race([Store.sync(), new Promise((r) => setTimeout(() => r(false), 6000))]);
    const wipe = synced && !pendingPhotoCount();
    await clearPhotoCache();
    try { localStorage.removeItem('mv1:run'); } catch (e) { /* ok */ }
    Store.close({ wipe });
    await Cloud.signOut();
    ui.user = null; ui.userStarted = null;
    try { location.replace(location.pathname); } catch (e) { goAuth('login'); }
  },
  changePass: () => openSheet('senha'),
  savePass: async () => {
    const p1 = ($('#np-1') || {}).value || '', p2 = ($('#np-2') || {}).value || '';
    const rule = PASS_RULE(p1); if (rule) return toast(rule);
    if (p1 !== p2) return toast('As duas senhas não são iguais');
    const b = $('#np-save'); if (b) { b.disabled = true; b.textContent = 'Salvando…'; }
    try { await Cloud.updatePassword(p1); closeSheet(); toast('Senha alterada'); }
    catch (e) { if (b) { b.disabled = false; b.textContent = 'Salvar nova senha'; } toast(Cloud.message(e)); }
  },
};

/* ---------------- início com conta ---------------- */
async function startUser(user, opts) {
  if (!user || !user.id) return;
  const meta = user.user_metadata || {};
  ui.user = { id: user.id, email: user.email || '', name: meta.name || '' };
  ui.offlineUser = false;
  if (ui.userStarted === user.id && ui.startP) {
    await ui.startP;
    if (ui.auth && ui.auth.recovering) { ui.route = 'auth'; ui.auth.mode = 'newpass'; safeRender(); } else afterStart();
    return;
  }
  ui.userStarted = user.id;
  ui.startP = (async () => {
    if (Store.mode !== 'boot' && Store.mode !== 'cached') Store.close({ wipe: false });
    ui.photoStore = Cloud.photos(user.id);
    if (!Store.ids().length) Store.hydrateFromCache(user.id);
    await Store.init({ uid: user.id, backend: Cloud.db(user.id) });
    cleanupStale();
  })();
  await ui.startP;
  if (opts && opts.fresh) toast('Conta criada');
  if (ui.auth && ui.auth.recovering) { ui.route = 'auth'; ui.auth.mode = 'newpass'; render(); return; }
  afterStart();
  uploadPendingPhotos();
}
function afterStart() {
  if (!prof().onboarded) { if (ui.route !== 'onboarding') { obInit(); ui.route = 'onboarding'; } }
  else if (['splash', 'auth', 'onboarding'].includes(ui.route)) { ui.route = (ui.run && ui.run.active) ? 'corrida' : 'home'; applyDeepLink(); }
  safeRender();
  tickReminders();
}

/** abre o app publicado: sessão salva → dados; sem sessão → tela de entrar */
async function bootCloud(retry) {
  const su = Cloud.storedUser();
  if (!retry) {
    // voltou pelo link do e-mail de recuperação?
    const hash = location.hash || '';
    const recovering = /[#&]type=recovery/.test(hash);
    if (recovering) { const a = authState(); a.recovering = true; a.mode = 'newpass'; }
    else if (/[#&](error_code|error_description)=/.test(hash)) {
      goAuthLater = { mode: 'forgot', error: /otp_expired|expired/i.test(hash) ? 'O link expirou ou já foi usado. Peça um novo.' : 'Não foi possível usar esse link. Peça um novo.' };
      try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* ok */ }
    }
    const had = su && !recovering ? Store.hydrateFromCache(su.id) : false;
    if (su && !recovering) ui.user = su;
    ui.route = recovering ? 'splash' : su && had && prof().onboarded ? ((ui.run && ui.run.active) ? 'corrida' : 'home') : su ? 'splash' : 'auth';
    if (ui.route === 'home') applyDeepLink();
    if (goAuthLater && ui.route === 'auth') { Object.assign(authState(), goAuthLater); goAuthLater = null; }
    render();
  }
  try { await Cloud.connect(); }
  catch (e) {
    const canOffline = !!(su && Store.useCacheOffline(su.id));
    if (canOffline && !retry) { ui.offlineUser = true; ui.route = prof().onboarded ? ui.route === 'splash' ? 'home' : ui.route : 'onboarding'; if (ui.route === 'onboarding') obInit(); render(); return; }
    return goAuth('offline', { canOffline, error: Cloud.message(e) });
  }
  if (!ui.authSub) {
    const sub = Cloud.onChange((event, session) => setTimeout(() => onAuthEvent(event, session), 0));
    ui.authSub = sub || true;
  }
  let session = null, err = null;
  try { session = await Cloud.session(); } catch (e) { err = e; }
  if (session && session.user) return startUser(session.user);
  if (err && su && Store.useCacheOffline(su.id)) { ui.offlineUser = true; if (ui.route === 'splash') ui.route = prof().onboarded ? 'home' : 'onboarding'; render(); return; }
  if (ui.auth && ui.auth.recovering) { ui.auth.recovering = false; ui.user = null; return goAuth('forgot', { error: 'O link expirou ou já foi usado. Peça um novo.' }); }
  ui.user = null;
  if (su) Store.close({ wipe: false }); // sessão expirada: nada de mostrar dados sem entrar de novo
  const a = authState(), extra = goAuthLater || {};
  goAuthLater = null;
  goAuth(extra.mode || (a.mode === 'offline' || a.mode === 'newpass' ? 'login' : a.mode || 'login'), extra);
}
let goAuthLater = null;

function onAuthEvent(event, session) {
  if (event === 'PASSWORD_RECOVERY') {
    const a = authState(); a.recovering = true;
    if (session && session.user) startUser(session.user).then(() => goAuth('newpass', { recovering: true }));
    else goAuth('newpass', { recovering: true });
    return;
  }
  if (event === 'SIGNED_IN' && session && session.user) { if (ui.userStarted !== session.user.id) startUser(session.user); return; }
  if (event === 'SIGNED_OUT') {
    if (ui.userStarted) {
      Store.close({ wipe: false });
      ui.user = null; ui.userStarted = null;
      goAuth('login', { info: 'Sua sessão terminou. Entre de novo para continuar.' });
    }
  }
  if (event === 'USER_UPDATED' && session && session.user && ui.user) ui.user.email = session.user.email || ui.user.email;
}

/** rotas que exigem conta no app publicado */
const AUTH_FREE = new Set(['auth', 'splash', 'privacidade']);
function guardRoute() {
  if (!CLOUD) return;
  if (!ui.user && !AUTH_FREE.has(ui.route)) ui.route = 'auth';
}
