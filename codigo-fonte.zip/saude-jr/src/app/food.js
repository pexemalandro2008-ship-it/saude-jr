/* ===== Saúde Jr. — 6 refeições por dia e suplementos ===== */
function foodPills(mn) {
  return `${mn.fr ? '<span class="pill fr">Fruta</span>' : ''}${mn.f ? '<span class="pill fb">Fibra</span>' : ''}${mn.p ? '<span class="pill pt">Proteína</span>' : ''}`;
}
function dayFoodStats(k) {
  const d = MEMO().days[k] || {}, menu = menuFor(k), meals = d.meals || {}, g = d.gut || {};
  const fol = (id) => meals[id] === 'ok' || meals[id] === 'troca';
  const ids = C.MEALS6.map((m) => m.id);
  const done = ids.filter(fol).length;
  const fruits = ids.filter((id) => fol(id) && menu[id].fr).length + (g.fruits || 0);
  const fiber = ids.filter((id) => fol(id) && menu[id].f).length + (g.fiber || 0);
  const prot = ['cafe', 'almoco', 'lanche2', 'jantar'].filter((id) => fol(id) && menu[id].p).length;
  return { done, fruits, fiber, prot, fled: ids.filter((id) => meals[id] === 'fora').length };
}
function vRefeicoes(k) {
  const d = MEMO().days[k] || {}, menu = menuFor(k), mt = mealTimesAll(), p = prof(), [lo, hi] = proteinRange();
  const st = dayFoodStats(k);
  const nowM = mealNow(nowMin()), nextM = nowM || currentMeal(nowMin());
  return `<section class="card"><div class="between"><span class="eyebrow">Hoje · 6 refeições</span><span class="badge ${st.done >= 5 ? 'ok' : ''}">${st.done}/6 no plano</span></div>
      <div class="grid3">${metric('Refeições', st.done, '/6')}${metric('Frutas', Math.min(st.fruits, 9), '/3')}${metric('Com fibra', Math.min(st.fiber, 9), '/4')}</div>
      <p class="small muted">${C.FIBER_FRUIT_RULE}</p>
      <button class="btn btn-ghost btn-block btn-sm" data-act="sheet" data-s="horarios">${icon('clock', 'ic-sm')}Horários e avisos das refeições</button></section>
    ${C.MEALS6.map((m) => {
      const mn = menu[m.id], cur = (d.meals || {})[m.id], isNext = nextM && nextM.id === m.id;
      return `<section class="card tight ${isNext ? 'meal-next' : ''}" id="meal-${m.id}"><div class="between"><div class="row"><span class="meal-time">${esc(mt[m.id])}</span><div class="h3">${esc(m.label)}</div></div>${isNext ? `<span class="badge ok">${nowM ? 'agora' : 'próxima'}</span>` : m.when ? `<span class="badge">${esc(m.when)}</span>` : ''}</div>
        <p class="small">${esc(adaptFood(mn.t))}</p>
        <div class="row wrap" style="gap:6px">${foodPills(mn)}</div>
        ${m.id === 'jantar' && !d.dinner ? `<button class="link-btn" data-act="seg" data-group="comida" data-v="marmita">Escolher a marmita de hoje</button>` : ''}
        ${mealButtons(k, m.id, cur)}</section>`;
    }).join('')}
    <section class="card"><span class="eyebrow">Proteína do dia</span><div class="row" style="align-items:baseline"><span class="num" style="font-size:46px">${lo}–${hi}</span><span class="muted">g por dia</span></div>
      <p class="small muted">Referência de 1,2 a 1,6 g por kg do peso-meta (${fmtKg(p.goalWeight)} kg), dividida nas refeições. Confirme com um nutricionista.</p></section>
    <section class="card"><span class="eyebrow">Regras do prato</span><ul class="clean">${C.FOOD_RULES.map(([t, s]) => `<li>${icon('check', 'ic-sm')}<span><b>${t}.</b> <span class="muted">${s}</span></span></li>`).join('')}</ul></section>
    <details class="fold"><summary>Substituições baratas${icon('chevR')}</summary><div class="fold-body">
      ${C.SWAPS.map((s) => `<div class="stack-sm"><div class="between"><b>${s.title}</b><span class="tiny faint">${s.note}</span></div><div class="tbl-wrap"><table class="tbl"><tbody>${s.rows.filter(([a]) => !(p.prefs.noRedMeat && /carne|fígado/i.test(a))).map(([a, b]) => `<tr><td>${esc(adaptFood(a))}</td><td class="r">${esc(b)}</td></tr>`).join('')}</tbody></table></div></div>`).join('')}
      <p class="tiny faint">${C.SWAPS_SOURCE}</p></div></details>
    ${p.prefs.notes ? `<div class="note">${icon('info')}<span>Suas preferências: ${esc(p.prefs.notes)}</span></div>` : ''}
    <p class="tiny faint">Cardápio educativo que muda a cada dia da semana, sem contagem de calorias e sem restrição extrema. Um nutricionista pode ajustar as quantidades para você.</p>`;
}
function refeicaoSheet(d) {
  const k = today(), id = d.m, m = C.MEALS6.find((x) => x.id === id);
  if (!m) return { title: 'Refeição', body: '' };
  const mn = menuFor(k)[id], cur = ((MEMO().days[k] || {}).meals || {})[id];
  return { title: `${m.label} · ${mealTimeOf(id)}`, body: `<p>${esc(adaptFood(mn.t))}</p><div class="row wrap" style="gap:6px">${foodPills(mn)}</div>
    ${mealButtons(k, id, cur)}
    <p class="tiny faint">Troquei = comi algo equivalente (veja as substituições baratas em Comida).</p>` };
}
function horariosSheet() {
  const mt = mealTimesAll(), p = prof();
  return { title: 'Horários das refeições', body: `
    <p class="small muted">Calculados a partir do seu dia: acorda ${esc(p.wakeTime)}, treina ${esc(p.trainTime)}, dorme ${esc(p.bedTime)}. Ajuste se precisar.</p>
    <div class="grid2">${C.MEALS6.map((m) => `<div class="field"><label for="mt-${m.id}">${m.label}</label><input id="mt-${m.id}" type="time" value="${esc(mt[m.id])}"></div>`).join('')}</div>
    <div class="switch-row"><span><b>Avisos na hora de cada refeição</b><br><span class="tiny faint">Aparecem com o app aberto. Para receber com o celular bloqueado, veja Lembretes.</span></span><button class="switch" role="switch" aria-checked="${!!p.reminders.meals}" aria-label="Avisos das refeições" data-act="remToggle" data-f="meals"></button></div>
    <button class="btn btn-go btn-block" data-act="saveMealTimes">Salvar horários</button>
    <button class="link-btn" data-act="resetMealTimes">Voltar aos horários sugeridos</button>` };
}

/* ---------------- suplementos ---------------- */
function suppWhen(s) { return s.meal ? `${mealLabel(s.meal)} (${suppTime(s)})` : suppTime(s); }
function suppDaysText(s) { return !s.days || !s.days.length || s.days.length === 7 ? 'todos os dias' : [1, 2, 3, 4, 5, 6, 0].filter((d) => s.days.includes(d)).map((d) => WD[d].toLowerCase()).join(', '); }
function vSuplementos(k) {
  const all = suppList(), todayList = suppsOn(k).slice().sort((a, b) => L.minutesOf(suppTime(a)) - L.minutesOf(suppTime(b)));
  const days7 = [0, 1, 2, 3, 4, 5, 6].map((i) => L.addDays(k, i - 6));
  let due = 0, took = 0;
  for (const dk of days7) for (const s of suppsOn(dk)) { if (s.created && dk < s.created) continue; due++; if ((((MEMO().days[dk] || {}).supps) || {})[s.id]) took++; }
  const adh = due ? Math.round((took / due) * 100) : null;
  return `<div class="note warn">${icon('shield')}<span>${C.SUPP_NOTE}</span></div>
    <section class="card"><div class="between"><span class="eyebrow">Hoje</span>${adh != null ? `<span class="badge ${adh >= 80 ? 'ok' : ''}">${adh}% nos últimos 7 dias</span>` : ''}</div>
      ${todayList.length ? `<div class="stack-sm">${todayList.map((s) => { const on = suppTaken(k, s.id); return `<button class="check" data-act="suppTake" data-id="${s.id}" aria-pressed="${on}"><span class="box">${icon('check')}</span><span class="grow"><b>${esc(s.name)}</b><br><span class="small muted">${esc(s.dose || '')} · ${esc(suppWhen(s))}</span></span></button>`; }).join('')}</div>` : '<p class="small muted">Nenhum suplemento para hoje.</p>'}</section>
    ${all.length ? `<section class="card"><span class="eyebrow">Meus suplementos</span><div>${all.map((s) => {
      const left = L.suppDaysLeft(s);
      return `<div class="kv"><span class="grow" style="min-width:0"><b>${esc(s.name)}</b><br><span class="small muted">${esc(s.dose || '')} · ${esc(suppWhen(s))} · ${esc(suppDaysText(s))}${s.by ? ` · indicado por ${esc(s.by)}` : ''}</span>${left != null ? `<br><span class="small ${left <= 7 ? 'warn-text' : 'muted'}">Estoque: ${fmt0(Number(s.stock))} ${esc(s.unit || 'doses')} · ${left <= 7 ? `acaba em ${left} dia${left === 1 ? '' : 's'}` : `dura ~${left} dias`}</span>` : ''}</span>
        <button class="btn btn-icon btn-ghost" style="width:44px;min-height:44px" data-act="sheet" data-s="supp" data-id="${s.id}" aria-label="Editar ${esc(s.name)}">${icon('edit', 'ic-sm')}</button></div>`;
    }).join('')}</div></section>` : ''}
    <button class="btn btn-soft btn-block" data-act="sheet" data-s="supp">${icon('plus')}Adicionar suplemento</button>
    <p class="tiny faint">Os suplementos entram na agenda do dia e nos lembretes, no horário escolhido.</p>`;
}
function suppSheet(d) {
  const s = d.id ? suppList().find((x) => x.id === d.id) : null, v = s || { days: [0, 1, 2, 3, 4, 5, 6], perDose: 1, meal: 'cafe' };
  const whenOpts = [...C.MEALS6.map((m) => [m.id, `Com ${m.label.toLowerCase()}`]), ['hora', 'Em um horário fixo']];
  const when = v.meal || 'hora';
  return { title: s ? 'Editar suplemento' : 'Novo suplemento', body: `
    ${s ? '' : `<div class="field"><span class="lbl">Atalhos</span><div class="chips">${C.SUPP_TEMPLATES.map((t, i) => `<button class="chip" data-act="suppTpl" data-i="${i}">${esc(t.name)}</button>`).join('')}</div><span class="hint">Só atalhos de cadastro. Registre o que foi indicado para você.</span></div>`}
    <div class="field"><label for="sp-name">Nome</label><input id="sp-name" type="text" value="${esc(v.name || '')}" placeholder="Ex.: Vitamina D"></div>
    <div class="field"><label for="sp-dose">Dose</label><input id="sp-dose" type="text" value="${esc(v.dose || '')}" placeholder="Ex.: 1 cápsula, 5 g"></div>
    <div class="field"><label for="sp-when">Quando</label><select id="sp-when" data-input="spWhen">${whenOpts.map(([id, l]) => `<option value="${id}" ${when === id ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="field" id="sp-time-f" ${when === 'hora' ? '' : 'hidden'}><label for="sp-time">Horário</label><input id="sp-time" type="time" value="${esc(v.time || '08:00')}"></div>
    <div class="field"><span class="lbl">Dias</span><div class="days" id="sp-days">${[1, 2, 3, 4, 5, 6, 0].map((w) => `<button class="chip" data-act="toggleChip" data-w="${w}" aria-pressed="${(v.days && v.days.length ? v.days : [0, 1, 2, 3, 4, 5, 6]).includes(w)}" aria-label="${WD_LONG[w]}">${WD[w]}</button>`).join('')}</div></div>
    <div class="grid2"><div class="field"><label for="sp-stock">Estoque</label><input id="sp-stock" type="number" inputmode="numeric" value="${v.stock != null ? esc(v.stock) : ''}" placeholder="opcional"></div>
      <div class="field"><label for="sp-unit">Unidade</label><input id="sp-unit" type="text" value="${esc(v.unit || 'doses')}"></div></div>
    <div class="field"><label for="sp-per">Quanto sai por dose (na unidade acima)</label><input id="sp-per" type="text" inputmode="decimal" autocomplete="off" value="${decv(v.perDose || 1)}"></div>
    <div class="field"><label for="sp-by">Indicado por</label><select id="sp-by">${[['', '—'], ['Nutricionista', 'Nutricionista'], ['Médico', 'Médico'], ['Outro', 'Outro']].map(([o, l]) => `<option value="${o}" ${(v.by || '') === o ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div class="field"><label for="sp-notes">Observações</label><textarea id="sp-notes" placeholder="Ex.: tomar com água, evitar à noite">${esc(v.notes || '')}</textarea></div>
    <button class="btn btn-go btn-block" data-act="saveSupp" data-id="${esc(v.id || '')}">Salvar</button>
    ${s ? `<button class="btn btn-danger btn-block btn-sm" data-act="askDelSupp" data-id="${s.id}">${icon('trash', 'ic-sm')}Excluir</button>` : ''}` };
}
