/* ===== Saúde Jr. — fotos diárias, linha do tempo e fotos da meta =====
 * Onde a foto fica:
 *   src 'sb'    → app publicado: arquivo no bucket privado do Supabase (pasta do usuário) + cópia neste aparelho
 *   src 'local' → só neste aparelho (IndexedDB)
 *   src 'cloud' → versão dentro do Claude (arquivos da conta)
 *   src 'embed' → imagem-meta que veio com a versão privada
 */
const POSE_LABEL = { frente: 'Frente', lado: 'Lado', costas: 'Costas' };
const monthName = (mk) => { const [y, m] = mk.split('-').map(Number); return `${MONTHS_LONG[m - 1]} de ${y}`; };
function photoImg(ph, alt, cls) {
  if (!ph) return '';
  const c = cls ? ` class="${cls}"` : '';
  if (ph.src === 'local' || ph.src === 'sb') {
    const u = Photos && Photos.cached(ph.id);
    return `<img${c} data-local="${esc(ph.id)}"${ph.src === 'sb' && ph.path ? ` data-sb="${esc(ph.path)}"` : ''} ${u ? `src="${u}"` : ''} alt="${esc(alt || '')}">`;
  }
  if (ph.src === 'embed') return `<img${c} src="${ph.id === 'embed:start' ? IMG.before : IMG.after}" alt="${esc(alt || '')}">`;
  return `<img${c} src="/_blob/${esc(ph.id)}" alt="${esc(alt || '')}" loading="lazy">`;
}
/** URL de uma foto guardada: cópia deste aparelho ou, se faltar, baixa da conta (e guarda) */
const photoFetches = new Map();
async function photoUrl(ph) {
  if (!ph) return null;
  if (ph.src === 'embed') return ph.id === 'embed:start' ? IMG.before : IMG.after;
  if (ph.src === 'cloud' || !ph.src) return '/_blob/' + ph.id;
  if (!Photos || !Photos.available) return null;
  try { const u = await Photos.url(ph.id); if (u) return u; } catch (e) { /* segue */ }
  if (ph.src !== 'sb' || !ph.path || ph.pending || !ui.photoStore) return null;
  if (!photoFetches.has(ph.id)) {
    photoFetches.set(ph.id, (async () => {
      const blob = await ui.photoStore.download(ph.path);
      await Photos.put(ph.id, blob);
      return Photos.url(ph.id);
    })().finally(() => setTimeout(() => photoFetches.delete(ph.id), 1000)));
  }
  try { return await photoFetches.get(ph.id); } catch (e) { return null; }
}
async function hydratePhotos(root) {
  if (!Photos || !Photos.available) return;
  const imgs = (root || document).querySelectorAll('img[data-local]:not([src])');
  for (const img of imgs) {
    const ph = { id: img.dataset.local, src: img.dataset.sb ? 'sb' : 'local', path: img.dataset.sb || null };
    try {
      const u = await photoUrl(ph);
      if (u) img.src = u;
      else { const box = img.closest('button, .ph, .ph3'); if (box) box.classList.add('missing'); }
    } catch (e) { /* foto indisponível agora */ }
  }
}
const frontPhotos = () => photosMeta().filter((p) => (p.pose || 'frente') === 'frente');
function photoStreakNow() { return L.photoStreak([...new Set(frontPhotos().map((p) => p.date))], today()); }
function allPhotoMetas() {
  const c = coreRead(), g = c.goalPhotos || {};
  return [...(c.photos || []), g.start, g.goal].filter(Boolean);
}
function pendingPhotoCount() { return allPhotoMetas().filter((p) => p.src === 'sb' && p.pending).length; }
function vFotos() {
  const k = today(), ph = photosMeta(), front = frontPhotos();
  const todayP = ph.filter((p) => p.date === k);
  const streak = photoStreakNow();
  const byMonth = new Map();
  ph.slice().reverse().forEach((p) => { const mk = p.date.slice(0, 7); if (!byMonth.has(mk)) byMonth.set(mk, []); byMonth.get(mk).push(p); });
  const where = CLOUD ? 'As fotos ficam privadas na sua conta: só você vê. Uma cópia fica neste aparelho para abrir rápido.'
    : PWA ? 'As fotos ficam só neste aparelho.' : ui.assets ? 'As fotos ficam privadas na sua conta.' : 'As fotos ficam neste aparelho.';
  const pend = pendingPhotoCount();
  const hasFront = todayP.some((p) => (p.pose || 'frente') === 'frente'), hasSide = todayP.some((p) => p.pose === 'lado'), hasBack = todayP.some((p) => p.pose === 'costas');
  return `<section class="card card-now"><div class="between"><span class="eyebrow go">Foto do dia</span><span class="badge ok">🔥 ${streak} dia${streak === 1 ? '' : 's'}</span></div>
      ${todayP.length ? `<div class="pair">${todayP.map((p) => `<button class="ph3" data-act="sheet" data-s="foto" data-id="${p.id}" aria-label="Ver foto de hoje">${photoImg(p)}<span class="tag"><span>${POSE_LABEL[p.pose] || 'Frente'}</span></span></button>`).join('')}</div>` : '<p class="muted">Ainda sem foto hoje. Mesmo lugar, mesma luz, antes de comer.</p>'}
      <div class="btn-row three"><button class="btn ${hasFront ? 'btn-ghost' : 'btn-go'}" data-act="photoAdd" data-pose="frente">${icon('camera', 'ic-sm')}Frente${hasFront ? ' ✓' : ''}</button><button class="btn btn-ghost" data-act="photoAdd" data-pose="lado">${icon('camera', 'ic-sm')}Lado${hasSide ? ' ✓' : ''}</button><button class="btn btn-ghost" data-act="photoAdd" data-pose="costas">${icon('camera', 'ic-sm')}Costas${hasBack ? ' ✓' : ''}</button></div>
      <p class="tiny faint">Frente todo dia. Lado e costas uma vez por semana.</p></section>
    ${front.length >= 2 ? `<div class="btn-row"><button class="btn btn-soft" data-act="sheet" data-s="timelapse">${icon('play')}Ver evolução</button><button class="btn btn-soft" data-act="sheet" data-s="compare" data-mode="photos">${icon('swap')}Comparar</button></div>` : ''}
    <section class="card"><div class="between"><span class="eyebrow">Minhas fotos</span><span class="badge">${ph.length}</span></div>
      ${ph.length ? [...byMonth.entries()].map(([mk, list]) => `<div class="stack-sm"><span class="lbl">${monthName(mk)}</span><div class="photos">${list.map((p) => `<button data-act="sheet" data-s="foto" data-id="${p.id}" aria-label="Foto de ${dShort(p.date)}">${photoImg(p)}<span class="d">${dShort(p.date)}${p.pose && p.pose !== 'frente' ? ' · ' + (POSE_LABEL[p.pose] || '').toLowerCase() : ''}</span></button>`).join('')}</div></div>`).join('') : '<p class="small muted">Sua primeira foto aparece aqui. Daqui a 3 meses, você vai agradecer.</p>'}
      ${pend ? `<p class="small warn-text">${pend} foto${pend === 1 ? '' : 's'} esperando internet para ir para a sua conta.</p>` : ''}
      <p class="tiny faint">${where}</p></section>
    <section class="card"><span class="eyebrow">Como tirar a foto</span><ul class="clean">${C.PHOTO_TIPS.map((t) => `<li>${icon('camera', 'ic-sm')}<span class="small">${t}</span></li>`).join('')}</ul></section>`;
}
/** par de fotos da meta: as do usuário, ou as que vieram com o app (só para o dono) */
function goalPair() {
  const g = coreRead().goalPhotos || {};
  if (g.start || g.goal) return { start: g.start ? Object.assign({ pose: 'inicio' }, g.start) : null, goal: g.goal ? Object.assign({ pose: 'meta' }, g.goal) : null, own: true };
  if (canShowGoalPhotos()) return { start: { id: 'embed:start', src: 'embed' }, goal: { id: 'embed:goal', src: 'embed' }, own: false };
  return null;
}
async function addPhoto(file) {
  if (!/^image\//.test(file.type || 'image/')) return toast('Escolha uma imagem');
  const pose = ui.photoPose || 'frente', k = today();
  toast('Salvando foto…');
  try {
    const blob = await compressImage(file, 1280, 0.82);
    let id = uidGen('ph'), src = null, path = null, pending = false;
    if (CLOUD && ui.photoStore) {
      // guarda a cópia local primeiro (aparece na hora e não se perde sem internet), depois envia para a conta
      if (Photos && Photos.available) await Photos.put(id, blob);
      src = 'sb'; path = ui.user.id + '/' + id + '.jpg';
      try { await ui.photoStore.upload(id, blob); }
      catch (e) { if (!(Photos && Photos.available)) throw e; pending = true; }
    } else {
      const a = !PWA ? await getCap('assets') : null;
      if (a) { try { const res = await a.upload(blob, { type: 'image/jpeg' }); id = res.id; src = 'cloud'; } catch (e) { if (e && e.code === 'too_large') throw e; } }
      if (!src) {
        if (!Photos || !Photos.available) throw { code: 'nostore' };
        await Photos.put(id, blob); src = 'local';
      }
    }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    const meta = { id, src };
    if (path) meta.path = path;
    if (pending) meta.pending = true;
    const c = CORE();
    if (pose === 'inicio' || pose === 'meta') {
      const key = pose === 'inicio' ? 'start' : 'goal', old = c.goalPhotos[key];
      c.goalPhotos[key] = meta;
      save('core'); render(); if (old) removePhotoBlob(old);
      return toast(pending ? 'Foto salva aqui. Vai para a sua conta quando a internet voltar.' : 'Foto salva');
    }
    const old = c.photos.filter((p) => p.date === k && (p.pose || 'frente') === pose);
    c.photos = c.photos.filter((p) => !(p.date === k && (p.pose || 'frente') === pose)).concat(Object.assign({ date: k, pose, at: Date.now() }, meta));
    save('core'); render();
    old.forEach(removePhotoBlob);
    const st = photoStreakNow();
    toast(pending ? 'Foto salva aqui. Vai para a sua conta quando a internet voltar.' : pose === 'lado' ? 'Foto de lado salva' : pose === 'costas' ? 'Foto de costas salva' : (st > 1 ? `Foto do dia salva · ${st} dias seguidos` : 'Foto do dia salva · sequência começou'));
  } catch (e) {
    const code = e && e.code;
    toast(code === 'too_large' ? 'Foto grande demais' : code === 'quota_or_state' ? 'Espaço de fotos cheio' : code === 'nostore' ? 'Este navegador não permite guardar fotos' : 'Não foi possível salvar a foto');
  }
}
/** envia as fotos que ficaram só no aparelho (sem internet na hora) */
let uploadingPhotos = false;
async function uploadPendingPhotos() {
  if (!CLOUD || !ui.photoStore || uploadingPhotos || Store.mode !== 'cloud') return;
  const list = allPhotoMetas().filter((p) => p.src === 'sb' && p.pending);
  if (!list.length) return;
  uploadingPhotos = true;
  let sent = 0;
  try {
    for (const ph of list) {
      const blob = await Photos.get(ph.id).catch(() => null);
      if (!blob) continue;
      try { await ui.photoStore.upload(ph.id, blob); } catch (e) { break; }
      const c = CORE();
      const upd = (p) => (p && p.id === ph.id ? Object.assign({}, p, { pending: false }) : p);
      c.photos = c.photos.map(upd);
      c.goalPhotos = { start: upd(c.goalPhotos.start) || undefined, goal: upd(c.goalPhotos.goal) || undefined };
      Object.keys(c.goalPhotos).forEach((kk) => { if (!c.goalPhotos[kk]) delete c.goalPhotos[kk]; });
      sent++;
    }
  } finally { uploadingPhotos = false; }
  if (sent) { save('core'); safeRender(); }
}
function removePhotoBlob(ph) {
  if (!ph) return;
  if (ph.src === 'local') { if (Photos) Photos.del(ph.id).catch(() => {}); }
  else if (ph.src === 'sb') {
    if (Photos) Photos.del(ph.id).catch(() => {});
    if (!ph.pending && ph.path && ui.photoStore) ui.photoStore.remove(ph.path).catch(() => {});
  } else if (ph.src !== 'embed' && ui.assets) ui.assets.delete(ph.id).catch(() => {});
}
/** ao sair da conta: apaga deste aparelho as cópias das fotos que já estão na conta */
async function clearPhotoCache() {
  if (!Photos || !Photos.available) return;
  for (const ph of allPhotoMetas()) if (ph.src === 'sb' && !ph.pending) { try { await Photos.del(ph.id); } catch (e) { /* ok */ } }
}
/* linha do tempo animada */
async function startTimelapse() {
  const list = frontPhotos();
  const urls = [];
  for (const p of list) urls.push(await photoUrl(p).catch(() => null));
  const frames = list.map((p, i) => ({ p, u: urls[i] })).filter((f) => f.u);
  if (!frames.length) return;
  const img = document.getElementById('tl-img'), lab = document.getElementById('tl-date'), rg = document.getElementById('tl-r');
  if (!img) return;
  const first = frames[0].p.date;
  ui.tl = { i: 0, frames, speed: 1, playing: true, t: null };
  const show = (i) => {
    const f = frames[i]; if (!f || !document.getElementById('tl-img')) return;
    img.src = f.u; lab.textContent = `${dShort(f.p.date)} · dia ${L.diffDays(first, f.p.date) + 1}`;
    if (rg) { rg.max = frames.length - 1; rg.value = i; }
  };
  const step = () => { if (!ui.tl) return; ui.tl.i = (ui.tl.i + 1) % frames.length; show(ui.tl.i); };
  ui.tl.show = show; ui.tl.step = step;
  show(0);
  tlSetSpeed(1);
}
function tlSetSpeed(sp) {
  if (!ui.tl) return;
  ui.tl.speed = sp;
  clearInterval(ui.tl.t);
  ui.tl.t = setInterval(() => { if (ui.tl && ui.tl.playing) ui.tl.step(); }, Math.round(420 / sp));
}
function stopTimelapse() { if (ui.tl) { clearInterval(ui.tl.t); ui.tl = null; } }
