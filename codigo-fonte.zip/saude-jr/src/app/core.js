/* ===== Saúde Jr. — núcleo do app (helpers, dados derivados, regras de tela) ===== */
const L = window.MVLogic, C = window.MVContent, Store = window.MVStore, Photos = window.MVPhotos;
const IMG = window.MVImages || {};
const PWA = (window.MV_TARGET || 'artifact') === 'pwa';

const $ = (s, r) => (r || document).querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fin = (x) => typeof x === 'number' && isFinite(x);
const fmt1 = (x) => (fin(x) ? x.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '—');
const fmt0 = (x) => (fin(x) ? Math.round(x).toLocaleString('pt-BR') : '—');
const fmtKg = (x) => (fin(x) ? (Math.abs(x - Math.round(x)) < 0.05 ? fmt0(x) : fmt1(x)) : '—');
/** valor para campo de texto decimal: vírgula brasileira */
const decv = (x) => (x == null || x === '' || !isFinite(Number(x)) ? '' : String(Number(x)).replace('.', ','));
const signed = (x, f = fmt1) => (fin(x) ? (x > 0 ? '+' : x < 0 ? '−' : '') + f(Math.abs(x)) : '—');
const MONTHS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const MONTHS_LONG = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const WD = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const WD1 = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
const WD_LONG = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const dShort = (k) => { const d = L.parse(k); return `${L.pad(d.getDate())}/${L.pad(d.getMonth() + 1)}`; };
const dLong = (k) => { const d = L.parse(k); return `${WD_LONG[d.getDay()]}, ${d.getDate()} de ${MONTHS_LONG[d.getMonth()]}`; };
const monYear = (k) => { const d = L.parse(k); return `${MONTHS[d.getMonth()]}/${d.getFullYear()}`; };
const today = () => L.key(new Date());
const nowMin = () => { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); };
const firstName = (n) => String(n || '').trim().split(/\s+/)[0] || '';
const uidGen = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

/* ---------- ícones (traço 2px, 24×24) ---------- */
const IC = {
  home: '<path d="M3.5 10.5 12 3.5l8.5 7V20a1 1 0 0 1-1 1H15v-6H9v6H4.5a1 1 0 0 1-1-1z"/>',
  dumbbell: '<path d="M6.5 6.5v11M3.5 9v6M17.5 6.5v11M20.5 9v6M6.5 12h11"/>',
  bowl: '<path d="M3 11h18c0 5.2-4 8.5-9 8.5S3 16.2 3 11z"/><path d="M8 7.5c0-1.5 1-2 1-3.5M12 7.5c0-1.5 1-2 1-3.5M16 7.5c0-1.5 1-2 1-3.5"/>',
  trend: '<path d="M3.5 17 9 11.5l4 4 7.5-7.5"/><path d="M15 8h5.5v5.5"/>',
  grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7"/>',
  chevR: '<path d="m9 6 6 6-6 6"/>',
  chevL: '<path d="m15 6-6 6 6 6"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  drop: '<path d="M12 3.5s6 6.3 6 10.7a6 6 0 0 1-12 0C6 9.8 12 3.5 12 3.5z"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  bolt: '<path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12z"/>',
  scale: '<rect x="3.5" y="4" width="17" height="16" rx="3"/><path d="M8.5 9.5a4.5 4.5 0 0 1 7 0L12 12z"/>',
  tape: '<path d="M4 18 18 4l2.5 2.5-14 14z"/><path d="m8 14 1.5 1.5M11 11l1.5 1.5M14 8l1.5 1.5"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  bell: '<path d="M6 16.5V11a6 6 0 1 1 12 0v5.5l1.5 1.5h-15z"/><path d="M10 20.5h4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
  camera: '<path d="M4 8h3l2-2.5h6L17 8h3v11H4z"/><circle cx="12" cy="13.5" r="3.5"/>',
  swap: '<path d="M7 7.5h13l-3.5-3.5M17 16.5H4l3.5 3.5"/>',
  play: '<path d="M8 5.5v13l10.5-6.5z"/>',
  walk: '<circle cx="13" cy="4.5" r="1.8"/><path d="m9 21 2.5-6.5L14 17v4M8 11l3-3.5 3.5 1 1.5 3.5 2.5 1M11.5 14.5 12 9"/>',
  leaf: '<path d="M5 19C5 11 11 5 19.5 5 19.5 13 13.5 19 5 19z"/><path d="m5 19 7.5-7.5"/>',
  pulse: '<path d="M3 12h4l2-5 4 10 2-5h6"/>',
  shield: '<path d="M12 3.5 19.5 6v6c0 4.8-3.3 7.8-7.5 8.8-4.2-1-7.5-4-7.5-8.8V6z"/><path d="m9 12 2 2 4-4"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.2"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
  download: '<path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/>',
  trash: '<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
  edit: '<path d="M4 20h4L19.5 8.5l-4-4L4 16z"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
  flame: '<path d="M12 3c.8 3.2 4.5 5.2 4.5 9.8a4.5 4.5 0 0 1-9 0c0-2.2 1-3.4 2-4.3.1 1.8.9 2.8 2 3.2-.4-3.2-.2-5.8.5-8.7z"/>',
  timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 1.5M9.5 3h5"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7a4.3 4.3 0 0 1 7.5 2.8C19.5 15.4 12 20 12 20z"/>',
  logo: '<path d="M3 13.4h3.4l1.6-3.9 2.3 6.9 1.7-4.8 1.1 1.8 4.4-4.5"/><path d="M15.2 8.9h2.6v2.6"/>',
  lock: '<rect x="5" y="11" width="14" height="9.5" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  logout: '<path d="M15 4.5h3.5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H15"/><path d="M10 16.5 5.5 12 10 7.5M5.5 12H15"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 8.5-8.5M16 7l2.5 2.5M14 9l2 2"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2.5 12h2M19.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
};
const icon = (n, cls) => `<svg class="ic ${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;

/* ---------- perfil e documentos ---------- */
const DEFAULTS = {
  name: '', sex: 'M', age: null, height: null, startWeight: null, goalWeight: null,
  goal: 'Perder peso e melhorar a saúde',
  activityLevel: '', trainPref: '',
  trainDays: [1, 3, 5], trainTime: '18:30', wakeTime: '06:30', bedTime: '22:30',
  waterGoal: 3000, stepsGoal: 6000,
  equipment: C.EQUIP.map((e) => e.id),
  prefs: { lactose: false, noRedMeat: false, notes: '' },
  reminders: { wake: true, water: true, waterEvery: 120, train: true, meals: true, sleep: true, photo: true, supps: true, weigh: true, weighDay: 1, weighTime: '07:00', checklist: true, checklistTime: '21:00' },
  mealTimes: {},
  custom: [],
  week: null,
  showGoalPhotos: true,
};
Object.assign(DEFAULTS, window.MV_DEFAULTS || {});
const P = () => Store.doc('profile');
const prof = () => {
  const p = Store.peek('profile') || {};
  return Object.assign({}, DEFAULTS, p, {
    prefs: Object.assign({}, DEFAULTS.prefs, p.prefs || {}),
    reminders: Object.assign({}, DEFAULTS.reminders, p.reminders || {}),
    mealTimes: Object.assign({}, p.mealTimes || {}),
  });
};
const CORE = () => {
  const c = Store.doc('core');
  c.choice = c.choice || {}; c.ex = c.ex || {}; c.marmitas = c.marmitas || []; c.marks = c.marks || {}; c.photos = c.photos || [];
  c.supps = c.supps || []; c.run = c.run || {}; c.monthPlans = c.monthPlans || {}; c.goalPhotos = c.goalPhotos || {};
  return c;
};
const coreRead = () => Store.peek('core') || {};
const monthId = (k) => 'm-' + L.monthKey(k);
const MON = (k) => {
  const m = Store.doc(monthId(k));
  m.days = m.days || {}; m.weights = m.weights || []; m.measures = m.measures || []; m.sessions = m.sessions || []; m.cardio = m.cardio || []; m.runs = m.runs || [];
  return m;
};
/** dia para escrita (cria se não existir) */
const dayW = (k) => { const m = MON(k); if (!m.days[k]) m.days[k] = {}; return m.days[k]; };

/* ---------- dados derivados (recalculados a cada render) ---------- */
let memo = null;
const invalidate = () => { memo = null; };
function save(...ids) { Store.touch(...ids); invalidate(); }
function MEMO() {
  if (memo) return memo;
  const ids = Store.ids().filter((id) => /^m-\d{4}-\d{2}$/.test(id)).sort();
  const weights = [], measures = [], sessions = [], cardio = [], runs = [], days = {};
  for (const id of ids) {
    const m = Store.peek(id) || {};
    if (m.weights) weights.push(...m.weights);
    if (m.measures) measures.push(...m.measures);
    if (m.sessions) sessions.push(...m.sessions);
    if (m.cardio) cardio.push(...m.cardio);
    if (m.runs) runs.push(...m.runs);
    if (m.days) Object.assign(days, m.days);
  }
  const daily = L.dailyWeights(weights);
  const trend = L.trendSeries(daily);
  sessions.sort((a, b) => (a.startedAt || 0) - (b.startedAt || 0));
  cardio.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.at || 0) - (b.at || 0)));
  measures.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.at || 0) - (b.at || 0)));
  runs.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.at || 0) - (b.at || 0)));
  memo = {
    weights: daily, trend, rate: L.weeklyRate(daily), measures, sessions, cardio, runs, days,
    trainedDates: new Set(sessions.filter((s) => s.completed).map((s) => s.date)),
    cardioDates: new Set(cardio.map((c) => c.date).concat(runs.map((r) => r.date))),
    info: {},
  };
  return memo;
}
function dayInfo(k) {
  const mm = MEMO();
  if (mm.info[k]) return mm.info[k];
  const p = prof();
  const d = mm.days[k] || {};
  const trained = mm.trainedDates.has(k), cardio = mm.cardioDates.has(k);
  const auto = L.autoChecks(d, { trained, cardio, waterGoal: p.waterGoal, stepsGoal: p.stepsGoal, menu: menuFor(k) });
  const st = L.checkState(d, auto);
  return (mm.info[k] = { d, auto, st, score: L.dayScore(st), trained, cardio });
}
const isConsistent = (k) => dayInfo(k).score >= L.CONSISTENT;
const startDate = () => prof().startDate || today();
function streakNow() { return L.streak(isConsistent, today(), startDate()); }
function streakBest() { return L.longestStreak(isConsistent, startDate(), today()); }
function activeDays() { return L.countDays(isConsistent, startDate(), today()); }
function curWeight() { const t = MEMO().trend; return t.length ? t[t.length - 1].trend : prof().startWeight; }
function lastWeigh() { const w = MEMO().weights; return w.length ? w[w.length - 1] : null; }
function waistSeries() { return MEMO().measures.filter((m) => m.waist > 0); }
function milestonesList() { const p = prof(); return L.milestones(p.startWeight, p.goalWeight); }
function phaseGoal() { const cur = curWeight(); return milestonesList().find((m) => cur > m + 0.05) || null; }
function phraseOf(k) {
  const n = C.PHRASES.length;
  const i = ((L.diffDays('2026-01-01', k) % n) + n) % n;
  return C.PHRASES[i];
}
function greeting() { const h = new Date().getHours(); return h < 5 ? 'Boa noite' : h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'; }
function proteinRange() { const g = prof().goalWeight || 90; return [Math.round((g * 1.2) / 5) * 5, Math.round((g * 1.6) / 5) * 5]; }

/* ---------- treino ---------- */
const progWeek = (k) => L.programWeek(startDate(), k || today());
const ALL_REST = { 0: 'rest', 1: 'rest', 2: 'rest', 3: 'rest', 4: 'rest', 5: 'rest', 6: 'rest' };
function weekPlan() { const p = prof(); return p.week && typeof p.week === 'object' ? Object.assign({}, ALL_REST, p.week) : L.weekPlanFromDays(p.trainDays); }
const dayPlan = (k) => weekPlan()[L.weekday(k)] || 'rest';
const isGymDay = (k) => dayPlan(k) === 'gym';
const isRunDay = (k) => dayPlan(k) === 'run';
const isTrainDay = (k) => dayPlan(k) !== 'rest';
function exAvailable(exId) {
  const eq = new Set(prof().equipment || []);
  return (C.EX[exId].eq || []).every((e) => eq.has(e));
}
function slotChoice(slot) {
  const ch = (coreRead().choice || {})[slot.id];
  if (ch && slot.options.includes(ch) && exAvailable(ch)) return ch;
  return slot.options.find(exAvailable) || slot.options[0];
}
const exRead = (exId) => ((coreRead().ex || {})[exId]) || {};
function nextType() {
  const s = MEMO().sessions.filter((x) => x.completed && (x.type === 'A' || x.type === 'B'));
  if (!s.length) return 'A';
  return s[s.length - 1].type === 'A' ? 'B' : 'A';
}
function sessionTitle(s) {
  if (s.type === 'R') return C.QUICK.title;
  if (s.type === 'H') return C.QUICK_HOME.title;
  return C.PROGRAM[s.type].title;
}
function activeSession() {
  const k = today();
  const list = MEMO().sessions;
  for (let i = list.length - 1; i >= 0; i--) if (!list[i].completed && list[i].date === k) return list[i];
  return null;
}
function findSession(id) { return MEMO().sessions.find((s) => s.id === id) || null; }
function makeItem(exId, slotId, nSets, reps, rest) {
  const ex = C.EX[exId];
  const st = exRead(exId);
  let target = L.parseRange(reps), label = reps;
  if (ex.kind === 'time') {
    const b = st.secBonus || 0;
    target = [target[0] + b, target[1] + b];
    label = `${target[0]}–${target[1]} s`;
  }
  const def = target[1];
  return {
    exId, slotId, kind: ex.kind, reps: label, target, rest, inc: ex.inc,
    load: fin(st.load) ? st.load : null,
    sets: Array.from({ length: nSets }, () => ({ done: false, reps: def })),
    difficulty: null, note: '', done: false,
    suggestion: st.last && st.last.why ? st.last.why : null,
  };
}
/** repetições (ou tempo) de um exercício conforme o papel no treino e a semana */
function repsFor(exId, role, cfg) {
  const kind = C.EX[exId].kind;
  if (role === 'core') return kind === 'time' ? cfg.core[1] : '8–12';
  return cfg[role][1];
}
function buildSession(type) {
  const k = today(), week = progWeek(k), cfg = C.weekConfig(week);
  let items = [];
  const mp = (type === 'A' || type === 'B') ? (((coreRead().monthPlans || {})[L.monthKey(k)]) || {})[type] : null;
  if (mp && mp.length) {
    items = mp.map((e) => makeItem(e.exId, e.slotId || null, Number(e.sets) || 3, e.reps || '10–12', Number(e.rest) || 60));
  } else if (type === 'A' || type === 'B') {
    items = C.PROGRAM[type].slots.map((slot) => {
      const exId = slotChoice(slot);
      return makeItem(exId, slot.id, cfg[slot.role][0], repsFor(exId, slot.role, cfg), cfg.rest[slot.role]);
    });
  } else if (type === 'R') {
    const q = C.QUICK;
    items = q.slots.map((sid) => {
      const slot = C.PROGRAM.A.slots.find((s) => s.id === sid);
      const exId = slotChoice(slot);
      return makeItem(exId, sid, q.rounds, C.EX[exId].kind === 'time' ? cfg.core[1] : q.reps, q.rest);
    });
  } else {
    const q = C.QUICK_HOME;
    items = q.exercises.map((exId) => makeItem(exId, null, q.rounds, C.EX[exId].kind === 'time' ? '20–30 s' : q.reps, q.rest));
  }
  return { id: uidGen('s'), date: k, type, week, phase: C.phaseOf(week), startedAt: Date.now(), warmupDone: false, items, completed: false };
}
function estMinutes(type, week) {
  const cfg = C.weekConfig(week);
  if (type === 'R') return 25;
  if (type === 'H') return 22;
  let sec = 0;
  const mp = (((coreRead().monthPlans || {})[L.monthKey(today())]) || {})[type];
  if (mp && mp.length) for (const e of mp) sec += (Number(e.sets) || 3) * (45 + (Number(e.rest) || 60));
  else for (const slot of C.PROGRAM[type].slots) { const [n] = cfg[slot.role]; sec += n * (45 + cfg.rest[slot.role]); }
  return Math.round(sec / 60 / 5) * 5 + 15;
}
function sessionStats(s) {
  const done = s.items.filter((i) => i.done).length;
  let sets = 0, vol = 0;
  for (const it of s.items) for (const st of it.sets) if (st.done) { sets++; if (it.kind === 'reps' && it.load > 0) vol += it.load * (st.reps || 0); }
  const min = Math.max(1, Math.round(((s.finishedAt || Date.now()) - s.startedAt) / 60000));
  return { done, total: s.items.length, sets, vol, min };
}
function finishSession(s) {
  s.completed = true;
  s.finishedAt = Date.now();
  const core = CORE();
  const results = [];
  for (const it of s.items) {
    if (!it.sets.some((x) => x.done)) continue; // exercício pulado não muda nada
    const st = core.ex[it.exId] || {};
    if (it.kind === 'reps' && it.load > 0) {
      if (!(st.first > 0)) st.first = it.load;
      st.best = Math.max(st.best || 0, it.load);
    }
    if (s.type === 'A' || s.type === 'B') {
      let r = L.progression({ kind: it.kind, inc: it.inc, load: it.load, sets: it.sets, target: it.target, difficulty: it.difficulty });
      // sem avaliação de esforço, o app não sobe carga (segurança primeiro)
      if (it.difficulty == null && (r.action === 'up' || r.action === 'reps')) r = { action: 'keep', load: Number(it.load) || 0, why: 'Sem avaliação de esforço: carga mantida. Marque “Como foi?” para o app ajustar.' };
      if (it.kind === 'time') st.secBonus = L.clamp((st.secBonus || 0) + (r.secBonus || 0), -10, 60);
      else if (fin(it.load)) st.load = r.load;
      st.last = { date: s.date, why: r.why, action: r.action };
      results.push({ name: C.EX[it.exId].name, action: r.action, why: r.why, from: it.load, to: r.load, kind: it.kind, inc: it.inc });
    } else if (fin(it.load)) st.load = it.load;
    core.ex[it.exId] = st;
  }
  save('core', monthId(s.date));
  return results;
}

/* ---------- cardio ---------- */
function weekCardio(k) {
  const ws = L.weekStart(k), we = L.addDays(ws, 6);
  const list = MEMO().cardio.filter((c) => c.date >= ws && c.date <= we);
  return { n: list.length, min: list.reduce((s, c) => s + (c.minutes || 0), 0) };
}

/* ---------- alimentação: 6 refeições ---------- */
function mealTimesAll() { const p = prof(); return Object.assign({}, L.defaultMealTimes(p.wakeTime, p.trainTime, p.bedTime), p.mealTimes || {}); }
const mealTimeOf = (id) => mealTimesAll()[id];
const mealLabel = (id) => (C.MEALS6.find((m) => m.id === id) || {}).label || '';
function mealTime(m) { return mealTimeOf(m.id) || m.time; }
function currentMeal(min) {
  const mt = mealTimesAll();
  for (const m of C.MEALS6) if (L.minutesOf(mt[m.id]) + 90 >= min) return m;
  return C.MEALS6[C.MEALS6.length - 1];
}
function mealNow(min) {
  const mt = mealTimesAll();
  for (const m of C.MEALS6) { const t = L.minutesOf(mt[m.id]); if (t != null && min >= t - 30 && min <= t + 60) return m; }
  return null;
}
function adaptFood(text) {
  const pr = prof().prefs;
  let t = text;
  if (pr.lactose) t = t.replace(/iogurte natural/g, 'iogurte natural sem lactose').replace(/ml de leite/g, 'ml de leite sem lactose').replace(/^Leite morno/, 'Leite sem lactose morno');
  if (pr.noRedMeat) t = t.replace(/Fígado acebolado/g, 'Frango acebolado').replace(/carne moída/gi, 'frango desfiado').replace(/Carne moída/g, 'Frango desfiado');
  return t;
}
function marmitaById(id) { return (coreRead().marmitas || []).find((m) => m.id === id) || null; }
/** cardápio do dia (gira pelos dias da semana); a marmita escolhida substitui o jantar */
function menuFor(k) {
  const wd = L.weekday(k), out = {};
  for (const m of C.MEALS6) out[m.id] = Object.assign({}, C.MENU[m.id][wd]);
  const d = (memo && memo.days[k]) || ((Store.peek(monthId(k)) || {}).days || {})[k] || {};
  if (d.dinner) { const mm = marmitaById(d.dinner); if (mm) out.jantar = { t: 'Marmita: ' + mm.name, f: 1, p: 1 }; }
  return out;
}

/* ---------- suplementos ---------- */
const suppList = () => coreRead().supps || [];
const suppsOn = (k) => suppList().filter((s) => !s.days || !s.days.length || s.days.includes(L.weekday(k)));
const suppTime = (s) => s.time || (s.meal ? mealTimeOf(s.meal) : '08:00');
const suppTaken = (k, id) => !!(((MEMO().days[k] || {}).supps) || {})[id];

/* ---------- corrida e caminhada ---------- */
function runCfg() { const c = coreRead().run || {}; return { start: c.start || startDate(), race: Object.assign({}, C.RACE_DEFAULT, c.race || {}), shift: c.shift || 0 }; }
function runLocked() { const s = prof().safety; return !!(s && s.flag && !s.cleared); }
function walkified(s) {
  if (!s || !L.runSeconds(s.blocks)) return s;
  return Object.assign({}, s, { title: s.title.replace(/^Trote .*?·/, 'Caminhada com trechos rápidos ·').replace(/^Corrida contínua/, 'Caminhada rápida contínua').replace(/^Longo/, 'Longo caminhando').replace(/^Teste/, 'Teste caminhando'), kind: s.kind === 'race' ? 'race' : 'walk', blocks: L.walkVersion(s.blocks), walkOnly: true });
}
function runPlanInfo(k) {
  k = k || today();
  const rc = runCfg();
  const N = L.planWeeks(rc.start, rc.race.date);
  const w = L.clamp(L.planWeekNow(rc.start, k, rc.shift), 1, N);
  const short = N < 16;
  const cw = L.canonicalWeek(w, N);
  const phase = C.RUN_PHASES.find((p) => cw >= p.from && cw <= p.to) || C.RUN_PHASES[0];
  const sessions = C.RUN_PLAN[cw].map((s) => (short && s.kind !== 'race' ? walkified(s) : s));
  return { rc, N, w, cw, phase, sessions, short, daysToRace: L.diffDays(k, rc.race.date) };
}
const runDays = () => { const wp = weekPlan(); return [1, 2, 3, 4, 5, 6, 0].filter((d) => wp[d] === 'run'); };
const S_RECOVERY = { title: 'Caminhada leve · 30 min', kind: 'walk', blocks: [{ t: 'w', s: 1800 }], note: 'Recuperação: ritmo bem tranquilo.' };
const S_EVE = { title: 'Véspera da prova · caminhada leve de 15 min', kind: 'walk', blocks: [{ t: 'w', s: 900 }], note: 'Descanse, beba água, separe roupa, tênis e número de peito.' };
function runSessionFor(k) {
  const info = runPlanInfo(k);
  if (k === info.rc.race.date) return { idx: 2, s: C.RUN_PLAN[L.RUN_WEEKS][2], info, race: true };
  const days = runDays(), pos = days.indexOf(L.weekday(k));
  if (pos < 0) return null;
  let idx;
  if (days.length === 1) idx = 2;
  else if (days.length === 2) idx = pos === 0 ? 0 : 2;
  else idx = pos === days.length - 1 ? 2 : pos === 0 ? 0 : pos === 1 ? 1 : -1;
  let s = idx < 0 ? S_RECOVERY : info.sessions[idx];
  if (s && s.kind === 'race') s = S_EVE;
  return { idx, s, info };
}
const runsOn = (k) => MEMO().runs.filter((r) => r.date === k);
const sessionLocked = (s) => !!s && L.runSeconds(s.blocks) > 0 && runLocked();
const sessionToRun = (s) => (sessionLocked(s) ? walkified(s) : s);

/* ---------- fotos ---------- */
const photosMeta = () => (coreRead().photos || []).slice().sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.at || 0) - (b.at || 0)));
const photoOn = (k) => photosMeta().some((p) => p.date === k);

/* ---------- agenda do dia ---------- */
function agendaFor(k) {
  const p = prof(), plan = dayPlan(k), mt = mealTimesAll(), menu = menuFor(k);
  let trainLabel = '', trainSub = '';
  if (plan === 'gym') { const t = nextType(); trainLabel = C.PROGRAM[t].title; trainSub = 'Academia · ' + C.PROGRAM[t].focus; }
  if (plan === 'run') { const rs = runSessionFor(k); const s = rs ? sessionToRun(rs.s) : null; trainLabel = s ? s.title : 'Corrida / caminhada'; trainSub = s && s.place === 'praia' ? 'Praia · areia firme' : s && s.place === 'orla' ? 'Orla' : ''; }
  const meals = C.MEALS6.map((m) => ({ id: m.id, label: m.label, time: mt[m.id], sub: adaptFood(menu[m.id].t) }));
  const supps = suppsOn(k).map((s) => ({ id: s.id, name: s.name, dose: s.dose, time: suppTime(s) }));
  return L.buildAgenda({ weekday: L.weekday(k), wake: p.wakeTime, bed: p.bedTime, train: p.trainTime, dayPlan: plan, trainLabel, trainSub, meals, supps, custom: p.custom || [], photo: p.reminders.photo !== false });
}
function agendaDone(k, it) {
  const d = MEMO().days[k] || {};
  if (it.kind === 'meal') return !!(d.meals || {})[it.id.slice(5)];
  if (it.kind === 'supp') return !!(d.supps || {})[it.id.slice(5)];
  if (it.kind === 'photo') return photoOn(k);
  if (it.kind === 'gym') return MEMO().trainedDates.has(k) || !!(d.agenda || {})[it.id];
  if (it.kind === 'run') return runsOn(k).length > 0 || !!(d.agenda || {})[it.id];
  if (it.kind === 'wake') return !!d.sleep || !!(d.agenda || {}).wake;
  return !!(d.agenda || {})[it.id];
}

/* ---------- próxima ação (o card AGORA) ---------- */
function nextAction() {
  const k = today(), p = prof(), info = dayInfo(k), d = info.d, n = nowMin();
  const wake = L.minutesOf(p.wakeTime) ?? 390;
  let bed = L.minutesOf(p.bedTime) ?? 1350;
  if (bed <= wake) bed += 1440;
  const train = L.minutesOf(p.trainTime) ?? 1110;
  const act = activeSession();
  if (act) {
    const st = sessionStats(act);
    return { title: `Continue: ${sessionTitle(act)}`, text: `${st.done} de ${st.total} exercícios feitos. Termine o que começou.`, btn: { label: 'Continuar treino', act: 'resumeSession', icon: 'play' } };
  }
  if (typeof ui !== 'undefined' && ui.run && ui.run.active) {
    return { title: 'Sessão de corrida em andamento', text: ui.run.title, btn: { label: 'Voltar à sessão', act: 'go', data: { to: 'corrida' }, icon: 'play' } };
  }
  const night = n >= bed - 60 || n < wake - 90;
  if (night) {
    return { title: 'Hora de desacelerar', text: `Telas longe e luz baixa. Meta: dormir às ${p.bedTime}. ${info.score >= L.CONSISTENT ? 'Dia bem feito.' : 'Amanhã tem mais.'}`, btn: null };
  }
  if (!d.sleep && n < wake + 180) {
    return { title: 'Como você dormiu?', text: 'Registre em 10 segundos: horário, qualidade e energia ao acordar.', btn: { label: 'Registrar sono', act: 'sheet', data: { s: 'sono' }, icon: 'moon' } };
  }
  if (p.reminders.photo !== false && !photoOn(k) && n < wake + 300) {
    return { title: 'Foto do dia', text: 'Mesmo lugar e mesma luz, antes de comer. Leva 20 segundos e mostra sua evolução daqui a alguns meses.', btn: { label: 'Tirar foto', act: 'photoAdd', data: { pose: 'frente' }, icon: 'camera' } };
  }
  const lw = lastWeigh();
  const since = lw ? L.diffDays(lw.date, k) : 99;
  if (since >= 7 && n < 12 * 60) {
    return { title: 'Pesagem da semana', text: 'De manhã, depois do banheiro e antes de comer. O app acompanha a tendência, não o número de um dia.', btn: { label: 'Registrar peso', act: 'sheet', data: { s: 'peso' }, icon: 'scale' } };
  }
  const plan = dayPlan(k);
  if (plan === 'gym' && !info.trained && n >= train - 90) {
    const t = nextType();
    return { title: `Hora do ${C.PROGRAM[t].title}`, text: phraseOf(k), btn: { label: 'Começar treino', act: 'startSession', data: { type: t }, icon: 'play' }, alt: { label: 'Sem tempo ou sem pique? Treino rápido de 25 min', act: 'startSession', data: { type: 'R' } } };
  }
  if (plan === 'run' && !runsOn(k).length && n >= train - 90) {
    const rs = runSessionFor(k);
    if (rs) {
      const s = sessionToRun(rs.s);
      return { title: rs.race ? 'Dia da prova' : L.runSeconds(s.blocks) ? 'Hora da corrida' : 'Hora da caminhada', text: `${s.title}. ${phraseOf(k)}`, btn: { label: 'Começar sessão', act: 'runStart', data: { idx: rs.idx }, icon: 'play' } };
    }
  }
  const due = suppsOn(k).find((s) => { const t = L.minutesOf(suppTime(s)); return t != null && n >= t - 15 && n <= t + 90 && !suppTaken(k, s.id); });
  if (due) {
    return { title: `Suplemento: ${due.name}`, text: `${due.dose || 'Dose indicada'}${due.meal ? ' · com ' + mealLabel(due.meal).toLowerCase() : ''}.`, btn: { label: 'Marcar como tomado', act: 'suppTake', data: { id: due.id }, icon: 'check' } };
  }
  const water = d.water || 0;
  const expected = L.waterExpected(p.waterGoal, n, wake, L.minutesOf(p.bedTime) ?? 1350);
  if (expected - water >= 500 && water < p.waterGoal) {
    return { title: 'Beba 500 ml de água', text: `Pelo horário, o ideal seria ${fmt0(expected)} ml. Você está com ${fmt0(water)} ml.`, btn: { label: '+500 ml', act: 'water', data: { ml: 500 }, icon: 'drop' } };
  }
  const meal = mealNow(n);
  if (meal && !(d.meals || {})[meal.id]) {
    const mn = menuFor(k)[meal.id];
    return { title: `${meal.label} · ${mealTimeOf(meal.id)}`, text: adaptFood(mn.t) + '.', btn: { label: 'Registrar refeição', act: 'sheet', data: { s: 'refeicao', m: meal.id }, icon: 'bowl' } };
  }
  if (plan === 'rest' && !info.cardio && n < bed - 120) {
    return { title: 'Descanso ativo: caminhe 20–30 min', text: 'Ritmo leve, dá para conversar. Conta como movimento no checklist.', btn: { label: 'Registrar caminhada', act: 'sheet', data: { s: 'cardio', kind: 'caminhada' }, icon: 'walk' } };
  }
  if (plan === 'gym' && !info.trained) {
    return { title: `${C.PROGRAM[nextType()].title} hoje às ${p.trainTime}`, text: 'Separe a roupa e a garrafa agora. A decisão já está tomada: é só executar.', btn: { label: 'Ver treino', act: 'tabSub', data: { to: 'treino', sub: 'academia' }, icon: 'dumbbell' } };
  }
  if (plan === 'run' && !runsOn(k).length) {
    const rs = runSessionFor(k);
    return { title: `Corrida hoje às ${p.trainTime}`, text: rs ? sessionToRun(rs.s).title + '.' : '', btn: { label: 'Ver sessão', act: 'tabSub', data: { to: 'treino', sub: 'corrida' }, icon: 'walk' } };
  }
  const missing = L.CHECK_KEYS.filter((x) => !info.st[x]);
  if (missing.length) {
    return { title: 'Complete o dia', text: `Falta: ${missing.map((x) => checkLabel(x, k).toLowerCase()).join(', ')}.`, btn: { label: 'Ver checklist', act: 'scrollTo', data: { id: 'hoje' }, icon: 'check' } };
  }
  return { title: 'Dia vencido.', text: 'Tudo feito. Descanse bem: amanhã tem mais.', btn: null };
}
function checkLabel(key, k) {
  return {
    treino: dayPlan(k || today()) === 'rest' ? 'Movimento do dia' : 'Treino',
    agua: 'Água', proteina: 'Proteína', frutas: 'Frutas e vegetais', fibras: 'Fibras',
    passos: 'Passos', alimentacao: 'Alimentação planejada', sono: 'Sono 7 h+',
  }[key];
}
