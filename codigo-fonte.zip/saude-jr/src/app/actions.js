/* ===== Saúde Jr. — folhas de registro, ações, lembretes e inicialização ===== */
const $app = document.getElementById('app');
const VIEWS = { auth: vAuth, splash: vSplash, onboarding: vOnboarding, home: vHome, treino: vTreino, sessao: vSessao, fim: vFim, comida: vComida, evolucao: vEvolucao, mais: vMais, sono: vSono, hormonal: vHormonal, lembretes: vLembretes, perfil: vPerfil, seguranca: vSeguranca, agenda: vAgenda, corrida: vCorridaSessao, planoMes: vPlanoMes, instalar: vInstalar, privacidade: vPrivacidade };
const SUBPAGES = new Set(['sono', 'hormonal', 'lembretes', 'perfil', 'seguranca', 'agenda', 'planoMes', 'instalar', 'privacidade']);
const TAB_ROOTS = new Set(['home', 'treino', 'comida', 'evolucao', 'mais']);
let pendingRender = false;

const isTyping = () => { const a = document.activeElement; return !!(a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type !== 'range'); };
function render() {
  invalidate();
  guardRoute();
  const key = ui.route + '|' + (ui.sub[ui.route] || '');
  const same = ui.lastKey === key;
  const y = window.scrollY;
  const html = (VIEWS[ui.route] || vHome)();
  $app.innerHTML = html;
  $app.classList.toggle('no-tabs', NO_TABS.has(ui.route));
  renderTabbar();
  window.scrollTo(0, same ? y : 0);
  ui.lastKey = ui.route + '|' + (ui.sub[ui.route] || '');
  if (ui.route === 'sessao' && ui.scrollEx != null) {
    const el = document.querySelectorAll('#app .ex')[ui.scrollEx + 1];
    ui.scrollEx = null;
    if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }
  if (ui.route === 'corrida') runTick();
  if (ui.route === 'auth') authAfterRender();
  hydratePhotos($app);
}
function safeRender() { if (isTyping() || ui.sheet) { pendingRender = true; return; } render(); }
function renderTabbar() {
  const tb = document.getElementById('tabbar');
  if (NO_TABS.has(ui.route)) { tb.hidden = true; return; }
  tb.hidden = false;
  const cur = ROUTE_TAB[ui.route] || 'home';
  tb.innerHTML = TABS.map(([id, label, ic]) => `<button class="tab" data-act="tab" data-to="${id}" ${cur === id ? 'aria-current="page"' : ''}>${icon(ic)}<span>${label}</span><span class="pip"></span></button>`).join('');
}
function go(to) {
  if (to === 'meta') { ui.sub.evolucao = 'meta'; to = 'evolucao'; }
  if (SUBPAGES.has(to) && TAB_ROOTS.has(ui.route)) ui.back = ui.route;
  if (TAB_ROOTS.has(to)) ui.back = 'mais';
  ui.route = to;
  closeSheet();
  render();
}
let toastT = null;
function placeToast() {
  const t = document.getElementById('toast');
  const restOn = !document.getElementById('restbar').hidden;
  t.style.bottom = restOn ? 'calc(118px + env(safe-area-inset-bottom, 0px))' : NO_TABS.has(ui.route) ? 'calc(24px + env(safe-area-inset-bottom, 0px))' : '';
}
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  placeToast();
  t.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------------- folhas (sheets) ---------------- */
function openSheet(name, data) { suspendAlert(); ui.sheet = { name, data: data || {} }; renderSheet(); }
function closeSheet() {
  if (!ui.sheet) return;
  stopTimelapse();
  ui.sheet = null;
  const w = document.getElementById('sheet');
  w.hidden = true; w.innerHTML = '';
  document.body.style.overflow = '';
  if (pendingRender) { pendingRender = false; render(); }
  if ((ui.alertQ || []).length) setTimeout(showNextReminder, 700);
}
function renderSheet() {
  const w = document.getElementById('sheet');
  const fn = SHEETS[ui.sheet.name];
  if (!fn) return;
  const r = fn(ui.sheet.data);
  w.innerHTML = `<div class="sheet-scrim" data-act="closeSheet"></div><div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(r.title)}"><div class="grab"></div>
    <div class="sheet-head"><div class="h2">${esc(r.title)}</div><button class="btn btn-icon btn-ghost" data-act="closeSheet" aria-label="Fechar">${icon('x')}</button></div>${r.body}</div>`;
  w.hidden = false;
  document.body.style.overflow = 'hidden';
  hydratePhotos(w);
  if (r.after) r.after();
  if (r.focus) { const f = document.getElementById(r.focus); if (f) { f.focus(); if (f.select) try { f.select(); } catch (e) { /* ok */ } } }
}
const pressedIn = (id) => { const b = document.querySelector(`#${id} [aria-pressed="true"]`); return b ? b.dataset.v : null; };
const foodOptions = (grp, sel, extra) => [...Object.entries(C.FOODS).filter(([, f]) => f.g === grp).map(([id, f]) => [id, f.name]), ...extra]
  .map(([id, n]) => `<option value="${id}" ${sel === id ? 'selected' : ''}>${esc(n)}</option>`).join('');
const SHEETS = {
  peso: () => {
    const lw = lastWeigh();
    return { title: 'Registrar peso', focus: 'w-kg', body: `
      <div class="stepper" style="grid-template-columns:64px minmax(0,1fr) 64px"><button data-act="nudge" data-for="w-kg" data-d="-0.1" aria-label="Menos 0,1 kg">${icon('minus')}</button><input id="w-kg" class="big-input" type="text" inputmode="decimal" autocomplete="off" value="${decv(lw ? lw.kg : prof().startWeight)}" aria-label="Peso em kg"><button data-act="nudge" data-for="w-kg" data-d="0.1" aria-label="Mais 0,1 kg">${icon('plus')}</button></div>
      <div class="field"><label for="w-date">Data</label><input id="w-date" type="date" value="${today()}" max="${today()}"></div>
      <p class="hint">De manhã, depois do banheiro e antes de comer, 1 a 3 vezes por semana. O app mostra a tendência, não o número de um dia.</p>
      <button class="btn btn-go btn-block" data-act="saveWeight">Salvar peso</button>
      <button class="link-btn" data-act="sheet" data-s="medidas">Registrar cintura e quadril</button>` };
  },
  medidas: () => {
    const ws = MEMO().measures, last = ws[ws.length - 1] || {};
    const f = (id, l, v) => `<div class="field"><label for="${id}">${l} (cm)</label><input id="${id}" type="text" inputmode="decimal" autocomplete="off" value="${decv(v)}" placeholder="opcional"></div>`;
    return { title: 'Medidas', body: `
      <div class="grid2">${f('m-waist', 'Cintura', last.waist)}${f('m-hip', 'Quadril', last.hip)}</div>
      <div class="grid2">${f('m-arm', 'Braço', last.arm)}${f('m-chest', 'Peito', last.chest)}</div>
      <div class="field"><label for="m-date">Data</label><input id="m-date" type="date" value="${today()}" max="${today()}"></div>
      <p class="hint">Fita sem apertar, sempre no mesmo horário. Cintura: na altura do umbigo, depois de soltar o ar. Braço: relaxado, no meio entre ombro e cotovelo. Peito: na linha dos mamilos. Meça a cada 2 semanas.</p>
      <button class="btn btn-go btn-block" data-act="saveMeasures">Salvar medidas</button>` };
  },
  comecarDia: () => {
    const p = prof(), k = today(), d = MEMO().days[k] || {}, s = d.sleep || {};
    const bed = s.bed || p.bedTime, wake = s.wake || p.wakeTime, r = p.reminders;
    const lw = lastWeigh(), weighDay = r.weigh !== false && L.weekday(k) === Number(r.weighDay) && !(lw && lw.date === k);
    const plan = dayPlan(k), agenda = agendaFor(k).filter((it) => it.kind !== 'wake').slice(0, 6);
    return { title: 'Começar o dia', body: `
      <p class="muted">${esc(phraseOf(k))}</p>
      <div class="field"><span class="lbl">Como você dormiu?</span>
        <div class="grid2"><div class="field"><label for="sd-bed">Dormi às</label><input id="sd-bed" type="time" value="${esc(bed)}" data-input="sdCalc"></div><div class="field"><label for="sd-wake">Acordei às</label><input id="sd-wake" type="time" value="${esc(wake)}" data-input="sdCalc"></div></div>
        <div class="note">${icon('moon')}<span>Duração: <b id="sd-h">${fmt1(L.sleepHours(bed, wake))} h</b></span></div>
        <div class="seg" id="sd-q">${['Ruim', 'Regular', 'Boa', 'Ótima'].map((l, i) => `<button data-act="pick" data-group="sd-q" data-v="${i + 1}" aria-pressed="${s.quality === i + 1}">${l}</button>`).join('')}</div></div>
      <div class="field"><span class="lbl">Energia agora</span><div class="scale" id="sd-e">${Array.from({ length: 10 }, (_, i) => `<button data-act="pick" data-group="sd-e" data-v="${i + 1}" aria-pressed="${s.energy === i + 1}">${i + 1}</button>`).join('')}</div><span class="hint">1 = exausto · 10 = cheio de energia</span></div>
      ${weighDay ? `<div class="field"><label for="sd-kg">Pesagem da semana (kg)</label><input id="sd-kg" type="text" inputmode="decimal" autocomplete="off" placeholder="opcional · depois do banheiro, antes de comer"></div>` : ''}
      <div class="switch-row"><span><b>Primeiro copo de água</b><br><span class="tiny faint">+250 ml agora</span></span><button class="switch" role="switch" id="sd-water" aria-checked="true" aria-label="Registrar o primeiro copo de água" data-act="toggleSwitch"></button></div>
      <div class="stack-sm"><span class="lbl">Seu plano de hoje</span>
        <div class="plan-list">${agenda.map((it) => `<div class="kv"><span class="k">${esc(it.time)}</span><span class="v small">${esc(it.label)}</span></div>`).join('')}</div>
        <p class="tiny faint">${plan === 'rest' ? 'Dia de descanso ativo: caminhada leve conta.' : 'O card “Agora” mostra o próximo passo a cada hora.'}</p></div>
      <button class="btn btn-go btn-block" data-act="saveStartDay">${icon('sun')}Começar</button>` };
  },
  senha: () => ({ title: 'Trocar senha', focus: 'np-1', body: `
    <div class="field"><label for="np-1">Nova senha</label><div class="pw"><input id="np-1" type="password" autocomplete="new-password" minlength="8" maxlength="72"><button type="button" class="pw-eye" data-act="pwToggle" data-for="np-1" aria-label="Mostrar senha" aria-pressed="false">${icon('eye', 'ic-sm')}</button></div></div>
    <div class="field"><label for="np-2">Repita a nova senha</label><div class="pw"><input id="np-2" type="password" autocomplete="new-password" minlength="8" maxlength="72"><button type="button" class="pw-eye" data-act="pwToggle" data-for="np-2" aria-label="Mostrar senha" aria-pressed="false">${icon('eye', 'ic-sm')}</button></div></div>
    <p class="hint">Pelo menos 8 caracteres, com letras e números.</p>
    <button class="btn btn-go btn-block" id="np-save" data-act="savePass">Salvar nova senha</button>` }),
  passos: () => {
    const d = MEMO().days[today()] || {};
    return { title: 'Passos de hoje', focus: 'st-n', body: `
      <input id="st-n" class="big-input" type="number" inputmode="numeric" step="100" value="${d.steps || ''}" placeholder="0" aria-label="Passos">
      <div class="chips">${[1000, 2000, 3000, 5000].map((n) => `<button class="chip" data-act="addSteps" data-n="${n}">+${fmt0(n)}</button>`).join('')}</div>
      <p class="hint">Veja o total no app de saúde do celular (Google Fit, Samsung Health ou Saúde) e anote aqui. Meta atual: ${fmt0(prof().stepsGoal)} passos.</p>
      <button class="btn btn-go btn-block" data-act="saveSteps">Salvar passos</button>` };
  },
  sono: () => {
    const p = prof(), s = (MEMO().days[today()] || {}).sleep || {};
    const bed = s.bed || p.bedTime, wake = s.wake || p.wakeTime;
    return { title: 'Sono de hoje', body: `
      <div class="grid2"><div class="field"><label for="sl-bed">Dormi às</label><input id="sl-bed" type="time" value="${esc(bed)}" data-input="sleepCalc"></div><div class="field"><label for="sl-wake">Acordei às</label><input id="sl-wake" type="time" value="${esc(wake)}" data-input="sleepCalc"></div></div>
      <div class="note">${icon('moon')}<span>Duração: <b id="sl-h">${fmt1(L.sleepHours(bed, wake))} h</b></span></div>
      <div class="field"><span class="lbl">Qualidade</span><div class="seg" id="sl-q">${['Ruim', 'Regular', 'Boa', 'Ótima'].map((l, i) => `<button data-act="pick" data-group="sl-q" data-v="${i + 1}" aria-pressed="${s.quality === i + 1}">${l}</button>`).join('')}</div></div>
      <div class="field"><span class="lbl">Energia ao acordar</span><div class="scale" id="sl-e">${Array.from({ length: 10 }, (_, i) => `<button data-act="pick" data-group="sl-e" data-v="${i + 1}" aria-pressed="${s.energy === i + 1}">${i + 1}</button>`).join('')}</div><span class="hint">1 = exausto · 10 = cheio de energia</span></div>
      <div class="field"><label for="sl-notes">Observações</label><textarea id="sl-notes" maxlength="300" placeholder="Ex.: acordei 2 vezes, dormi tarde por causa do celular">${esc(s.notes || '')}</textarea></div>
      <button class="btn btn-go btn-block" data-act="saveSleep">Salvar sono</button>` };
  },
  agua: () => {
    const p = prof();
    return { title: 'Água', body: `
      <div class="field"><label for="wa-ml">Adicionar outra quantidade (ml)</label><div class="row"><input id="wa-ml" type="number" inputmode="numeric" step="50" placeholder="ex.: 350" style="flex:1"><button class="btn btn-soft" data-act="waterCustom">Adicionar</button></div></div>
      <div class="field"><label for="wa-goal">Meta do dia (ml)</label><div class="stepper"><button data-act="nudge" data-for="wa-goal" data-d="-250" aria-label="Menos 250 ml">${icon('minus')}</button><input id="wa-goal" type="number" inputmode="numeric" step="250" value="${p.waterGoal}"><button data-act="nudge" data-for="wa-goal" data-d="250" aria-label="Mais 250 ml">${icon('plus')}</button></div></div>
      <p class="hint">Não existe um número universal. Ajuste pela sede, pelo calor, pelos treinos e pela orientação médica. Urina clara ao longo do dia é um bom sinal.</p>
      <button class="btn btn-go btn-block" data-act="saveWaterGoal">Salvar meta</button>` };
  },
  cardio: (data) => {
    const kind = data.kind || ui.lastCardioKind || 'esteira';
    const plan = C.cardioPlan(progWeek());
    return { title: 'Registrar cardio', after: cardioCalc, body: `
      <div class="field"><span class="lbl">Modalidade</span><div class="chips" id="cd-kind">${C.CARDIO_KINDS.map((c) => `<button class="chip" data-act="pick" data-group="cd-kind" data-v="${c.id}" data-then="cardioCalc" aria-pressed="${c.id === kind}">${c.label}</button>`).join('')}</div></div>
      <div class="field"><label for="cd-min">Tempo (min)</label><div class="stepper"><button data-act="nudge" data-for="cd-min" data-d="-5" aria-label="Menos 5 minutos">${icon('minus')}</button><input id="cd-min" type="number" inputmode="numeric" value="${plan.minutes}" data-input="cardioCalc"><button data-act="nudge" data-for="cd-min" data-d="5" aria-label="Mais 5 minutos">${icon('plus')}</button></div></div>
      <div class="grid2"><div class="field"><label for="cd-km">Distância (km)</label><input id="cd-km" type="text" inputmode="decimal" autocomplete="off" placeholder="opcional" data-input="cardioCalc"></div><div class="field"><label for="cd-spd">Velocidade (km/h)</label><input id="cd-spd" type="text" inputmode="decimal" autocomplete="off" placeholder="opcional" data-input="cardioCalc"></div></div>
      <div class="field"><label for="cd-rpe">Esforço: <b id="cd-rpe-v">4</b>/10 · <span id="cd-rpe-t">${C.RPE(4)}</span></label><input id="cd-rpe" type="range" min="1" max="10" step="1" value="4" data-input="cardioCalc"></div>
      <div class="field"><label for="cd-kcal">Calorias estimadas</label><input id="cd-kcal" type="number" inputmode="numeric" placeholder="automático"><span class="hint" id="cd-kcal-h">Estimativa pelo tipo, tempo, esforço e seu peso. Se o aparelho mostrar, use o valor dele.</span></div>
      <button class="btn btn-go btn-block" data-act="saveCardio">Salvar cardio</button>` };
  },
  marmita: (data) => {
    const m = data.id ? marmitaById(data.id) : null, v = m || {};
    const pair = (id, grp, selV, gV, oV, extra, label) => `<div class="field"><span class="lbl">${label}</span><div class="grid2" style="grid-template-columns:minmax(0,1.6fr) minmax(0,1fr)">
      <select id="${id}-f" data-input="mmPreview" aria-label="${label}"><option value="">Escolha</option>${foodOptions(grp, selV, extra)}</select>
      <input id="${id}-g" type="number" inputmode="numeric" placeholder="gramas" value="${gV != null ? esc(gV) : ''}" data-input="mmPreview" aria-label="${label} em gramas"></div>
      <input id="${id}-o" type="text" placeholder="Qual?" value="${esc(oV || '')}" ${selV === 'outro' ? '' : 'hidden'} aria-label="${label}: qual"></div>`;
    return { title: m ? 'Editar marmita' : 'Nova marmita', after: mmPreview, body: `
      <div class="field"><label for="mm-name">Nome</label><input id="mm-name" type="text" value="${esc(v.name || '')}" placeholder="Ex.: Frango com legumes" data-input="mmPreview"></div>
      ${pair('mm-p', 'prot', v.protFood, v.protG, v.protOther, [['outro', 'Outro']], 'Proteína')}
      ${pair('mm-c', 'carb', v.carbFood, v.carbG, v.carbOther, [['nenhum', 'Sem carboidrato'], ['outro', 'Outro']], 'Carboidrato')}
      ${pair('mm-v', 'veg', v.vegFood, v.vegG, v.vegOther, [['outro', 'Outro']], 'Vegetais')}
      <div class="field"><label for="mm-qty">Quantidade total (g)</label><input id="mm-qty" type="number" inputmode="numeric" value="${v.qty != null ? esc(v.qty) : ''}" placeholder="opcional, ex.: 400"></div>
      <div class="stack-sm"><span class="lbl">Do rótulo (opcional)</span><div class="grid2"><div class="field"><label for="mm-kcal">Calorias (kcal)</label><input id="mm-kcal" type="number" inputmode="numeric" value="${v.kcal != null ? esc(v.kcal) : ''}" data-input="mmPreview"></div><div class="field"><label for="mm-prot">Proteína (g)</label><input id="mm-prot" type="number" inputmode="numeric" value="${v.prot != null ? esc(v.prot) : ''}" data-input="mmPreview"></div></div><span class="hint">Com o rótulo preenchido, o app usa esses valores em vez da estimativa.</span></div>
      <div id="mm-prev"></div>
      <button class="btn btn-go btn-block" data-act="saveMarmita" data-id="${esc(v.id || '')}">Salvar marmita</button>
      ${m ? `<button class="btn btn-danger btn-block btn-sm" data-act="askDelMarmita" data-id="${m.id}">${icon('trash', 'ic-sm')}Excluir marmita</button>` : ''}` };
  },
  trocar: (data) => {
    const s = activeSession(), it = s && s.items[Number(data.i)];
    if (!it) return { title: 'Trocar exercício', body: '<p class="muted">Treino não encontrado.</p>' };
    const slot = it.slotId ? [...C.PROGRAM.A.slots, ...C.PROGRAM.B.slots].find((x) => x.id === it.slotId) : null;
    if (!slot) return { title: 'Trocar exercício', body: '<p class="muted">Este exercício do treino em casa não tem alternativa. Se não der, pule e siga para o próximo.</p>' };
    return { title: 'Trocar exercício', body: `<p class="small muted">Máquina ocupada ou sem o aparelho? Escolha uma alternativa para a mesma região. O app lembra da troca nos próximos treinos.</p>
      <div class="stack-sm">${slot.options.map((id) => { const ex = C.EX[id], cur = id === it.exId, av = exAvailable(id); return `<button class="list-row" style="background:var(--surface-2);border-radius:14px;border:0" data-act="swapEx" data-i="${data.i}" data-ex="${id}"><span class="grow"><b>${esc(ex.name)}</b> ${cur ? '<span class="badge ok">atual</span>' : ''}<br><span class="small muted">${esc(ex.group)}${av ? '' : ' · marcado como indisponível'}</span></span>${icon('chevR', 'chev')}</button>`; }).join('')}</div>` };
  },
  meta: () => {
    const p = prof();
    return { title: 'Ajustar meta', focus: 'g-kg', body: `
      <div class="stepper" style="grid-template-columns:64px minmax(0,1fr) 64px"><button data-act="nudge" data-for="g-kg" data-d="-1" aria-label="Menos 1 kg">${icon('minus')}</button><input id="g-kg" class="big-input" type="text" inputmode="decimal" autocomplete="off" value="${decv(p.goalWeight)}" aria-label="Meta em kg"><button data-act="nudge" data-for="g-kg" data-d="1" aria-label="Mais 1 kg">${icon('plus')}</button></div>
      <p class="hint">Meta pessoal. O número certo para você sai de uma avaliação física (bioimpedância) com médico e nutricionista. As metas intermediárias de 5 em 5 kg continuam valendo.</p>
      <button class="btn btn-go btn-block" data-act="saveGoal">Salvar meta</button>` };
  },
  confirm: (d) => ({ title: d.title, body: `<p class="muted">${esc(d.text)}</p><div class="btn-row"><button class="btn btn-ghost" data-act="${d.cancelAct || 'closeSheet'}">${esc(d.cancel || 'Cancelar')}</button><button class="btn ${d.danger ? 'btn-danger' : 'btn-go'}" data-act="${d.ok}" ${attrs(d.okData)}>${esc(d.okLabel)}</button></div>${d.extra || ''}` }),
  compare: (d) => {
    let a, b, la = 'Início', lb = 'Meta';
    if (d.mode === 'photos') {
      const ph = frontPhotos();
      if (ph.length < 2) return { title: 'Comparar', body: '<p class="muted">Tire pelo menos duas fotos de frente.</p>' };
      a = ph[0]; b = ph[ph.length - 1]; la = dShort(a.date); lb = dShort(b.date);
    } else {
      const gp = goalPair();
      if (!gp || !gp.start || !gp.goal) return { title: 'Comparar', body: '<p class="muted">Adicione a foto de início e a foto-meta.</p>' };
      a = gp.start; b = gp.goal;
    }
    return { title: d.mode === 'photos' ? 'Primeira × última' : 'Início × meta', after: bindCompare, body: `
      <div class="cmp" id="cmp" style="--x:50%">${photoImg(a, la)}${photoImg(b, lb, 'after')}<div class="handle"><div class="knob">${icon('swap', 'ic-sm')}</div></div><span class="lbl-l">${esc(la)}</span><span class="lbl-r">${esc(lb)}</span></div>
      <input type="range" min="0" max="100" value="50" id="cmp-r" data-input="cmpSlide" aria-label="Posição da comparação">
      <p class="tiny faint center">Arraste para comparar.</p>` };
  },
  foto: (d) => {
    const ph = photosMeta().find((x) => x.id === d.id);
    if (!ph) return { title: 'Foto', body: '<p class="muted">Foto não encontrada.</p>' };
    const n = L.diffDays(startDate(), ph.date) + 1;
    return { title: `Foto de ${dShort(ph.date)}${ph.pose && ph.pose !== 'frente' ? ' · ' + ph.pose : ''}`, body: `<div class="ph-full">${photoImg(ph, 'Foto de ' + dShort(ph.date))}</div>
      <p class="small muted center">${dLong(ph.date)}${n > 0 ? ` · dia ${n} da virada` : ''}</p>
      <button class="btn btn-danger btn-block btn-sm" data-act="askDelPhoto" data-id="${ph.id}">${icon('trash', 'ic-sm')}Apagar foto</button>` };
  },
  energia: () => {
    const s = (MEMO().days[today()] || {}).sleep || {};
    return { title: 'Energia hoje', body: `<p class="muted">Como você está se sentindo hoje?</p>
      <div class="scale">${Array.from({ length: 10 }, (_, i) => `<button data-act="dayEnergy" data-v="${i + 1}" aria-pressed="${s.day === i + 1}">${i + 1}</button>`).join('')}</div>
      <div class="between tiny faint"><span>1 · sem energia</span><span>10 · cheio de energia</span></div>
      <p class="hint">Registre todo dia, no mesmo horário. Em algumas semanas dá para ver se a energia está subindo. Cansaço que não passa merece conversa com um médico.</p>` };
  },
  texto: (d) => ({ title: d.title, body: `<p class="small muted">Copie o conteúdo abaixo e guarde onde preferir.</p><textarea id="tx-out" readonly style="min-height:240px;font-family:ui-monospace,monospace;font-size:13px">${esc(d.text)}</textarea><button class="btn btn-soft btn-block" data-act="copyText" data-for="tx-out">${icon('copy', 'ic-sm')}Copiar</button>` }),
  refeicao: (d) => refeicaoSheet(d),
  horarios: () => horariosSheet(),
  supp: (d) => suppSheet(d),
  bloco: (d) => blocoSheet(d),
  planItem: (d) => planItemSheet(d),
  runLog: (d) => runLogSheet(d),
  prova: () => provaSheet(),
  timelapse: () => ({ title: 'Sua evolução', after: startTimelapse, body: `
    <div class="tl"><img id="tl-img" alt="Linha do tempo das suas fotos"><span class="tl-date" id="tl-date"></span></div>
    <input type="range" id="tl-r" min="0" max="0" value="0" step="1" data-input="tlSeek" aria-label="Escolher a foto">
    <div class="btn-row"><button class="btn btn-soft" data-act="tlPlay" id="tl-play">Pausar</button><button class="btn btn-ghost" data-act="tlSpeed" id="tl-speed">Velocidade 1×</button></div>
    <p class="tiny faint center">Fotos de frente, em ordem de data. Quanto mais dias, mais nítida a mudança.</p>` }),
};

/* ---------------- entradas ao vivo ---------------- */
function cardioCalc() {
  const kind = pressedIn('cd-kind') || 'esteira';
  const min = L.num(($('#cd-min') || {}).value), km = L.num(($('#cd-km') || {}).value), spd = L.num(($('#cd-spd') || {}).value);
  const rpeEl = $('#cd-rpe'); if (!rpeEl) return;
  const rpe = Number(rpeEl.value);
  $('#cd-rpe-v').textContent = rpe; $('#cd-rpe-t').textContent = C.RPE(rpe);
  const speed = spd || (km && min ? km / (min / 60) : null);
  if (!spd && speed) $('#cd-spd').placeholder = `≈ ${fmt1(speed)}`;
  const kcal = L.kcal(L.cardioMET(kind, speed, rpe), curWeight(), min);
  $('#cd-kcal').placeholder = kcal ? `≈ ${fmt0(kcal)} kcal` : 'automático';
  $('#cd-kcal-h').textContent = rpe >= 9 ? 'Nesta fase, prefira esforço entre 3 e 6: sustentável e seguro.' : 'Estimativa pelo tipo, tempo, esforço e seu peso. Se o aparelho mostrar, use o valor dele.';
}
function readMarmitaForm() {
  const g = (id) => ($('#' + id) || {}).value;
  return {
    name: (g('mm-name') || '').trim(),
    protFood: g('mm-p-f') || null, protG: L.num(g('mm-p-g')), protOther: (g('mm-p-o') || '').trim(),
    carbFood: g('mm-c-f') || null, carbG: L.num(g('mm-c-g')), carbOther: (g('mm-c-o') || '').trim(),
    vegFood: g('mm-v-f') || null, vegG: L.num(g('mm-v-g')), vegOther: (g('mm-v-o') || '').trim(),
    qty: L.num(g('mm-qty')), kcal: L.num(g('mm-kcal')), prot: L.num(g('mm-prot')),
  };
}
function mmPreview() {
  const m = readMarmitaForm();
  ['mm-p', 'mm-c', 'mm-v'].forEach((id) => { const o = $('#' + id + '-o'), f = $('#' + id + '-f'); if (o && f) o.hidden = f.value !== 'outro'; });
  const box = $('#mm-prev'); if (!box) return;
  if (!m.protFood && !m.carbFood && !m.vegFood && m.kcal == null) { box.innerHTML = ''; return; }
  const tot = L.marmitaTotals(m, C.FOODS), chk = L.marmitaCheck(m, tot);
  box.innerHTML = `<div class="note ${chk.level === 'ok' ? 'go' : 'warn'}">${icon(chk.level === 'ok' ? 'check' : 'info')}<div class="stack-sm"><b>${tot.kcal != null ? `≈ ${fmt0(tot.kcal)} kcal · ${fmt0(tot.prot)} g de proteína` : 'Calorias: informe os gramas ou o rótulo'}</b>${chk.tips.length ? chk.tips.map((t) => `<span class="small">${esc(t)}</span>`).join('') : '<span class="small">Composição equilibrada.</span>'}</div></div>`;
}
function setCmp(v) { const c = $('#cmp'); if (c) c.style.setProperty('--x', v + '%'); const r = $('#cmp-r'); if (r && String(r.value) !== String(Math.round(v))) r.value = Math.round(v); }
function bindCompare() {
  const c = $('#cmp'); if (!c) return;
  const move = (e) => { const b = c.getBoundingClientRect(); setCmp(L.clamp(((e.clientX - b.left) / b.width) * 100, 0, 100)); };
  c.addEventListener('pointerdown', (e) => { c.setPointerCapture(e.pointerId); move(e); });
  c.addEventListener('pointermove', (e) => { if (e.buttons || e.pointerType === 'touch') move(e); });
}
const INP = {
  sleepCalc: () => { const h = L.sleepHours($('#sl-bed').value, $('#sl-wake').value); $('#sl-h').textContent = h != null ? fmt1(h) + ' h' : '—'; },
  sdCalc: () => { const h = L.sleepHours($('#sd-bed').value, $('#sd-wake').value); $('#sd-h').textContent = h != null ? fmt1(h) + ' h' : '—'; },
  cardioCalc: () => cardioCalc(),
  mmPreview: () => mmPreview(),
  cmpSlide: (el) => setCmp(Number(el.value)),
  rlRpe: (el) => { const v = Number(el.value), a = $('#rl-rpe-v'), b = $('#rl-rpe-t'); if (a) a.textContent = v; if (b) b.textContent = C.RPE(v); },
  rlPain: () => { const f = $('#rl-area-f'); if (f) f.hidden = !(Number(pressedIn('rl-pain') || 0) >= 1); },
  spWhen: (el) => { const f = $('#sp-time-f'); if (f) f.hidden = el.value !== 'hora'; },
  tlSeek: (el) => { if (!ui.tl) return; ui.tl.playing = false; ui.tl.i = Number(el.value) || 0; ui.tl.show(ui.tl.i); const b = $('#tl-play'); if (b) b.textContent = 'Continuar'; },
};

/* ---------------- água, peso e registros ---------------- */
function addWater(ml) {
  const k = today(), day = dayW(k), g = prof().waterGoal;
  const before = day.water || 0;
  day.water = before + ml;
  day.waterLog = (day.waterLog || []).concat(ml).slice(-60);
  save(monthId(k));
  render();
  toast(before < g && day.water >= g ? 'Meta de água batida!' : `+${fmt0(ml)} ml · ${fmt0(day.water)} ml hoje`);
}
function dayUpdate(fn, msg) { const k = today(); fn(dayW(k)); save(monthId(k)); render(); if (msg) toast(msg); }

/* ---------------- sessão de treino ---------------- */
const S = () => activeSession();
const itemOf = (d) => { const s = S(); return s ? s.items[Number(d.i)] : null; };
function nextOpen(s, from) {
  for (let j = from + 1; j < s.items.length; j++) if (!s.items[j].done) return j;
  for (let j = 0; j < s.items.length; j++) if (!s.items[j].done) return j;
  return -1;
}
function startSession(type) {
  const ex = activeSession();
  if (ex) { ui.route = 'sessao'; ui.openEx = nextOpen(ex, -1); closeSheet(); render(); wakeLock(true); return; }
  const s = buildSession(type);
  MON(s.date).sessions.push(s);
  save(monthId(s.date));
  ui.route = 'sessao'; ui.openEx = 0;
  closeSheet(); render(); wakeLock(true);
  toast(type === 'R' || type === 'H' ? 'Treino rápido: o básico bem feito' : 'Bom treino. Técnica primeiro.');
}
function finishNow() {
  const s = S(); if (!s) return;
  const results = finishSession(s);
  ui.finish = { id: s.id, results };
  stopRest(); wakeLock(false); closeSheet();
  ui.route = 'fim'; render();
  vibrate([60, 40, 60]);
}

/* ---------------- descanso ---------------- */
const rest = { until: 0, total: 0, t: null };
function startRest(sec) {
  rest.total = sec; rest.until = Date.now() + sec * 1000;
  const bar = document.getElementById('restbar');
  bar.innerHTML = `<div><div class="l">Descanso</div><div class="t" id="restT">${L.pad(Math.floor(sec / 60))}:${L.pad(sec % 60)}</div></div>
    <button data-act="restAdd" aria-label="Mais 15 segundos">+15 s</button><button class="go" data-act="restSkip">Pular</button><div class="rb"><i id="restP" style="width:100%"></i></div>`;
  bar.hidden = false; placeToast();
  clearInterval(rest.t); rest.t = setInterval(tickRest, 250);
}
function tickRest() {
  const left = Math.max(0, (rest.until - Date.now()) / 1000);
  const t = document.getElementById('restT'), p = document.getElementById('restP');
  const s = Math.ceil(left);
  if (t) t.textContent = `${Math.floor(s / 60)}:${L.pad(s % 60)}`;
  if (p) p.style.width = (rest.total ? (left / rest.total) * 100 : 0) + '%';
  if (left <= 0) { stopRest(); beep(); vibrate([250, 120, 250]); toast('Descanso encerrado. Próxima série!'); }
}
function stopRest() { clearInterval(rest.t); rest.t = null; const bar = document.getElementById('restbar'); if (bar) { bar.hidden = true; bar.innerHTML = ''; } }

/* ---------------- som, vibração, tela ligada ---------------- */
let actx = null;
function unlockAudio() {
  try {
    if (!actx) { const A = window.AudioContext || window.webkitAudioContext; if (A) actx = new A(); }
    if (actx && actx.state === 'suspended') actx.resume().catch(() => {});
  } catch (e) { actx = null; }
}
function beep() {
  if (!actx || actx.state !== 'running') return;
  try {
    const t = actx.currentTime;
    [0, 0.2].forEach((dt, i) => {
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = 'sine'; o.frequency.value = i ? 1046.5 : 784;
      g.gain.setValueAtTime(0.0001, t + dt); g.gain.exponentialRampToValueAtTime(0.28, t + dt + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + dt + 0.18);
      o.connect(g); g.connect(actx.destination); o.start(t + dt); o.stop(t + dt + 0.2);
    });
  } catch (e) { /* sem som */ }
}
function vibrate(p) { try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(p); } catch (e) { /* sem vibração */ } }
let wl = null;
async function wakeLock(on) {
  try {
    if (on && !wl && navigator.wakeLock) { wl = await navigator.wakeLock.request('screen'); wl.addEventListener('release', () => { wl = null; }); }
    else if (!on && wl) { await wl.release(); wl = null; }
  } catch (e) { wl = null; }
}

/* ---------------- lembretes ---------------- */
function reminderList(k) {
  const p = prof(), r = p.reminders, out = [];
  const wake = L.minutesOf(p.wakeTime), bed = L.minutesOf(p.bedTime);
  const day = () => MEMO().days[k] || {};
  if (r.wake && wake != null) out.push({ id: 'wake', time: p.wakeTime, title: 'Bom dia. Hora de levantar', body: 'Primeiro copo de água e bora. ' + phraseOf(k), btn: { label: 'Começar o dia', act: 'sheet', data: { s: 'comecarDia' } }, skip: () => !!day().started });
  if (r.weigh !== false && L.weekday(k) === Number(r.weighDay)) out.push({ id: 'weigh', time: r.weighTime || '07:00', title: 'Pesagem da semana', body: 'Depois do banheiro e antes de comer. O app acompanha a tendência, não o número de um dia.', btn: { label: 'Registrar peso', act: 'sheet', data: { s: 'peso' } }, skip: () => { const lw = lastWeigh(); return !!(lw && lw.date === k); } });
  if (r.checklist !== false) out.push({ id: 'checklist', time: r.checklistTime || '21:00', title: 'Checklist do dia', body: 'Um minuto para revisar: o que falta marcar hoje?', btn: { label: 'Ver checklist', act: 'goChecklist' }, skip: () => dayInfo(k).score >= 1 });
  if (r.photo !== false && wake != null) out.push({ id: 'photo', time: L.hm(wake + 10), title: 'Foto do dia', body: 'Mesmo lugar e mesma luz, antes de comer. Leva 20 segundos.', btn: { label: 'Tirar foto', act: 'photoAdd', data: { pose: 'frente' } }, skip: () => photoOn(k) });
  if (r.water && wake != null && bed != null) {
    let end = bed - 60; if (end <= wake) end += 1440;
    const every = Math.max(45, Number(r.waterEvery) || 120);
    for (let t = wake + every; t <= end; t += every) if (t < 1440) out.push({ id: 'water' + t, time: L.hm(t), title: 'Hora da água', body: 'Um copo agora. Um toque e está registrado.', btn: { label: '+250 ml', act: 'water', data: { ml: 250 } }, skip: () => (day().water || 0) >= p.waterGoal });
  }
  const plan = dayPlan(k);
  if (r.train && plan === 'gym') out.push({ id: 'train', time: p.trainTime, title: 'Hora do treino', body: phraseOf(k), btn: { label: 'Começar treino', act: 'startSession', data: { type: nextType() } }, skip: () => MEMO().trainedDates.has(k) || !!activeSession() });
  if (r.train && (plan === 'run' || k === runCfg().race.date)) {
    const rs = runSessionFor(k), s = rs ? sessionToRun(rs.s) : null;
    if (s) out.push({ id: 'train', time: p.trainTime, title: rs.race ? 'Dia da prova' : L.runSeconds(s.blocks) ? 'Hora da corrida' : 'Hora da caminhada', body: s.title, btn: { label: 'Começar sessão', act: 'runStart', data: { idx: rs.idx } }, skip: () => runsOn(k).length > 0 || !!(ui.run && ui.run.active) });
  }
  if (r.meals) {
    const mt = mealTimesAll(), menu = menuFor(k);
    C.MEALS6.forEach((m) => out.push({ id: 'meal-' + m.id, time: mt[m.id], title: `${m.label} · ${mt[m.id]}`, body: adaptFood(menu[m.id].t) + '.', btn: { label: 'Registrar refeição', act: 'sheet', data: { s: 'refeicao', m: m.id } }, skip: () => !!(day().meals || {})[m.id] }));
  }
  if (r.supps) {
    const groups = new Map();
    suppsOn(k).forEach((s) => { const t = suppTime(s); if (!groups.has(t)) groups.set(t, []); groups.get(t).push(s); });
    for (const [t, list] of groups) {
      out.push({ id: 'supp-' + t, time: t, title: list.length === 1 ? `Suplemento: ${list[0].name}` : 'Hora dos suplementos', body: list.map((s) => s.name + (s.dose ? ` (${s.dose})` : '')).join(' · '),
        btn: list.length === 1 ? { label: 'Marcar como tomado', act: 'suppTake', data: { id: list[0].id } } : { label: 'Ver suplementos', act: 'tabSub', data: { to: 'comida', sub: 'suplementos' } },
        skip: () => list.every((s) => suppTaken(k, s.id)) });
    }
  }
  if (r.sleep && bed != null) out.push({ id: 'winddown', time: L.hm(bed - 30), title: 'Hora de desacelerar', body: `Telas longe e luz baixa. Dormir às ${p.bedTime}.` });
  return out.filter((x) => L.minutesOf(x.time) != null).sort((a, b) => L.minutesOf(a.time) - L.minutesOf(b.time));
}
const daysText = (days) => (!days || !days.length || days.length === 7 ? 'todos os dias' : [1, 2, 3, 4, 5, 6, 0].filter((w) => days.includes(w)).map((w) => WD[w].toLowerCase()).join(', '));
/** lembretes fixos da semana (para alarmes do celular e para o calendário) */
function fixedReminders() {
  const p = prof(), r = p.reminders, mt = mealTimesAll(), wp = weekPlan(), out = [];
  const wake = L.minutesOf(p.wakeTime), bed = L.minutesOf(p.bedTime);
  const gym = [0, 1, 2, 3, 4, 5, 6].filter((w) => wp[w] === 'gym'), run = [0, 1, 2, 3, 4, 5, 6].filter((w) => wp[w] === 'run');
  if (r.wake && wake != null) out.push({ id: 'wake', time: p.wakeTime, title: 'Acordar', desc: 'Primeiro copo de água.', dur: 5 });
  if (r.photo !== false && wake != null) out.push({ id: 'photo', time: L.hm(wake + 10), title: 'Foto do dia', desc: 'Mesmo lugar e mesma luz, antes de comer.', dur: 5 });
  if (r.meals) C.MEALS6.forEach((m) => out.push({ id: 'meal-' + m.id, time: mt[m.id], title: m.label, desc: 'Inclua fruta ou fibra. O cardápio do dia está no Saúde Jr.', dur: 20 }));
  if (r.train && gym.length) out.push({ id: 'gym', time: p.trainTime, days: gym, title: 'Academia', desc: 'Abra o Saúde Jr. e comece o treino do dia.', dur: 60 });
  if (r.train && run.length) out.push({ id: 'run', time: p.trainTime, days: run, title: 'Corrida / caminhada', desc: 'Abra o Saúde Jr.: a sessão do dia tem avisos por voz a cada troca.', dur: 45 });
  if (r.supps) suppList().forEach((s) => out.push({ id: 'supp-' + s.id, time: suppTime(s), days: s.days && s.days.length && s.days.length < 7 ? s.days : null, title: s.name, desc: s.dose || '', dur: 5 }));
  if (r.weigh !== false) out.push({ id: 'weigh', time: r.weighTime || '07:00', days: [Number(r.weighDay) || 0], title: 'Pesagem da semana', desc: 'Depois do banheiro e antes de comer. Registre no Saúde Jr.', dur: 5 });
  if (r.checklist !== false) out.push({ id: 'checklist', time: r.checklistTime || '21:00', title: 'Checklist do dia', desc: 'Abra o Saúde Jr. e marque o que você fez hoje.', dur: 5 });
  if (r.sleep && bed != null) out.push({ id: 'wind', time: L.hm(bed - 30), title: 'Desacelerar para dormir', desc: `Telas longe. Dormir às ${p.bedTime}.`, dur: 30 });
  const key = (t) => { const m = L.minutesOf(t); return m < (wake ?? 0) - 120 ? m + 1440 : m; };
  return out.filter((x) => L.minutesOf(x.time) != null).sort((a, b) => key(a.time) - key(b.time));
}
function alarmsText() {
  return fixedReminders().map((e) => `${e.time} · ${e.title}${e.days ? ' — ' + daysText(e.days) : ''}`).join('\n');
}
const shownKey = (k) => 'mv1:shown:' + k;
function getShown(k) { try { return JSON.parse(localStorage.getItem(shownKey(k)) || '[]'); } catch (e) { return (ui.shown && ui.shown[k]) || []; } }
function markShown(k, ids) {
  const arr = getShown(k).concat(ids);
  try { localStorage.setItem(shownKey(k), JSON.stringify(arr)); } catch (e) { ui.shown = ui.shown || {}; ui.shown[k] = arr; }
}
function tickReminders() {
  if (!prof().onboarded || ui.route === 'onboarding') return;
  const k = today(), n = nowMin(), shown = new Set(getShown(k));
  const due = reminderList(k).filter((r) => { const t = L.minutesOf(r.time); return t != null && n >= t && n < t + 20 && !shown.has(r.id); });
  if (!due.length) return;
  markShown(k, due.map((r) => r.id));
  const fresh = due.filter((r) => !(r.skip && r.skip()));
  ui.alertQ = (ui.alertQ || []).concat(fresh);
  showNextReminder();
}
/** avisos esperam enquanto há uma folha aberta ou uma corrida ao vivo na tela */
const canAlert = () => !ui.sheet && ui.route !== 'corrida' && ui.route !== 'onboarding' && document.getElementById('alertbar').hidden;
function showNextReminder() {
  if (!canAlert()) return;
  const q = ui.alertQ || [], n = nowMin();
  while (q.length) {
    const r = q.shift(), t = L.minutesOf(r.time);
    if (t != null && n - t > 60) continue; // passou da hora: não avisa atrasado
    if (r.skip && r.skip()) continue; // já foi feito
    return showReminder(r);
  }
}
function suspendAlert() {
  const bar = document.getElementById('alertbar');
  if (!bar || bar.hidden) return;
  bar.hidden = true; clearTimeout(ui.alertT);
  if (ui.alertCur) (ui.alertQ = ui.alertQ || []).unshift(ui.alertCur);
  ui.alertCur = null;
}
function showReminder(r) {
  const bar = document.getElementById('alertbar');
  const more = (ui.alertQ || []).length;
  bar.innerHTML = `<div class="between"><span class="eyebrow go">${esc(r.time)} · Lembrete${more ? ` · +${more}` : ''}</span><button class="btn btn-icon btn-ghost" style="width:40px;min-height:40px" data-act="alertClose" aria-label="Fechar lembrete">${icon('x', 'ic-sm')}</button></div>
    <div class="h3">${esc(r.title)}</div><p class="small muted">${esc(r.body)}</p>${r.btn ? `<button class="btn btn-go btn-block btn-sm" data-act="alertAct" data-a="${r.btn.act}" ${attrs(r.btn.data)}>${esc(r.btn.label)}</button>` : ''}`;
  bar.hidden = false; ui.alertCur = r;
  beep(); vibrate([180, 90, 180]);
  try {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted' && document.hidden) {
      if (PWA && navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.ready.then((reg) => reg.showNotification(r.title, { body: r.body, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: r.id })).catch(() => {});
      else new Notification(r.title, { body: r.body });
    }
  } catch (e) { /* sem notificação do sistema */ }
  clearTimeout(ui.alertT); ui.alertT = setTimeout(() => { bar.hidden = true; ui.alertCur = null; setTimeout(showNextReminder, 800); }, 90000);
}
function closeAlert() { document.getElementById('alertbar').hidden = true; ui.alertCur = null; clearTimeout(ui.alertT); setTimeout(showNextReminder, 1200); }

/* ---------------- fotos e arquivos ---------------- */
async function getCap(name) {
  if (ui[name] !== undefined) return ui[name];
  try { ui[name] = window.claude && typeof window.claude.use === 'function' ? await window.claude.use(name) : null; } catch (e) { ui[name] = null; }
  return ui[name];
}
function compressImage(file, max, q) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => (b ? res(b) : rej(new Error('blob'))), 'image/jpeg', q);
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent || '') || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
async function offerFile(name, data, mime) {
  if (PWA) {
    const blob = new Blob([data], { type: mime || 'application/octet-stream' });
    if (isIOS() && navigator.canShare) {
      try { const f = new File([blob], name, { type: blob.type }); if (navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: name }); return; } }
      catch (e) { if (e && e.name === 'AbortError') return; }
    }
    const u = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = u; a.download = name; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 60000);
    toast('Arquivo baixado');
    return;
  }
  const dl = await getCap('downloads');
  if (dl) {
    try { await dl.save({ filename: name, data }); toast('Arquivo pronto'); return; }
    catch (e) { if (e && e.code === 'declined') return; }
  }
  openSheet('texto', { title: name, text: data });
}
/** link do Google Agenda com o lembrete já preenchido e repetição */
function gcalLink(e) {
  let k = today();
  if (e.days && e.days.length && e.days.length < 7) for (let j = 0; j < 7 && !e.days.includes(L.weekday(k)); j++) k = L.addDays(k, 1);
  const d = k.replace(/-/g, ''), m0 = L.minutesOf(e.time), m1 = Math.min(m0 + (e.dur || 15), 1439);
  const BY = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];
  const recur = e.days && e.days.length && e.days.length < 7 ? `RRULE:FREQ=WEEKLY;BYDAY=${e.days.map((x) => BY[x]).join(',')}` : 'RRULE:FREQ=DAILY';
  const q = new URLSearchParams({ action: 'TEMPLATE', text: 'Saúde Jr. · ' + e.title, dates: `${d}T${L.hm(m0).replace(':', '')}00/${d}T${L.hm(m1).replace(':', '')}00`, details: e.desc || '', recur });
  return 'https://calendar.google.com/calendar/render?' + q.toString();
}
function icsNow() { return new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); }

/* ---------------- ações ---------------- */
const num = (id) => L.num(($('#' + id) || {}).value);
function readOb() {
  const ob = ui.ob, d = ob.d, g = (id) => ($('#' + id) || {}).value;
  if (ob.step === 1) {
    d.name = (g('ob-name') || '').trim().slice(0, 40);
    d.age = num('ob-age'); d.height = num('ob-height'); d.startWeight = num('ob-weight'); d.waist = num('ob-waist'); d.goalWeight = num('ob-goal');
  } else if (ob.step === 2) {
    d.trainTime = g('ob-train') || d.trainTime; d.wakeTime = g('ob-wake') || d.wakeTime; d.bedTime = g('ob-bed') || d.bedTime;
    d.stepsGoal = num('ob-steps'); d.waterGoal = num('ob-water');
    d.activityLevel = g('ob-activity') || ''; d.trainPref = g('ob-pref') || '';
  }
}
function validOb() {
  const ob = ui.ob, d = ob.d;
  if (ob.step === 1) {
    if (!(d.startWeight >= 40 && d.startWeight <= 300)) return 'Confira o peso (entre 40 e 300 kg).';
    if (!(d.height >= 120 && d.height <= 230)) return 'Confira a altura em centímetros (ex.: 185).';
    if (!(d.age >= 14 && d.age <= 100)) return 'Confira a idade.';
    if (!(d.goalWeight >= 40 && d.goalWeight < d.startWeight)) return 'A meta precisa ser menor que o peso de hoje.';
    if (d.waist != null && !(d.waist >= 50 && d.waist <= 250)) return 'Confira a cintura em centímetros.';
  }
  if (ob.step === 2) {
    if (!(d.waterGoal >= 500 && d.waterGoal <= 8000)) return 'Escolha uma meta de água entre 500 e 8.000 ml.';
    if (!(d.stepsGoal >= 1000 && d.stepsGoal <= 40000)) return 'Escolha uma meta de passos entre 1.000 e 40.000.';
  }
  return null;
}
const PF_LIMITS = { age: [14, 100], height: [120, 230], startWeight: [40, 300], goalWeight: [40, 300], waterGoal: [500, 8000], stepsGoal: [1000, 40000] };

const ACT = {
  go: (d) => go(d.to),
  tab: (d) => go(d.to),
  tabSub: (d) => { ui.sub[d.to] = d.sub; go(d.to); },
  seg: (d) => {
    if (d.group === 'range') ui.chartRange = d.v === 'all' ? 'all' : Number(d.v);
    else if (d.group === 'agendaDay') ui.agendaDay = d.v;
    else if (d.group === 'sumRange') ui.sumRange = d.v;
    else { ui.sub[d.group] = d.v; if (ui.route !== d.group) { ui.route = d.group; } }
    render();
  },
  scrollTo: (d) => { const el = document.getElementById(d.id); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); },
  sheet: (d) => openSheet(d.s, d),
  closeSheet: () => closeSheet(),
  nudge: (d) => {
    const el = document.getElementById(d.for); if (!el) return;
    const cur = L.num(el.value) || 0, step = Number(d.d);
    const dec = String(d.d).includes('.') || !Number.isInteger(cur) ? 1 : 0;
    el.value = Math.max(0, cur + step).toFixed(dec).replace('.', ',');
    el.dispatchEvent(new Event('input', { bubbles: true }));
  },
  pick: (d, el) => {
    const grp = document.getElementById(d.group); if (!grp) return;
    const was = el.getAttribute('aria-pressed') === 'true';
    grp.querySelectorAll('[aria-pressed]').forEach((b) => b.setAttribute('aria-pressed', 'false'));
    if (!was || d.group === 'cd-kind') el.setAttribute('aria-pressed', 'true');
    if (d.then && INP[d.then]) INP[d.then]();
  },
  copyText: (d) => {
    const el = document.getElementById(d.for); if (!el) return;
    const txt = el.value != null && el.tagName === 'TEXTAREA' ? el.value : el.textContent;
    const fallback = () => { try { if (el.select) el.select(); else { const r = document.createRange(); r.selectNodeContents(el); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); } } catch (e) { /* ok */ } toast('Texto selecionado: copie pelo menu'); };
    try { navigator.clipboard.writeText(txt).then(() => toast('Copiado'), fallback); } catch (e) { fallback(); }
  },
  copyAlarms: () => ACT.copyText({ for: 'alarmsText' }),

  /* checklist e registros rápidos */
  check: (d) => {
    const k = today(), info = dayInfo(k);
    dayUpdate((day) => { day.checks = Object.assign({}, day.checks); day.checks[d.k] = !info.st[d.k]; });
    vibrate(15);
  },
  water: (d) => addWater(Number(d.ml) || 250),
  waterUndo: () => {
    const k = today(), day = dayW(k), log = day.waterLog || [];
    if (!log.length) return toast('Nada para desfazer');
    const last = log.pop();
    day.water = Math.max(0, (day.water || 0) - last);
    save(monthId(k)); render(); toast(`−${fmt0(last)} ml`);
  },
  waterCustom: () => { const v = num('wa-ml'); if (!(v >= 50 && v <= 3000)) return toast('Informe entre 50 e 3.000 ml'); closeSheet(); addWater(Math.round(v)); },
  saveWaterGoal: () => { const v = num('wa-goal'); if (!(v >= 500 && v <= 8000)) return toast('Escolha entre 500 e 8.000 ml'); P().waterGoal = Math.round(v); save('profile'); closeSheet(); render(); toast('Meta de água atualizada'); },
  saveWeight: () => {
    const v = num('w-kg'), dt = ($('#w-date') || {}).value || today();
    if (!(v >= 40 && v <= 300)) return toast('Confira o peso (entre 40 e 300 kg)');
    if (dt > today()) return toast('A data não pode ser no futuro');
    const before = phaseGoal();
    const m = MON(dt);
    m.weights = m.weights.filter((w) => w.date !== dt).concat({ date: dt, kg: L.round1(v), at: Date.now() });
    save(monthId(dt)); closeSheet(); render();
    const after = phaseGoal();
    toast(before && after !== before ? `Meta da fase batida: ${fmtKg(before)} kg!` : `Peso salvo: ${fmt1(v)} kg`);
  },
  saveMeasures: () => {
    const w = num('m-waist'), h = num('m-hip'), a = num('m-arm'), c = num('m-chest'), dt = ($('#m-date') || {}).value || today();
    if (w == null && h == null && a == null && c == null) return toast('Preencha pelo menos uma medida');
    if (w != null && !(w >= 50 && w <= 250)) return toast('Confira a cintura em cm');
    if (h != null && !(h >= 50 && h <= 250)) return toast('Confira o quadril em cm');
    if (a != null && !(a >= 15 && a <= 90)) return toast('Confira o braço em cm');
    if (c != null && !(c >= 50 && c <= 250)) return toast('Confira o peito em cm');
    if (dt > today()) return toast('A data não pode ser no futuro');
    const m = MON(dt), r1 = (v) => (v != null ? L.round1(v) : null);
    m.measures = m.measures.filter((x) => x.date !== dt).concat({ date: dt, waist: r1(w), hip: r1(h), arm: r1(a), chest: r1(c), at: Date.now() });
    save(monthId(dt)); closeSheet(); render(); toast('Medidas salvas');
  },
  saveStartDay: () => {
    const bed = ($('#sd-bed') || {}).value, wake = ($('#sd-wake') || {}).value, h = L.sleepHours(bed, wake);
    if (h != null && (h < 1 || h > 16)) return toast('Confira os horários do sono');
    const q = Number(pressedIn('sd-q')) || null, e = Number(pressedIn('sd-e')) || null;
    const kg = num('sd-kg');
    if (kg != null && !(kg >= 40 && kg <= 300)) return toast('Confira o peso (entre 40 e 300 kg)');
    const sw = $('#sd-water'), water = !!(sw && sw.getAttribute('aria-checked') === 'true');
    const k = today(), day = dayW(k);
    if (h != null) day.sleep = Object.assign({}, day.sleep, { bed, wake, hours: h, quality: q || (day.sleep || {}).quality || null, energy: e || (day.sleep || {}).energy || null });
    else if (e) day.sleep = Object.assign({}, day.sleep, { energy: e });
    if (water) { day.water = (day.water || 0) + 250; day.waterLog = (day.waterLog || []).concat(250).slice(-60); }
    day.started = Date.now();
    if (kg != null) { const m = MON(k); m.weights = m.weights.filter((x) => x.date !== k).concat({ date: k, kg: L.round1(kg), at: Date.now() }); }
    save(monthId(k)); closeSheet(); render();
    toast('Dia começado. Bora!');
    vibrate([40, 30, 40]);
    const now = document.querySelector('.card-now'); if (now) now.scrollIntoView({ behavior: 'smooth', block: 'center' });
  },
  addSugMarmita: (d) => {
    const s = C.MARMITA_SUGESTOES[Number(d.i)]; if (!s) return;
    const c = CORE();
    if (c.marmitas.some((m) => m.name === s.name)) return toast('Essa marmita já está na lista');
    c.marmitas.push({ id: uidGen('mm'), name: s.name, protFood: s.protFood, protG: s.protG, protOther: '', carbFood: s.carbFood, carbG: s.carbG, carbOther: '', vegFood: s.vegFood, vegG: s.vegG, vegOther: '', qty: s.protG + s.carbG + s.vegG, kcal: null, prot: null });
    save('core'); render(); toast('Marmita adicionada');
  },
  addSteps: (d) => { const el = $('#st-n'); el.value = (L.num(el.value) || 0) + Number(d.n); },
  saveSteps: () => {
    const v = num('st-n');
    if (!(v >= 0 && v <= 100000)) return toast('Confira o número de passos');
    closeSheet();
    dayUpdate((day) => { day.steps = Math.round(v); }, v >= prof().stepsGoal ? 'Meta de passos batida!' : `${fmt0(v)} passos registrados`);
  },
  saveSleep: () => {
    const bed = $('#sl-bed').value, wake = $('#sl-wake').value, h = L.sleepHours(bed, wake);
    if (h == null) return toast('Informe os horários');
    if (h < 1 || h > 16) return toast('Confira os horários: a duração ficou estranha');
    const q = Number(pressedIn('sl-q')) || null, e = Number(pressedIn('sl-e')) || null;
    const notes = (($('#sl-notes') || {}).value || '').trim().slice(0, 300);
    closeSheet();
    dayUpdate((day) => { day.sleep = Object.assign({}, day.sleep, { bed, wake, hours: h, quality: q, energy: e, notes: notes || null }); }, h >= 7 ? `Sono salvo: ${fmt1(h)} h` : `Sono salvo: ${fmt1(h)} h. Hoje, tente deitar 30 min mais cedo.`);
  },
  dayEnergy: (d) => { closeSheet(); dayUpdate((day) => { day.sleep = Object.assign({}, day.sleep, { day: Number(d.v) }); }, `Energia de hoje: ${d.v}/10`); },
  saveCardio: () => {
    const kind = pressedIn('cd-kind') || 'esteira', min = num('cd-min'), km = num('cd-km'), spd = num('cd-spd'), rpe = Number($('#cd-rpe').value), kIn = num('cd-kcal');
    if (!(min >= 1 && min <= 300)) return toast('Informe o tempo em minutos');
    const speed = spd || (km && min ? km / (min / 60) : null), dist = km || (spd ? (spd * min) / 60 : null);
    const kcalAuto = L.kcal(L.cardioMET(kind, speed, rpe), curWeight(), min);
    const k = today();
    MON(k).cardio.push({ id: uidGen('c'), date: k, at: Date.now(), kind, minutes: Math.round(min), km: dist ? L.round1(dist) : null, speed: speed ? L.round1(speed) : null, rpe, kcal: kIn > 0 ? Math.round(kIn) : kcalAuto, kcalSrc: kIn > 0 ? 'aparelho' : 'estimativa' });
    ui.lastCardioKind = kind;
    save(monthId(k)); closeSheet(); render();
    toast(rpe >= 9 ? 'Salvo. Nesta fase, prefira esforço entre 3 e 6.' : `Cardio salvo: ${Math.round(min)} min`);
  },
  askDelCardio: (d) => openSheet('confirm', { title: 'Apagar este cardio?', text: 'O registro sai do histórico e da semana.', ok: 'delCardio', okData: { id: d.id }, okLabel: 'Apagar', danger: true }),
  delCardio: (d) => {
    for (const id of Store.ids().filter((x) => /^m-/.test(x))) {
      const m = Store.peek(id);
      if (m && m.cardio && m.cardio.some((c) => c.id === d.id)) { m.cardio = m.cardio.filter((c) => c.id !== d.id); save(id); }
    }
    closeSheet(); render(); toast('Cardio apagado');
  },
  meal: (d) => dayUpdate((day) => { day.meals = Object.assign({}, day.meals); if (day.meals[d.m] === d.v) delete day.meals[d.m]; else day.meals[d.m] = d.v; }, d.v === 'fora' ? 'Registrado. Próxima refeição é nova chance.' : 'Refeição registrada'),
  dinner: (d) => dayUpdate((day) => { day.dinner = day.dinner === d.id ? null : d.id; }, 'Jantar de hoje definido'),
  saveMarmita: (d) => {
    const m = readMarmitaForm();
    if (!m.name) return toast('Dê um nome para a marmita');
    if (!m.protFood && !m.carbFood && !m.vegFood) return toast('Escolha pelo menos um componente');
    for (const g of [m.protG, m.carbG, m.vegG, m.qty]) if (g != null && !(g >= 0 && g <= 2000)) return toast('Confira os gramas');
    const c = CORE();
    if (d.id) { const i = c.marmitas.findIndex((x) => x.id === d.id); if (i >= 0) c.marmitas[i] = Object.assign({ id: d.id }, m); }
    else c.marmitas.push(Object.assign({ id: uidGen('mm') }, m));
    save('core'); closeSheet(); ui.sub.comida = 'marmita'; render(); toast('Marmita salva');
  },
  askDelMarmita: (d) => openSheet('confirm', { title: 'Excluir marmita?', text: 'Ela sai da sua lista. Registros antigos continuam.', ok: 'delMarmita', okData: { id: d.id }, okLabel: 'Excluir', danger: true }),
  delMarmita: (d) => { const c = CORE(); c.marmitas = c.marmitas.filter((x) => x.id !== d.id); save('core'); closeSheet(); render(); toast('Marmita excluída'); },
  gut: (d) => dayUpdate((day) => { day.gut = Object.assign({}, day.gut); day.gut[d.f] = L.clamp((day.gut[d.f] || 0) + Number(d.d), 0, 20); }),
  gutSet: (d) => dayUpdate((day) => {
    day.gut = Object.assign({}, day.gut);
    const v = d.f === 'bm' ? d.v === '1' : d.f === 'form' ? d.v : Number(d.v);
    if (day.gut[d.f] === v) delete day.gut[d.f]; else day.gut[d.f] = v;
    if (d.f === 'bm' && day.gut.bm !== true) delete day.gut.form;
  }),
  gutFlag: (d) => dayUpdate((day) => { day.gut = Object.assign({}, day.gut); day.gut.flags = Object.assign({}, day.gut.flags); day.gut.flags[d.f] = !day.gut.flags[d.f]; }),
  sleepSign: (d) => { const p = P(); p.sleepSigns = Object.assign({}, p.sleepSigns); p.sleepSigns[d.f] = !p.sleepSigns[d.f]; save('profile'); render(); },
  alcohol: (d) => dayUpdate((day) => { day.alcohol = Number(d.v); }, 'Registrado'),
  stress: (d) => dayUpdate((day) => { day.stress = day.stress === Number(d.v) ? null : Number(d.v); }),
  mark: (d) => {
    if (d.auto) return toast('Esse marco se marca sozinho pelos seus registros');
    const c = CORE(); if (c.marks[d.id]) delete c.marks[d.id]; else c.marks[d.id] = today();
    save('core'); render(); if (c.marks[d.id]) toast('Marco conquistado!');
  },
  saveGoal: () => {
    const v = num('g-kg'), p = prof();
    if (!(v >= 40 && v < p.startWeight)) return toast('A meta precisa ser menor que o peso inicial');
    P().goalWeight = L.round1(v); save('profile'); closeSheet(); render(); toast('Meta atualizada');
  },
  goalPhotos: (d) => { P().showGoalPhotos = d.v === '1'; save('profile'); render(); },

  /* sessão */
  startSession: (d) => startSession(d.type || nextType()),
  resumeSession: () => { const s = S(); if (!s) return render(); ui.route = 'sessao'; ui.openEx = nextOpen(s, -1); render(); wakeLock(true); },
  sessLeave: () => { stopRest(); wakeLock(false); go('home'); toast('Treino continua salvo. Volte quando quiser.'); },
  warmup: () => { const s = S(); if (!s) return; s.warmupDone = !s.warmupDone; save(monthId(s.date)); render(); },
  exToggle: (d) => { const i = Number(d.i); ui.openEx = ui.openEx === i ? -1 : i; if (ui.openEx === i) ui.scrollEx = i; render(); },
  exLoad: (d) => { const s = S(), it = itemOf(d); if (!it) return; const step = it.inc || 1; it.load = Math.max(0, Math.round(((it.load || 0) + Number(d.d) * step) * 10) / 10); save(monthId(s.date)); render(); },
  setReps: (d) => { const s = S(), it = itemOf(d); if (!it) return; const st = it.sets[Number(d.j)], step = it.kind === 'time' ? 5 : 1; st.reps = L.clamp((st.reps || 0) + Number(d.d) * step, 1, 300); save(monthId(s.date)); render(); },
  setDone: (d) => {
    const s = S(), it = itemOf(d); if (!it) return;
    const st = it.sets[Number(d.j)];
    st.done = !st.done;
    const all = it.sets.every((x) => x.done);
    it.done = all;
    save(monthId(s.date)); render();
    if (st.done) {
      vibrate(20);
      const lastOfSession = all && s.items.every((x) => x.done);
      if (!lastOfSession) startRest(it.rest);
      if (all) toast('Exercício feito. Marque “Como foi?” e conclua.');
    }
  },
  exDiff: (d) => { const s = S(), it = itemOf(d); if (!it) return; const v = Number(d.v); it.difficulty = it.difficulty === v ? null : v; save(monthId(s.date)); render(); },
  exDone: (d) => {
    const s = S(), it = itemOf(d); if (!it) return;
    const i = Number(d.i), wasDone = it.done;
    it.sets.forEach((x) => { x.done = true; });
    it.done = true;
    const nx = nextOpen(s, i);
    ui.openEx = nx; ui.scrollEx = nx >= 0 ? nx : null;
    save(monthId(s.date)); render();
    if (nx >= 0 && !wasDone) startRest(it.rest);
    if (nx < 0) toast('Todos os exercícios feitos. Finalize o treino!');
  },
  swapEx: (d) => {
    const s = S(); if (!s) return;
    const i = Number(d.i), old = s.items[i], exId = d.ex;
    if (!old || !C.EX[exId]) return;
    if (exId !== old.exId) {
      const slot = [...C.PROGRAM.A.slots, ...C.PROGRAM.B.slots].find((x) => x.id === old.slotId);
      const cfg = C.weekConfig(s.week);
      const reps = s.type === 'R' ? (C.EX[exId].kind === 'time' ? cfg.core[1] : C.QUICK.reps) : repsFor(exId, slot ? slot.role : 'acc', cfg);
      s.items[i] = makeItem(exId, old.slotId, old.sets.length, reps, old.rest);
      if (old.slotId && (s.type === 'A' || s.type === 'B')) { const c = CORE(); c.choice[old.slotId] = exId; save('core'); }
      save(monthId(s.date));
      toast(`Trocado por ${C.EX[exId].name}`);
    }
    closeSheet(); render();
  },
  sessFinishAsk: () => {
    const s = S(); if (!s) return;
    const st = sessionStats(s);
    const anySet = s.items.some((it) => it.sets.some((x) => x.done));
    if (!anySet) return openSheet('confirm', { title: 'Nenhuma série feita', text: 'Quer descartar este treino? Se preferir, faça ao menos o treino rápido: 20 minutos contam.', ok: 'sessDiscard', okLabel: 'Descartar', danger: true, cancel: 'Continuar' });
    if (st.done < st.total) return openSheet('confirm', { title: `Finalizar com ${st.done} de ${st.total}?`, text: 'Tudo bem terminar antes: o que foi feito conta. Exercícios sem séries feitas não mudam suas cargas.', ok: 'sessFinish', okLabel: 'Finalizar', cancel: 'Continuar treinando' });
    finishNow();
  },
  sessFinish: () => finishNow(),
  sessDiscard: () => {
    const s = S(); if (!s) return closeSheet();
    const m = MON(s.date); m.sessions = m.sessions.filter((x) => x.id !== s.id);
    save(monthId(s.date)); stopRest(); wakeLock(false); closeSheet(); go('treino'); toast('Treino descartado');
  },
  finishDone: () => { ui.finish = null; go('home'); },
  restAdd: () => { rest.until += 15000; rest.total += 15; tickRest(); },
  restSkip: () => stopRest(),

  /* cadastro inicial */
  obNext: () => {
    const ob = ui.ob; readOb();
    const err = validOb(); if (err) return toast(err);
    ob.step = Math.min(3, ob.step + 1); render();
  },
  obBack: () => { readOb(); ui.ob.step = Math.max(0, ui.ob.step - 1); render(); },
  obDay: (d, el) => {
    const w = Number(d.w), set = new Set(ui.ob.d.trainDays);
    if (set.has(w)) set.delete(w); else set.add(w);
    ui.ob.d.trainDays = [...set];
    el.setAttribute('aria-pressed', String(set.has(w)));
  },
  obSafety: (d, el) => { const s = ui.ob.safety; s[d.q] = !s[d.q]; el.setAttribute('aria-checked', String(s[d.q])); },
  obFinish: () => {
    const ob = ui.ob, d = ob.d, k = today();
    const flag = Object.values(ob.safety).some(Boolean);
    const p = P();
    Object.assign(p, {
      name: d.name, age: d.age, height: d.height, startWeight: L.round1(d.startWeight), goalWeight: L.round1(d.goalWeight),
      trainDays: d.trainDays.length ? d.trainDays : [1, 3, 5], trainTime: d.trainTime, wakeTime: d.wakeTime, bedTime: d.bedTime,
      waterGoal: Math.round(d.waterGoal), stepsGoal: Math.round(d.stepsGoal), activityLevel: d.activityLevel || '', trainPref: d.trainPref || '',
      onboarded: true, startDate: k, safety: { answers: Object.assign({}, ob.safety), flag, date: k, cleared: false }, week: null,
    });
    const m = MON(k);
    m.weights = m.weights.filter((w) => w.date !== k).concat({ date: k, kg: L.round1(d.startWeight), at: Date.now() });
    if (d.waist) m.measures = m.measures.filter((x) => x.date !== k).concat({ date: k, waist: L.round1(d.waist), hip: null, at: Date.now() });
    CORE();
    save('profile', 'core', monthId(k));
    ui.ob = null; ui.route = 'home'; render();
    toast(flag ? 'Pronto. Leia o aviso de segurança no topo.' : 'Pronto. A virada começou.');
  },

  /* segurança e perfil */
  safetyQ: (d) => {
    const p = P(), s = Object.assign({ answers: {} }, prof().safety);
    s.answers = Object.assign({}, s.answers); s.answers[d.q] = !s.answers[d.q];
    const flag = Object.values(s.answers).some(Boolean);
    if (flag && !s.flag) s.cleared = false;
    s.flag = flag; s.date = today(); p.safety = s; save('profile'); render();
  },
  safetyCleared: () => { const p = P(), s = Object.assign({ answers: {} }, prof().safety); s.cleared = !s.cleared; p.safety = s; save('profile'); render(); if (s.cleared) toast('Ótimo. Siga com progressão gradual.'); },
  trainDay: (d) => {
    const w = Number(d.w), set = new Set(prof().trainDays);
    if (set.has(w)) set.delete(w); else set.add(w);
    P().trainDays = [...set]; save('profile'); render();
    if (set.size > 5) toast('Na Fase 1, 3 dias bastam. Descanso também é treino.');
  },
  equip: (d) => {
    const set = new Set(prof().equipment);
    if (set.has(d.id)) set.delete(d.id); else set.add(d.id);
    P().equipment = [...set]; save('profile'); render();
  },
  pref: (d) => { const p = P(); p.prefs = Object.assign({}, prof().prefs); p.prefs[d.f] = !p.prefs[d.f]; save('profile'); render(); },
  remToggle: (d) => { const p = P(); p.reminders = Object.assign({}, prof().reminders); p.reminders[d.f] = !p.reminders[d.f]; save('profile'); render(); },
  testReminder: () => {
    const k = today();
    try { if (PWA && typeof Notification !== 'undefined' && Notification.permission === 'granted' && navigator.serviceWorker) navigator.serviceWorker.ready.then((reg) => reg.showNotification('Saúde Jr. · Hora do treino', { body: phraseOf(k), icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: 'teste' })).catch(() => {}); } catch (e) { /* sem notificação do sistema */ }
    showReminder({ time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), title: 'Hora do treino', body: phraseOf(k), btn: { label: 'Começar treino', act: 'startSession', data: { type: nextType() } } });
  },
  notifPerm: async () => {
    if (typeof Notification === 'undefined') return toast('Este navegador não oferece notificações aqui');
    try { const r = await Notification.requestPermission(); toast(r === 'granted' ? 'Notificações ativadas' : 'Notificações não permitidas nesta janela'); }
    catch (e) { toast('Notificações indisponíveis nesta janela'); }
    render();
  },
  alertClose: () => closeAlert(),
  alertAct: (d) => { closeAlert(); if (ACT[d.a]) ACT[d.a](d); },

  /* fotos e dados */
  photoAdd: (d) => {
    ui.photoPose = d.pose || 'frente';
    const inp = document.getElementById('photoInput');
    if (!inp) return toast('Fotos indisponíveis aqui');
    if (!PWA && ui.assets === undefined) getCap('assets');
    inp.click();
  },
  askDelPhoto: (d) => openSheet('confirm', { title: 'Apagar esta foto?', text: 'A foto é removida para sempre.', ok: 'delPhoto', okData: { id: d.id }, okLabel: 'Apagar', danger: true }),
  delPhoto: (d) => {
    const c = CORE(), ph = c.photos.find((x) => x.id === d.id);
    c.photos = c.photos.filter((x) => x.id !== d.id); save('core');
    removePhotoBlob(ph);
    closeSheet(); render(); toast('Foto apagada');
  },
  exportJson: () => offerFile(`saude-jr-backup-${today()}.json`, JSON.stringify(Store.exportAll(), null, 2), 'application/json'),
  exportCsv: () => {
    const rows = [['data', 'peso_kg', 'tendencia_kg'], ...MEMO().trend.map((p) => [p.date, fmt1(p.kg), fmt1(p.trend)])];
    offerFile(`saude-jr-pesos-${today()}.csv`, rows.map((r) => r.join(';')).join('\n'), 'text/csv');
  },
  askReset: () => openSheet('confirm', { title: 'Apagar todos os dados?', text: 'Perfil, pesos, medidas, treinos, fotos, marmitas e registros serão apagados da sua conta e deste aparelho. Não dá para desfazer. Se quiser, faça um backup antes.', ok: 'doReset', okLabel: 'Apagar tudo', danger: true }),
  doReset: async () => {
    const photos = allPhotoMetas();
    if (CLOUD && ui.photoStore) { try { await ui.photoStore.remove(photos.filter((p) => p.src === 'sb' && !p.pending && p.path).map((p) => p.path)); } catch (e) { /* segue: arquivos órfãos não são visíveis para ninguém */ } }
    if (Photos && Photos.available) for (const p of photos) { if (p.src === 'sb' || p.src === 'local') { try { await Photos.del(p.id); } catch (e) { /* ok */ } } }
    await Store.resetAll(); invalidate(); closeSheet(); stopRest(); obInit(); ui.route = 'onboarding'; render(); toast('Dados apagados');
  },
  goChecklist: () => { go('home'); setTimeout(() => ACT.scrollTo({ id: 'hoje' }), 60); },
  askRestart: () => openSheet('confirm', { title: 'Recomeçar a Fase 1?', text: 'O programa volta para a semana 1 a partir de hoje. Seus registros e cargas continuam salvos.', ok: 'doRestart', okLabel: 'Recomeçar' }),
  doRestart: () => { P().startDate = today(); save('profile'); closeSheet(); render(); toast('Fase 1 recomeça hoje'); },
  skipCloud: () => { if (ui.route !== 'splash') return; if (prof().onboarded) ui.route = 'home'; else { obInit(); ui.route = 'onboarding'; } render(); },

  /* agenda e semana */
  agendaCheck: (d) => {
    if (ui.route === 'agenda' && ui.agendaDay === 'amanha') return toast('Isso é amanhã. Marque no dia.');
    const k = today(), id = d.id, kind = d.kind, dd = MEMO().days[k] || {};
    if (kind === 'meal') {
      const m = id.slice(5), was = !!(dd.meals || {})[m];
      dayUpdate((day) => { day.meals = Object.assign({}, day.meals); if (was) delete day.meals[m]; else day.meals[m] = 'ok'; }, was ? 'Desmarcado' : 'Refeição registrada');
      return vibrate(15);
    }
    if (kind === 'supp') return ACT.suppTake({ id: id.slice(5) });
    if (kind === 'photo') return photoOn(k) ? toast('Foto de hoje já salva') : ACT.photoAdd({ pose: 'frente' });
    if (kind === 'gym' && MEMO().trainedDates.has(k)) return toast('Treino de hoje já registrado');
    if (kind === 'run' && runsOn(k).length) return toast('Sessão de hoje já registrada');
    if (kind === 'wake' && dd.sleep) return toast('Sono de hoje já registrado');
    const was = !!(dd.agenda || {})[id];
    dayUpdate((day) => {
      day.agenda = Object.assign({}, day.agenda);
      if (was) delete day.agenda[id]; else day.agenda[id] = true;
      if (kind === 'gym' || kind === 'run') { day.checks = Object.assign({}, day.checks); if (was) delete day.checks.treino; else day.checks.treino = true; }
    }, was ? 'Desmarcado' : kind === 'gym' || kind === 'run' ? 'Treino marcado como feito' : 'Feito');
    vibrate(15);
  },
  weekSet: (d) => {
    const w = Number(d.w), p = P(), wk = Object.assign({}, weekPlan());
    if (wk[w] === d.v) return;
    wk[w] = d.v;
    p.week = wk;
    p.trainDays = Object.keys(wk).map(Number).filter((x) => wk[x] !== 'rest');
    save('profile'); render();
    if (p.trainDays.length >= 7) toast('Reserve ao menos 1 dia de descanso');
  },
  weekSuggest: () => {
    const p = P();
    p.week = { 0: 'run', 1: 'gym', 2: 'run', 3: 'rest', 4: 'gym', 5: 'run', 6: 'rest' };
    p.trainDays = [0, 1, 2, 4, 5]; p.weekTip = false;
    save('profile'); render(); toast('Semana montada: 3 de corrida e 2 de academia');
  },
  weekTipOff: () => { P().weekTip = false; save('profile'); render(); },
  toggleChip: (d, el) => { el.setAttribute('aria-pressed', String(el.getAttribute('aria-pressed') !== 'true')); },
  toggleSwitch: (d, el) => { el.setAttribute('aria-checked', String(el.getAttribute('aria-checked') !== 'true')); },
  saveBloco: (d) => {
    const label = (($('#bl-label') || {}).value || '').trim().slice(0, 40), time = ($('#bl-time') || {}).value || '', end = ($('#bl-end') || {}).value || '';
    if (!label) return toast('Dê um nome ao bloco');
    if (!/^\d{2}:\d{2}$/.test(time)) return toast('Informe o horário de início');
    if (end && end === time) return toast('O fim precisa ser diferente do início');
    const days = [...document.querySelectorAll('#bl-days [aria-pressed="true"]')].map((b) => Number(b.dataset.w));
    if (!days.length) return toast('Escolha pelo menos um dia');
    const p = P(), list = (prof().custom || []).slice(), v = { label, time, end: end || null, days };
    if (d.id) { const i = list.findIndex((x) => x.id === d.id); if (i >= 0) list[i] = Object.assign({ id: d.id }, v); }
    else list.push(Object.assign({ id: uidGen('bl') }, v));
    p.custom = list; save('profile'); closeSheet(); render(); toast('Bloco salvo na agenda');
  },
  delBloco: (d) => { const p = P(); p.custom = (prof().custom || []).filter((x) => x.id !== d.id); save('profile'); closeSheet(); render(); toast('Bloco excluído'); },

  /* refeições e suplementos */
  saveMealTimes: () => {
    const pr = prof(), def = L.defaultMealTimes(pr.wakeTime, pr.trainTime, pr.bedTime), mt = {};
    for (const m of C.MEALS6) {
      const v = ($('#mt-' + m.id) || {}).value || '';
      if (!/^\d{2}:\d{2}$/.test(v)) return toast('Confira os horários');
      if (v !== def[m.id]) mt[m.id] = v;
    }
    const order = C.MEALS6.map((m) => L.minutesOf(mt[m.id] || def[m.id]));
    if (order.some((t, i) => i && t <= order[i - 1])) return toast('Coloque os horários em ordem, do café à ceia');
    P().mealTimes = mt; save('profile'); closeSheet(); render(); toast('Horários salvos');
  },
  resetMealTimes: () => { P().mealTimes = {}; save('profile'); closeSheet(); render(); toast('Horários sugeridos de volta'); },
  suppTake: (d) => {
    const k = today(), c = CORE(), s = c.supps.find((x) => x.id === d.id);
    if (!s) return;
    const was = suppTaken(k, s.id), per = Number(s.perDose) || 1;
    if (s.stock != null && s.stock !== '' && isFinite(Number(s.stock))) { s.stock = Math.max(0, Math.round((Number(s.stock) + (was ? per : -per)) * 100) / 100); save('core'); }
    const day = dayW(k); day.supps = Object.assign({}, day.supps);
    if (was) delete day.supps[s.id]; else day.supps[s.id] = Date.now();
    save(monthId(k)); render();
    if (was) return toast('Desmarcado');
    vibrate(15);
    const left = L.suppDaysLeft(s);
    toast(left != null && left <= 7 ? `${s.name}: estoque para ${left} dia${left === 1 ? '' : 's'}. Hora de repor.` : `${s.name} marcado`);
  },
  suppTpl: (d) => {
    const t = C.SUPP_TEMPLATES[Number(d.i)]; if (!t) return;
    const set = (id, v) => { const el = $('#' + id); if (el) el.value = v; };
    set('sp-name', t.name); set('sp-dose', t.dose); set('sp-unit', t.unit);
  },
  saveSupp: (d) => {
    const g = (id) => (($('#' + id) || {}).value || '').trim();
    const name = g('sp-name').slice(0, 40); if (!name) return toast('Dê um nome ao suplemento');
    const when = g('sp-when'), time = g('sp-time');
    if (when === 'hora' && !/^\d{2}:\d{2}$/.test(time)) return toast('Informe o horário');
    const days = [...document.querySelectorAll('#sp-days [aria-pressed="true"]')].map((b) => Number(b.dataset.w));
    if (!days.length) return toast('Escolha pelo menos um dia');
    const stockRaw = g('sp-stock'), stock = stockRaw === '' ? null : L.num(stockRaw);
    if (stockRaw !== '' && !(stock >= 0 && stock <= 100000)) return toast('Confira o estoque');
    const per = g('sp-per') === '' ? 1 : L.num(g('sp-per'));
    if (!(per > 0 && per <= 1000)) return toast('Confira quanto sai por dose');
    const v = { name, dose: g('sp-dose').slice(0, 40), meal: when === 'hora' ? null : when, time: when === 'hora' ? time : null, days, stock, unit: g('sp-unit').slice(0, 20) || 'doses', perDose: per, by: g('sp-by'), notes: g('sp-notes').slice(0, 300) };
    const c = CORE();
    if (d.id) { const i = c.supps.findIndex((x) => x.id === d.id); if (i >= 0) c.supps[i] = Object.assign({}, c.supps[i], v); }
    else c.supps.push(Object.assign({ id: uidGen('sp'), created: today() }, v));
    save('core'); closeSheet(); ui.sub.comida = 'suplementos'; render(); toast('Suplemento salvo');
  },
  askDelSupp: (d) => openSheet('confirm', { title: 'Excluir suplemento?', text: 'Ele sai da agenda e dos lembretes. O histórico dos dias continua.', ok: 'delSupp', okData: { id: d.id }, okLabel: 'Excluir', danger: true }),
  delSupp: (d) => { const c = CORE(); c.supps = c.supps.filter((x) => x.id !== d.id); save('core'); closeSheet(); render(); toast('Suplemento excluído'); },

  /* plano mensal da academia */
  monthKeep: () => {
    const k = today(), c = CORE(), prev = c.monthPlans[prevMonthKey(k)];
    if (!prev) return;
    c.monthPlans[L.monthKey(k)] = JSON.parse(JSON.stringify(prev)); save('core'); render(); toast('Plano mantido para este mês');
  },
  monthDefault: () => { const c = CORE(); c.monthPlans[L.monthKey(today())] = false; save('core'); if (ui.route === 'planoMes') ui.route = 'treino'; render(); toast('Usando a sugestão do app para a sua fase'); },
  savePlanItem: (d) => {
    const k = today(), c = CORE(), mk = L.monthKey(k);
    const plan = c.monthPlans[mk] ? JSON.parse(JSON.stringify(c.monthPlans[mk])) : defaultMonthPlan(k);
    const exId = ($('#pi-ex') || {}).value, sets = L.num(($('#pi-sets') || {}).value), reps = ((($('#pi-reps') || {}).value) || '').trim().slice(0, 20), rest = Number(($('#pi-rest') || {}).value) || 60;
    if (!C.EX[exId]) return toast('Escolha um exercício');
    if (!(sets >= 1 && sets <= 8)) return toast('Séries: de 1 a 8');
    if (!/\d/.test(reps)) return toast('Repetições: ex. 10–12 ou 30–40 s');
    const list = (plan[d.t] || []).slice();
    const item = { exId, sets: Math.round(sets), reps, rest };
    if (d.i === 'new') list.push(Object.assign({ slotId: null, role: 'acc' }, item));
    else { const i = Number(d.i), old = list[i] || {}; list[i] = Object.assign({}, old, item, { slotId: old.exId === exId ? old.slotId || null : null }); }
    plan[d.t] = list; c.monthPlans[mk] = plan; save('core'); closeSheet(); render(); toast('Plano do mês atualizado');
  },
  delPlanItem: (d) => {
    const k = today(), c = CORE(), mk = L.monthKey(k);
    const plan = c.monthPlans[mk] ? JSON.parse(JSON.stringify(c.monthPlans[mk])) : defaultMonthPlan(k);
    const list = (plan[d.t] || []).slice();
    if (list.length <= 1) return toast('O treino precisa de pelo menos 1 exercício');
    list.splice(Number(d.i), 1); plan[d.t] = list; c.monthPlans[mk] = plan; save('core'); closeSheet(); render(); toast('Exercício removido');
  },

  /* corrida e caminhada */
  runStart: (d) => {
    if (ui.run && ui.run.active) return go('corrida');
    const k = today(), idx = Number(d.idx), info = runPlanInfo(k), rs = runSessionFor(k);
    let s = null;
    if (rs && rs.idx === idx) s = rs.s;
    else { const slot = runWeekSlots(k).find((x) => x.idx === idx); s = slot ? slot.s : null; }
    if (!s) return toast('Sessão não encontrada');
    s = sessionToRun(s);
    runBegin({ idx, week: info.w, title: s.title, kind: s.kind, blocks: s.blocks, note: s.note || '', place: s.place || ui.lastPlace || 'praia', targetKm: s.targetKm || null, walkOnly: !!s.walkOnly });
  },
  runFree: (d) => {
    if (ui.run && ui.run.active) return go('corrida');
    if (d.t === 'r' && runLocked()) return openSheet('confirm', { title: 'Corrida só depois da liberação', text: 'Pelo seu questionário de segurança, a corrida fica para depois da avaliação médica. Até lá, faça caminhada. Depois da consulta, marque “Já fui avaliado e liberado”.', ok: 'runFree', okData: { t: 'w' }, okLabel: 'Fazer caminhada' });
    closeSheet();
    const r = d.t === 'r';
    runBegin({ free: true, freeType: r ? 'r' : 'w', title: r ? 'Corrida livre' : 'Caminhada livre', kind: r ? 'run' : 'walk', blocks: [], idx: null, week: null, place: ui.lastPlace || 'praia', note: 'Sessão livre: o cronômetro corre até você finalizar. A cada 5 minutos, um aviso de tempo.' });
  },
  runPause: () => {
    const r = ui.run; if (!r || !r.active) return;
    if (r.pausedAt) { r.pausedTotal += Date.now() - r.pausedAt; r.pausedAt = null; if (r.gps && r.gps.state) r.gps.state = Object.assign({}, r.gps.state, { last: null }); runSpeak('Continuando'); }
    else { r.pausedAt = Date.now(); runSpeak('Pausado'); }
    runPersist();
    const b = $('#runPauseBtn'); if (b) b.innerHTML = r.pausedAt ? `${icon('play')}Continuar` : `${icon('clock')}Pausar`;
    runTick();
  },
  runSkip: () => {
    const r = ui.run; if (!r || !r.active || r.free) return;
    const at = L.blockAt(r.blocks, runElapsed(r));
    if (at.i >= r.blocks.length) return;
    r.startedAt -= at.left * 1000;
    runPersist(); runTick();
  },
  runVoice: (d, el) => {
    const r = ui.run; if (!r) return;
    r.voice = r.voice === false;
    el.setAttribute('aria-checked', String(r.voice)); runPersist();
    if (r.voice) runSpeak('Avisos por voz ligados'); else { try { window.speechSynthesis.cancel(); } catch (e) { /* ok */ } }
  },
  runExit: () => { go('home'); toast('A sessão continua contando. Volte pelo card Agora.'); },
  runFinishAsk: () => {
    const r = ui.run; if (!r || !r.active) return;
    if (runElapsed(r) < 60) return openSheet('confirm', { title: 'Encerrar sem registrar?', text: 'A sessão teve menos de 1 minuto.', ok: 'runDiscard', okLabel: 'Descartar', danger: true, cancel: 'Continuar' });
    openSheet('confirm', { title: 'Finalizar a sessão?', text: r.free ? 'O tempo vai para o registro.' : 'Tudo bem terminar antes: o que foi feito conta.', ok: 'runFinish', okLabel: 'Finalizar', cancel: 'Continuar' });
  },
  runFinish: () => { closeSheet(); runFinishNow(); },
  runSave: (d) => {
    const fromRun = d.fromRun === '1', r = fromRun ? ui.run : null, res = fromRun ? ui.runResult || (r && r.result) : null;
    const min = num('rl-min'), km = num('rl-km');
    if (!(min >= 1 && min <= 600)) return toast('Informe o tempo em minutos');
    if (km != null && !(km > 0 && km <= 100)) return toast('Confira a distância em km');
    const type = fromRun ? null : pressedIn('rl-type') || 'rw';
    const place = pressedIn('rl-place') || 'praia', rpe = Number(($('#rl-rpe') || {}).value) || null, pain = Number(pressedIn('rl-pain') || 0);
    const kindOf = { w: 'walk', r: 'run', rw: 'runwalk' }, titleOf = { w: 'Caminhada', r: 'Corrida', rw: 'Corrida + caminhada' };
    const date = r && r.startedAt ? L.key(new Date(r.startedAt)) : today();
    const rec = {
      id: uidGen('r'), date, at: Date.now(),
      idx: r && r.idx != null && !r.free ? r.idx : null, week: r && r.week != null ? r.week : null,
      title: r ? r.title : titleOf[type], kind: r ? (r.free ? (r.freeType === 'r' ? 'run' : 'walk') : r.kind) : kindOf[type],
      minutes: Math.round(min), km: km ? Math.round(km * 100) / 100 : null, place, rpe, pain, painArea: pain >= 1 ? pressedIn('rl-area') : null,
      maxRun: res ? res.maxRun : null, runSec: res ? res.runDone : null, src: fromRun ? 'app' : 'manual',
    };
    MON(date).runs.push(rec);
    save(monthId(date));
    if (fromRun) { ui.run = null; ui.runResult = null; runPersist(); }
    ui.lastPlace = place;
    closeSheet(); ui.route = 'treino'; ui.sub.treino = 'corrida'; render();
    toast(pain >= 3 ? 'Salvo. Com dor forte, não treine em cima dela: procure avaliação.' : pain === 2 ? 'Salvo. Na próxima, troque por caminhada e observe a dor.' : `Sessão salva: ${rec.minutes} min${rec.km ? ' · ' + fmt1(rec.km) + ' km' : ''}`);
  },
  runDiscard: () => { gpsStop(); ui.run = null; ui.runResult = null; runPersist(); wakeLock(false); closeSheet(); ui.route = 'treino'; ui.sub.treino = 'corrida'; render(); toast('Sessão descartada'); },
  askDelRun: (d) => openSheet('confirm', { title: 'Apagar esta sessão?', text: 'O registro sai do histórico e dos totais.', ok: 'delRun', okData: { id: d.id }, okLabel: 'Apagar', danger: true }),
  delRun: (d) => {
    for (const id of Store.ids().filter((x) => /^m-/.test(x))) {
      const m = Store.peek(id);
      if (m && m.runs && m.runs.some((r) => r.id === d.id)) { m.runs = m.runs.filter((r) => r.id !== d.id); save(id); }
    }
    closeSheet(); render(); toast('Sessão apagada');
  },
  runShift: (d) => {
    const info = runPlanInfo(), step = Number(d.d), nw = info.w - step;
    if (nw < 1) return toast('Você já está na semana 1');
    if (nw >= info.N) return toast('Você já está na reta final do plano');
    const c = CORE(); c.run = Object.assign({}, c.run, { shift: (c.run.shift || 0) + step });
    save('core'); render(); toast(step > 0 ? `Plano volta para a semana ${nw}` : `Plano avança para a semana ${nw}`);
  },
  provaDefault: () => { const r = C.RACE_DEFAULT, set = (id, v) => { const el = $('#' + id); if (el) el.value = v; }; set('pv-name', r.name); set('pv-city', r.city); set('pv-date', r.date); },
  saveProva: () => {
    const name = (($('#pv-name') || {}).value || '').trim().slice(0, 60), city = (($('#pv-city') || {}).value || '').trim().slice(0, 40), date = ($('#pv-date') || {}).value || '';
    if (!name) return toast('Dê um nome para a prova');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date <= today()) return toast('Escolha uma data futura');
    if (L.diffDays(today(), date) > 800) return toast('Escolha uma data nos próximos 2 anos');
    const sw = $('#pv-restart'), restart = !!(sw && sw.getAttribute('aria-checked') === 'true');
    const c = CORE(); c.run = Object.assign({}, c.run, { race: { name, city, date } });
    if (restart) { c.run.start = today(); c.run.shift = 0; }
    save('core'); closeSheet(); render();
    const info = runPlanInfo();
    toast(info.short ? `Prova salva: ${info.N} semanas. Meta segura: completar caminhando.` : `Prova salva: plano de ${info.N} semanas`);
  },

  /* fotos: linha do tempo */
  tlPlay: (d, el) => { if (!ui.tl) return; ui.tl.playing = !ui.tl.playing; el.textContent = ui.tl.playing ? 'Pausar' : 'Continuar'; },
  tlSpeed: (d, el) => { if (!ui.tl) return; const sp = ui.tl.speed >= 4 ? 1 : ui.tl.speed * 2; tlSetSpeed(sp); el.textContent = `Velocidade ${sp}×`; },

  /* calendário, backup e instalação */
  exportIcs: () => {
    const ev = fixedReminders().map((e) => Object.assign({}, e, { title: 'Saúde Jr. · ' + e.title }));
    if (!ev.length) return toast('Ative ao menos um lembrete');
    offerFile('saude-jr-lembretes.ics', L.buildICS(ev, today(), icsNow()), 'text/calendar');
  },
  importAsk: () => openSheet('confirm', { title: 'Restaurar um backup?', text: 'Escolha o arquivo .json do backup. Os dados atuais deste app serão substituídos pelos do arquivo. As fotos não fazem parte do backup.', ok: 'importPick', okLabel: 'Escolher arquivo' }),
  importPick: () => { const inp = document.getElementById('importInput'); closeSheet(); if (inp) inp.click(); },
  installApp: async () => {
    const ev = ui.installEvt;
    if (!ev) return go('instalar');
    ui.installEvt = null;
    try { ev.prompt(); const r = await ev.userChoice; toast(r && r.outcome === 'accepted' ? 'Instalando o Saúde Jr.…' : 'Instalação cancelada'); }
    catch (e) { toast('Use o menu do navegador: Instalar app'); }
    render();
  },
  installHintOff: () => { try { localStorage.setItem('mv1:hideInstall', '1'); } catch (e) { ui.hideInstall = true; } render(); },
};
const CHG = {
  exLoadInput: (el) => { const s = S(), it = s && s.items[Number(el.dataset.i)]; if (!it) return; const v = L.num(el.value); it.load = v != null && v >= 0 && v <= 1000 ? v : null; save(monthId(s.date)); render(); },
  exNote: (el) => { const s = S(), it = s && s.items[Number(el.dataset.i)]; if (!it) return; it.note = el.value.slice(0, 500); save(monthId(s.date)); },
  pf: (el) => {
    const f = el.dataset.f, t = el.dataset.t;
    let v = el.value;
    if (t === 'num') {
      v = L.num(v);
      const lim = PF_LIMITS[f];
      if (v == null || (lim && (v < lim[0] || v > lim[1]))) { toast('Valor fora do esperado'); return render(); }
      if (f === 'goalWeight' && v >= prof().startWeight) { toast('A meta precisa ser menor que o peso inicial'); return render(); }
    }
    if (t === 'time' && !/^\d{2}:\d{2}$/.test(v)) return;
    if (t === 'text') v = String(v).trim().slice(0, 60);
    P()[f] = v; save('profile'); render(); toast('Salvo');
  },
  prefNotes: (el) => { const p = P(); p.prefs = Object.assign({}, prof().prefs); p.prefs.notes = el.value.slice(0, 300); save('profile'); toast('Salvo'); },
  mealTime: (el) => { if (!/^\d{2}:\d{2}$/.test(el.value)) return; const p = P(); p.mealTimes = Object.assign({}, prof().mealTimes); p.mealTimes[el.dataset.m] = el.value; save('profile'); toast('Horário salvo'); },
  remEvery: (el) => { const p = P(); p.reminders = Object.assign({}, prof().reminders); p.reminders.waterEvery = Number(el.value); save('profile'); render(); },
  remSet: (el) => {
    const f = el.dataset.f, t = el.dataset.t;
    let v = el.value;
    if (t === 'time') { if (!/^\d{2}:\d{2}$/.test(v)) return; }
    else if (t === 'int') { v = Number(v); if (!Number.isInteger(v) || v < 0 || v > 6) return; }
    const p = P(); p.reminders = Object.assign({}, prof().reminders); p.reminders[f] = v; save('profile'); render(); toast('Lembrete ajustado');
  },
  gutNotes: (el) => { const k = today(); const day = dayW(k); day.gut = Object.assign({}, day.gut); const v = el.value.trim().slice(0, 300); if (v) day.gut.notes = v; else delete day.gut.notes; save(monthId(k)); toast('Observação salva'); },
  photoFile: (el) => { const f = el.files && el.files[0]; el.value = ''; if (f) addPhoto(f); },
  importFile: async (el) => {
    const f = el.files && el.files[0]; el.value = '';
    if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      const n = await Store.importAll(data);
      invalidate(); cleanupStale();
      if (prof().onboarded) ui.route = 'home'; else { obInit(); ui.route = 'onboarding'; }
      render(); toast(`Backup restaurado (${n} arquivo${n === 1 ? '' : 's'} de dados)`);
    } catch (e) { console.error(e); toast('Arquivo inválido: escolha um backup do Saúde Jr.'); }
  },
};

/* ---------------- limpeza e inicialização ---------------- */
function cleanupStale() {
  const k = today(), changed = [];
  for (const id of Store.ids().filter((x) => /^m-/.test(x))) {
    const m = Store.peek(id);
    if (!m || !m.sessions) continue;
    let dirty = false;
    m.sessions = m.sessions.filter((s) => {
      if (s.completed || s.date === k) return true;
      dirty = true;
      if (s.items.some((it) => it.sets.some((x) => x.done))) { s.completed = true; s.partial = true; s.finishedAt = s.finishedAt || s.startedAt + 3600000; return true; }
      return false;
    });
    if (dirty) changed.push(id);
  }
  if (changed.length) save(...changed);
}
function dayRollover() {
  const k = today();
  if (ui.day && ui.day !== k) { invalidate(); if (ui.route !== 'sessao') safeRender(); }
  ui.day = k;
}
function boot() {
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const fn = ACT[el.dataset.act];
    if (!fn) return;
    e.preventDefault();
    try { const r = fn(Object.assign({}, el.dataset), el, e); if (r && r.catch) r.catch((err) => { console.error(err); toast('Algo deu errado. Tente de novo.'); }); }
    catch (err) { console.error(err); toast('Algo deu errado. Tente de novo.'); }
  });
  document.addEventListener('change', (e) => { const el = e.target.closest('[data-change]'); if (el && CHG[el.dataset.change]) { try { CHG[el.dataset.change](el, e); } catch (err) { console.error(err); } } });
  document.addEventListener('input', (e) => { const el = e.target.closest('[data-input]'); if (el && INP[el.dataset.input]) { try { INP[el.dataset.input](el, e); } catch (err) { console.error(err); } } });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && ui.sheet) closeSheet();
    if (e.key === 'Enter' && e.target && e.target.closest) {
      const el = e.target.closest('[data-enter]');
      if (el && ACT[el.dataset.enter]) { e.preventDefault(); const r = ACT[el.dataset.enter]({}, el, e); if (r && r.catch) r.catch((err) => console.error(err)); }
    }
  });
  document.addEventListener('pointerdown', unlockAudio, { passive: true });
  document.addEventListener('focusout', () => { setTimeout(() => { if (pendingRender && !isTyping() && !ui.sheet) { pendingRender = false; render(); } }, 0); });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    dayRollover(); tickReminders();
    if (ui.route === 'sessao' || (ui.run && ui.run.active)) wakeLock(true);
    runTick();
    if (ui.route === 'home') safeRender();
    if (CLOUD) cloudRefresh();
  });
  Store.on('status', () => {
    const [cls, label] = syncInfo();
    document.querySelectorAll('.top-btn .dot').forEach((d) => { d.className = 'dot ' + cls; });
    const l = document.getElementById('syncLabel'); if (l) l.textContent = label;
  });
  Store.on('remote', () => { invalidate(); safeRender(); });

  ui.day = today();
  // sessão de corrida em andamento sobrevive a recarregar a página
  try {
    const saved = JSON.parse(localStorage.getItem('mv1:run') || 'null');
    if (saved && saved.startedAt && Date.now() - saved.startedAt < 8 * 3600000) { ui.run = saved; ui.runResult = saved.active ? null : saved.result || null; }
    else if (saved) localStorage.removeItem('mv1:run');
  } catch (e) { /* sem armazenamento local */ }
  const startRoute = () => (ui.run && ui.run.active ? 'corrida' : 'home');
  setTimeout(() => { if (ui.route === 'splash') { ui.splashSlow = true; render(); } }, CLOUD ? 9000 : 5000);
  if (CLOUD) {
    // app publicado: conta com e-mail e senha (Supabase)
    bootCloud().catch((e) => { console.error(e); goAuth('offline', { canOffline: false, error: Cloud.message(e) }); });
    if (ui.run && ui.run.active) { gpsStart(); wakeLock(true); }
    window.addEventListener('online', () => { if (ui.offlineUser) bootCloud(true); else cloudRefresh(); });
    setInterval(() => { if (!document.hidden) cloudRefresh(); }, 90000);
  }
  const had = CLOUD ? false : Store.hydrateFromCache();
  if (had && prof().onboarded) { cleanupStale(); ui.route = startRoute(); applyDeepLink(); }
  if (!CLOUD) {
    render();
    if (ui.run && ui.run.active) { gpsStart(); wakeLock(true); }
  }
  if (!CLOUD) Store.init().then(async (mode) => {
    const u = Store.user;
    if (u) {
      try { ui.owner = await u.isOwner(); } catch (e) { ui.owner = null; }
      try { ui.me = await u.me(); } catch (e) { ui.me = null; }
    }
    cleanupStale();
    if (!prof().onboarded) { if (ui.route !== 'onboarding') { obInit(); ui.route = 'onboarding'; } }
    else if (ui.route === 'splash' || ui.route === 'onboarding') { ui.route = startRoute(); applyDeepLink(); }
    safeRender();
    if (mode === 'cloud') getCap('assets');
    tickReminders();
  }).catch((e) => { console.error(e); if (ui.route === 'splash') { obInit(); ui.route = 'onboarding'; render(); } });
  setInterval(tickReminders, 20000);
  setInterval(() => { const el = document.getElementById('sessClock'); if (el) { const s = activeSession(); if (s) el.textContent = clockText(s); } }, 1000);
  setInterval(dayRollover, 30000);
  setInterval(runTick, 250);
  if (PWA) {
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      const hadController = !!navigator.serviceWorker.controller;
      navigator.serviceWorker.register('sw.js').catch(() => {});
      navigator.serviceWorker.addEventListener('controllerchange', () => { if (hadController) toast('Saúde Jr. atualizado'); });
    }
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); ui.installEvt = e; if (ui.route === 'instalar' || ui.route === 'home') safeRender(); });
    window.addEventListener('appinstalled', () => { ui.installEvt = null; toast('Saúde Jr. instalado'); safeRender(); });
  }
}
/** app publicado: busca o que mudou em outro aparelho e envia fotos pendentes */
let lastRefresh = 0;
function cloudRefresh() {
  if (!CLOUD || Store.mode !== 'cloud' || Date.now() - lastRefresh < 20000) return;
  lastRefresh = Date.now();
  Store.pull().then(() => uploadPendingPhotos()).catch(() => {});
}
/** atalhos do ícone (?go=agenda | fotos | corrida) */
function applyDeepLink() {
  let to = null;
  try { to = new URLSearchParams(location.search).get('go'); } catch (e) { to = null; }
  if (!to || ui.deepDone || (ui.run && ui.run.active)) return;
  ui.deepDone = true;
  if (to === 'agenda') ui.route = 'agenda';
  else if (to === 'fotos') { ui.sub.evolucao = 'fotos'; ui.route = 'evolucao'; }
  else if (to === 'corrida') { ui.sub.treino = 'corrida'; ui.route = 'treino'; }
  else if (to === 'comida') ui.route = 'comida';
}
Object.assign(ACT, AUTH_ACT);
boot();
