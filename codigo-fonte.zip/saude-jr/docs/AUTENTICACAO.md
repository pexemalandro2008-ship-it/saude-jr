# Autenticação

- **Supabase Auth** com e-mail e senha. Sem senha universal, sem usuário fixo, sem login falso.
- **Cadastro:** `POST /functions/v1/app/signup` (função `supabase/functions/app`). Cria a conta já confirmada (sem e-mail de confirmação) e limita tentativas: 5 por IP por hora e 100 por dia (IP guardado só como hash).
- **Senha:** 8 a 72 caracteres, com letras e números, sem conter o próprio e-mail.
- **Sessão:** fica salva no aparelho (`saudejr-auth`) e é renovada sozinha. "Sair da conta" apaga a sessão e a cópia local.
- **Chave pública:** lida em tempo real em `/functions/v1/app/config`. Nada de chave no repositório.

## Recuperar senha

O app pede o link por e-mail (`resetPasswordForEmail`) e aceita tanto abrir o link direto quanto colar o link na tela "Recuperar senha".

Configuração no painel do Supabase (Authentication → URL Configuration):

- **Site URL:** `https://pexemalandro2008-ship-it.github.io/saude-jr/`
- **Redirect URLs:** `https://pexemalandro2008-ship-it.github.io/saude-jr/**`

O servidor de e-mail padrão do Supabase só envia para membros da equipe do projeto e poucas mensagens por hora. Para todos os usuários receberem o e-mail de recuperação, configure um SMTP próprio (Authentication → Emails → SMTP Settings; ex.: Resend ou Brevo, plano grátis).

## Isolamento

Tabela `app_documents` com RLS `(select auth.uid()) = user_id` nas 4 operações. As tabelas por assunto (profiles, meals, water_logs etc.) são só leitura para o dono e preenchidas por gatilho. Fotos: `progress-photos/<uid>/...`, políticas pela pasta do usuário.
