# Arquitetura

## Escolhas

| Decisão | Escolha | Por quê |
| --- | --- | --- |
| Tipo de app | PWA mobile-first | Instala no Android pelo navegador, abre em tela cheia, funciona offline, sem loja e sem custo |
| Linguagem | HTML, CSS e JavaScript puro | Carrega rápido e usa pouca memória. Única biblioteca: `supabase-js` (copiada para `vendor/`, sem CDN) |
| Build | `scripts/build.mjs` (Node puro) | Junta tudo num único `index.html` e checa a sintaxe; o build falha se houver erro |
| Conta | **Supabase Auth** (e-mail e senha) | Login real, sessão salva no aparelho, recuperação de senha. Veja [AUTENTICACAO.md](AUTENTICACAO.md) |
| Dados | Tabela `app_documents` (Postgres, RLS por usuário) + cópia local por usuário | Cada conta só enxerga os próprios dados; funciona offline e sincroniza quando a internet volta |
| Tabelas por assunto | profiles, reminders, workouts, workout_logs, meals, water_logs, sleep_logs, energy_logs, intestinal_logs, measurements, progress_photos, daily_checklists | Preenchidas por gatilho a partir dos documentos; só leitura para o dono |
| Fotos | Supabase Storage, bucket **privado** `progress-photos/<uid>/` + cache no IndexedDB | Nunca públicas; políticas pela pasta do usuário |
| Offline | Service worker com cache versionado | Página: rede primeiro, cópia se offline. Arquivos: cache primeiro. Versões antigas apagadas ao ativar |
| Fontes | Archivo e Figtree dentro do app (licença OFL) | Sem chamadas a terceiros e funcionam offline |
| Deploy | GitHub Pages (app) + Supabase grátis (banco, login, fotos, função `app`) | Custo zero. Veja [DEPLOY.md](DEPLOY.md) |

## Módulos

- `src/lib/logic.js` — lógica pura, testada em Node: datas, tendência de peso (média móvel exponencial), ritmo semanal,
  checklist, sequência, progressão de carga, plano de corrida, agenda do dia, GPS, calendário `.ics`.
- `src/lib/content.js` — conteúdo: exercícios de academia comercial, fases, cardápio, substituições, textos educativos e de segurança.
- `src/lib/store.js` — documentos (`profile`, `core`, um por mês `m-AAAA-MM`), cópia local por usuário e sincronização com a conta.
- `src/lib/cloud.js` — conexão com o Supabase: sessão, cadastro, recuperação de senha, documentos e fotos.
- `src/lib/photos.js` — cache de fotos no IndexedDB.
- `src/app/auth.js` — telas de entrar, criar conta, recuperar e trocar senha; sair da conta.
- `supabase/migrations` — esquema, RLS, gatilhos e bucket privado. `supabase/functions/app` — cadastro e configuração pública.
- `src/app/*` — telas, folhas de registro, ações, lembretes e inicialização.

## Duas versões do mesmo código

- `npm run build` com `SUPABASE_URL` → **app instalável com conta** (`dist/pwa`), publicado no GitHub Pages. Sem `SUPABASE_URL`, gera o modo local (dados só no aparelho), usado em desenvolvimento.
  O perfil inicial pode vir no link: `#ini=idade,altura,peso,meta` (ex.: `#ini=30,175,95,85`), sem ficar no código.
- `npm run build:claude` → versão que roda dentro do Claude (dados na conta Claude, sincronizados entre aparelhos).

## Segurança

- Nenhuma senha, token ou chave no código: a chave pública é lida em tempo real; a secreta só existe no Supabase.
- Content-Security-Policy no app: só conecta ao próprio site e ao projeto Supabase.
- Fotos e backups pessoais ficam fora do repositório (`.gitignore`: `private/`, backups, exports).
- Conteúdo conservador para quem começa com peso alto: sem alto impacto no início, progressão só com avaliação de esforço,
  trote bloqueado até liberação médica quando o questionário de segurança indica.
