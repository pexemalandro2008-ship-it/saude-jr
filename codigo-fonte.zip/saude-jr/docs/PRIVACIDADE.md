# Política de Privacidade — Saúde Jr.

Versão de 29/09/2026.

**Quais dados:** o que você registra no app — perfil (nome, idade, altura, pesos), medidas, treinos e cargas, cardio e
corridas, refeições, água, sono, energia, intestino, suplementos, hábitos e, se quiser, fotos de evolução.

**Onde ficam:** na sua conta do Saúde Jr. (banco Supabase, com regras que deixam cada conta ver e alterar só os próprios
dados) e numa cópia no seu aparelho para funcionar sem internet. Ninguém mais tem acesso. Ao sair da conta, a cópia do
aparelho é apagada.

**Fotos:** são dados pessoais sensíveis. Ficam num armazenamento **privado**, numa pasta só da sua conta, com cópia no
aparelho. Não entram no backup e nunca são publicadas.

**Conta:** e-mail e senha. A senha é guardada pelo Supabase Auth (criptografada), nunca pelo app. No cadastro, o endereço
IP é usado só para limitar tentativas e fica guardado apenas como código (hash) por até 7 dias.

**O que o app não faz:** não tem anúncios, rastreadores, análise de uso nem venda de dados.

**GPS:** usado só durante uma sessão de corrida, com a sua permissão, para medir a distância. As coordenadas não são guardadas; só a distância total.

**Seus controles:** exportar tudo (arquivo `.json`), restaurar, **apagar todos os dados** (inclusive as fotos da conta) em Perfil › Meus dados, e sair da conta.

**Código aberto:** o código fica no GitHub, sem nenhum dado pessoal. Fotos e backups pessoais são proibidos no repositório (`.gitignore`).
