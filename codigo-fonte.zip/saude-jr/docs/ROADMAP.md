# Próximas fases

## Fase 2
- Banco de alimentos e receitas simples (com fonte dos dados nutricionais)
- Ilustrações dos exercícios
- Relatórios e exportação em PDF
- Metas inteligentes (ajuste automático pela tendência)
- Passos automáticos (Health Connect exige app nativo; até lá, registro manual)

## Fase 3
- App Android nativo (APK/AAB) e Google Play — alarmes locais que tocam com o celular bloqueado
- Integração com Google Fit / Health Connect
- Backup em nuvem e sincronização entre aparelhos (com login e dados isolados por usuário)
