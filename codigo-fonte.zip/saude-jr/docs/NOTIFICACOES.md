# Notificações e lembretes

Lembretes configuráveis: **acordar (com o botão Começar o dia), foto do dia, treino/corrida, 6 refeições, suplementos, água, pesagem semanal, checklist da noite e hora de desacelerar**.
Horários em **Perfil › Lembretes e alarmes** e **Perfil › Agenda e semana**. Cada aviso de treino traz a frase do dia.

## O que funciona, sem rodeios

| Situação | Funciona? | Como |
| --- | --- | --- |
| App aberto na tela | ✅ Sim | Aviso na tela, som e vibração, com botão de ação (ex.: "Registrar refeição") |
| App instalado, aberto há pouco em segundo plano | ⚠️ Às vezes | Notificação do sistema (é preciso permitir em Lembretes › Notificações). O Android pausa apps web em segundo plano, então não dá para garantir o horário |
| Celular bloqueado / app fechado | ❌ Não pelo navegador | Limite do Android para apps web: sem servidor de push, o navegador não acorda o app num horário marcado |
| Celular bloqueado, via **Google Agenda** | ✅ Sim (recomendado) | Em Lembretes, toque em **Adicionar** em cada lembrete: o Google Agenda abre com o evento e a repetição prontos. O aviso toca pelo próprio Google Agenda |
| Celular bloqueado, via arquivo `.ics` | ✅ Sim | **Baixar calendário de lembretes**: iPhone e Samsung Calendário importam direto; no Google Agenda, importe pelo computador |

## Por que não prometemos mais

Notificações agendadas de verdade em apps web exigem **Web Push com servidor** (que envia a mensagem no horário). Isso
significa backend, chaves e conta — fica para a Fase 3 junto com o app Android nativo, onde alarmes locais funcionam sem internet.
