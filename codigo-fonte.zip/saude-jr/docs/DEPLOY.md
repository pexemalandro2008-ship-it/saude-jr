# Deploy

## App (GitHub Pages)

Endereço: https://pexemalandro2008-ship-it.github.io/saude-jr/

Hoje o Pages publica a raiz da branch `main` (o app já gerado: `index.html`, `sw.js`, `manifest.json`, `fonts/`, `icons/`, `vendor/`). Para atualizar à mão:

```bash
SUPABASE_URL=https://infspwbmjkloxghwwroe.supabase.co npm run build
# envie o conteúdo de dist/pwa para a raiz da main
```

Automático: o workflow `.github/workflows/deploy.yml` roda os testes e publica `dist/pwa` quando o código-fonte está no repositório. Para usar, em Settings → Pages troque "Source" para **GitHub Actions**. A URL do Supabase é pública (não é segredo) e pode ser trocada na variável `SUPABASE_URL` do repositório.

## Banco e servidor (Supabase)

- Migração: `supabase/migrations/*.sql` (aplicada no projeto `infspwbmjkloxghwwroe`).
- Função: `supabase/functions/app` com `verify_jwt = false` (as rotas `/config` e `/signup` são públicas; o cadastro tem limite por IP).
- Conferência de segurança em produção: rode `test/sql/20-remote-check.sql` no SQL Editor. Precisa terminar com `TESTE_OK` (nada fica gravado).
