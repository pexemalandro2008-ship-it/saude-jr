# Testes

```bash
npm test          # unitários (Node, sem navegador)
npm run test:db   # banco: RLS, projeção e fotos num Postgres 16 limpo (PGHOST, PGPORT, PGUSER, PGPASSWORD)
npm run test:e2e  # ponta a ponta no Chromium (npm install && npx playwright install chromium) — precisa do Postgres
```

## Conta e banco (test/e2e/cloud.e2e.mjs + test/sql)

Postgres com as mesmas migrações da produção e um Supabase local (`test/support/supabase-local.mjs`) que aplica RLS de verdade:

- criar conta (validações, senha fraca, e-mail repetido), primeiro uso, sair e entrar de novo, sessão salva ao reabrir;
- **usuário B não vê nem altera nada do usuário A** (documentos, tabelas e fotos);
- outro aparelho recebe os dados; recuperação de senha (link aberto e link colado); troca de senha;
- sem internet: abre com a cópia local e sincroniza depois;
- telas de 360, 390, 412 e 430 px sem rolagem lateral e botões com 40 px ou mais;
- PWA: manifesto, service worker, CSP, nenhuma chave nem nome pessoal no HTML publicado;
- servidor: limite de cadastros por IP, acesso anônimo bloqueado.

## Unitários (31)

Datas locais, sono atravessando meia-noite, números com vírgula, tendência de peso, ritmo semanal, metas de 5 em 5 kg,
projeção, checklist e sequência, água esperada, progressão de carga, calorias de cardio, marmita, alertas sem diagnóstico,
horários das 6 refeições, semana academia/corrida, plano de corrida (33 semanas, progressão segura, durações realistas),
blocos da sessão ao vivo, GPS (saltos e leituras ruins ignorados), agenda do dia, fotos, estoque de suplementos,
calendário `.ics` (repetição, alarme, texto escapado), cardápio (frutas, fibras, proteína), textos sem promessas.

## Ponta a ponta (147 verificações)

Em tela de celular (iPhone 13, Pixel 7) e em 320, 360, 390 e 768 px:

- abrir o app, cadastro, validações;
- **instalar PWA**: critério de instalação do Chrome sem erros, manifesto, ícones, service worker ativo;
- atualizar a página, **fechar e abrir**, dados continuam;
- **perder a internet** (app abre e registra offline) e **voltar a internet** (nada se perde);
- recuperação dos dados pela cópia no IndexedDB se o armazenamento simples for apagado;
- registrar peso, água, sono, **energia**, medidas, passos, cardio;
- iniciar treino, registrar carga, concluir série e exercício, descanso, trocar exercício, progressão no fim;
- alimentação: refeições, horários, marmita, intestino, suplementos (estoque);
- gráfico de tendência, conquistas, meta;
- corrida guiada: contagem, pausa, sessão sobrevive a recarregar, registro com dor;
- fotos (frente, lado, costas), linha do tempo e comparação;
- **notificações**: aviso na tela, fila de avisos, notificação do sistema no app instalado, lembretes do Google Agenda, `.ics`;
- alterar configurações; backup e restauração; privacidade e termos;
- sem rolagem lateral e sem erros no console em todas as telas.
