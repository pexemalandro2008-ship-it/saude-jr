# Termos de Uso — Saúde Jr.

Versão de 29/09/2026.

1. O Saúde Jr. é uma ferramenta pessoal de acompanhamento de hábitos, com conteúdo educativo.
2. **Não é serviço médico.** Não faz diagnóstico e não prescreve medicamentos, hormônios, anabolizantes, "boosters",
   dietas extremas ou jejuns prolongados. Testosterona aparece só como tema educativo: para investigar, procure um médico.
3. Projeções de peso e de prova são **estimativas**, não promessas. O resultado depende de fatores individuais.
4. Antes de aumentar a intensidade dos treinos, faça avaliação com **médico**, **nutricionista** e **profissional de educação física**.
5. Pare o exercício e procure atendimento se sentir dor ou pressão no peito, falta de ar desproporcional, tontura, desmaio ou palpitação forte.
6. Os dados são seus e ficam no seu aparelho (ver [PRIVACIDADE.md](PRIVACIDADE.md)). Faça backups de vez em quando.
7. Uso gratuito, sem anúncios e sem compras.
