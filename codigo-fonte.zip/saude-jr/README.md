# Saúde Jr.

App de saúde para celular Android (PWA instalável): treino de academia, corrida até os 10 km, alimentação simples e barata, água, sono, intestino, peso com tendência, medidas, fotos de evolução e lembretes.

**Link do app:** https://pexemalandro2008-ship-it.github.io/saude-jr/

- **Conta de verdade:** cadastro e entrada com e-mail e senha (Supabase Auth). Cada pessoa só enxerga e altera os próprios dados: regras RLS no banco.
- **Fotos privadas:** bucket privado no Supabase Storage, uma pasta por usuário. Nunca ficam públicas.
- **Funciona sem internet:** cópia local por usuário; o que for feito offline sobe quando a internet voltar.
- **Custo:** zero (GitHub Pages + plano grátis do Supabase).
- **Não é médico:** o app não diagnostica, não prescreve remédios, hormônios ou dietas extremas.

## Como instalar no Android

1. Abra o link no **Chrome** do celular.
2. Toque em **Criar conta** (nome, e-mail e senha com letras e números).
3. Menu **⋮ → Instalar app** (ou "Adicionar à tela inicial").

## Estrutura

```
src/            app (HTML, CSS e JS sem framework)
  lib/          lógica, conteúdo, armazenamento (store.js) e conexão com a conta (cloud.js)
  app/          telas, login (auth.js), fotos e ações
supabase/
  migrations/   esquema do banco com RLS, tabelas, gatilhos e bucket privado de fotos
  functions/app servidor do cadastro (/signup) e configuração pública (/config)
scripts/        build, servidor local e ícones
test/           unitários, banco (RLS) e ponta a ponta (Playwright, 360 a 430 px)
docs/           arquitetura, autenticação, deploy, privacidade, testes, notificações
```

## Desenvolvimento

```bash
npm install
npm run dev                      # app local, sem conta (dados só no aparelho)
SUPABASE_URL=https://<projeto>.supabase.co npm run build   # app com login em dist/pwa
```

Nenhuma chave vai para o código: o app busca a chave **pública** em `/functions/v1/app/config` quando abre. A chave secreta existe só dentro do Supabase.

## Testes

```bash
npm test            # unitários
npm run test:db     # banco: isolamento entre usuários, projeção e fotos (precisa de Postgres; veja docs/TESTES.md)
npm run test:e2e    # ponta a ponta no Chromium com Supabase local
```

## Documentação

[Arquitetura](docs/ARQUITETURA.md) · [Autenticação](docs/AUTENTICACAO.md) · [Deploy](docs/DEPLOY.md) · [Privacidade](docs/PRIVACIDADE.md) · [Testes](docs/TESTES.md) · [Notificações](docs/NOTIFICACOES.md) · [Termos](docs/TERMOS.md) · [Roadmap](docs/ROADMAP.md)
